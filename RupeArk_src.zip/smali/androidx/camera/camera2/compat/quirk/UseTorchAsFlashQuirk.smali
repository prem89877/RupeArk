.class public interface abstract Landroidx/camera/camera2/compat/quirk/UseTorchAsFlashQuirk;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/kkep;
