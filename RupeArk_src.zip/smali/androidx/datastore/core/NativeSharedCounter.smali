.class public final Landroidx/datastore/core/NativeSharedCounter;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public final native nativeCreateSharedCounter(I)J
.end method

.method public final native nativeGetCounterValue(J)I
.end method

.method public final native nativeIncrementAndGetCounterValue(J)I
.end method

.method public final native nativeTruncateFile(I)I
.end method
