.class public interface abstract Lcom/google/common/util/concurrent/ListenableFuture;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Future;


# virtual methods
.method public abstract dpunpe(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
.end method
