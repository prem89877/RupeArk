.class public final synthetic Lo/adinrnuie;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/npdkdr;


# instance fields
.field public final synthetic dikdannunk:I

.field public final synthetic rpupp:Lo/npdkdr;


# direct methods
.method public synthetic constructor <init>(ILo/npdkdr;)V
    .locals 0

    .line 1
    iput p1, p0, Lo/adinrnuie;->dikdannunk:I

    iput-object p2, p0, Lo/adinrnuie;->rpupp:Lo/npdkdr;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final kikaa(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, Lo/adinrnuie;->dikdannunk:I

    .line 2
    .line 3
    iget-object p0, p0, Lo/adinrnuie;->rpupp:Lo/npdkdr;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Ljava/lang/Long;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    invoke-interface {p0, p1}, Lo/npdkdr;->kikaa(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0

    .line 18
    :pswitch_0
    check-cast p1, Lo/edkddpkpkuen;

    .line 19
    .line 20
    invoke-interface {p0, p1}, Lo/npdkdr;->kikaa(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    check-cast p0, Lo/uakrpdkiukn;

    .line 25
    .line 26
    sget-object p1, Lo/rrrdipeirp;->pepeunri:Ljava/lang/Object;

    .line 27
    .line 28
    monitor-enter p1

    .line 29
    :try_start_0
    sget-object v0, Lo/rrrdipeirp;->irkari:Lo/edkddpkpkuen;

    .line 30
    .line 31
    invoke-virtual {p0}, Lo/uakrpdkiukn;->adadnadrr()J

    .line 32
    .line 33
    .line 34
    move-result-wide v1

    .line 35
    invoke-virtual {v0, v1, v2}, Lo/edkddpkpkuen;->adadnadrr(J)Lo/edkddpkpkuen;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    sput-object v0, Lo/rrrdipeirp;->irkari:Lo/edkddpkpkuen;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 40
    .line 41
    monitor-exit p1

    .line 42
    return-object p0

    .line 43
    :catchall_0
    move-exception p0

    .line 44
    monitor-exit p1

    .line 45
    throw p0

    .line 46
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
