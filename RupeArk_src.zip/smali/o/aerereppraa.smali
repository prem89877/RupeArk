.class public final Lo/aerereppraa;
.super Lo/eedpierrup;
.source "SourceFile"


# static fields
.field private static final zzg:Lo/aerereppraa;

.field private static volatile zzh:Lo/irepdkpa;


# instance fields
.field private zzb:I

.field private zze:Lo/irrpki;

.field private zzf:Lo/ikrraapuk;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lo/aerereppraa;

    .line 2
    .line 3
    invoke-direct {v0}, Lo/eedpierrup;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lo/aerereppraa;->zzg:Lo/aerereppraa;

    .line 7
    .line 8
    const-class v1, Lo/aerereppraa;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lo/eedpierrup;->ekrraa(Ljava/lang/Class;Lo/eedpierrup;)V

    .line 11
    .line 12
    .line 13
    return-void
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
.end method

.method public static peridinue()Lo/iuririnn;
    .locals 1

    .line 1
    sget-object v0, Lo/aerereppraa;->zzg:Lo/aerereppraa;

    .line 2
    .line 3
    invoke-virtual {v0}, Lo/eedpierrup;->kikaa()Lo/rdidep;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lo/iuririnn;

    .line 8
    .line 9
    return-object v0
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
.end method

.method public static ppipdprui([BLo/ipduk;)Lo/aerereppraa;
    .locals 1

    .line 1
    sget-object v0, Lo/aerereppraa;->zzg:Lo/aerereppraa;

    .line 2
    .line 3
    invoke-static {v0, p0, p1}, Lo/eedpierrup;->iiunkaippn(Lo/eedpierrup;[BLo/ipduk;)Lo/eedpierrup;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lo/aerereppraa;

    .line 8
    .line 9
    return-object p0
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
.end method


# virtual methods
.method public final ieddke(I)Ljava/lang/Object;
    .locals 2

    .line 1
    add-int/lit8 p1, p1, -0x1

    .line 2
    .line 3
    if-eqz p1, :cond_7

    .line 4
    .line 5
    const/4 p0, 0x2

    .line 6
    if-eq p1, p0, :cond_6

    .line 7
    .line 8
    const/4 p0, 0x3

    .line 9
    if-eq p1, p0, :cond_5

    .line 10
    .line 11
    const/4 p0, 0x4

    .line 12
    if-eq p1, p0, :cond_4

    .line 13
    .line 14
    const/4 p0, 0x5

    .line 15
    if-eq p1, p0, :cond_3

    .line 16
    .line 17
    const/4 p0, 0x6

    .line 18
    if-ne p1, p0, :cond_2

    .line 19
    .line 20
    sget-object p0, Lo/aerereppraa;->zzh:Lo/irepdkpa;

    .line 21
    .line 22
    if-nez p0, :cond_1

    .line 23
    .line 24
    const-class p1, Lo/aerereppraa;

    .line 25
    .line 26
    monitor-enter p1

    .line 27
    :try_start_0
    sget-object p0, Lo/aerereppraa;->zzh:Lo/irepdkpa;

    .line 28
    .line 29
    if-nez p0, :cond_0

    .line 30
    .line 31
    new-instance p0, Lo/uedp;

    .line 32
    .line 33
    sget-object v0, Lo/aerereppraa;->zzg:Lo/aerereppraa;

    .line 34
    .line 35
    invoke-direct {p0, v0}, Lo/uedp;-><init>(Lo/eedpierrup;)V

    .line 36
    .line 37
    .line 38
    sput-object p0, Lo/aerereppraa;->zzh:Lo/irepdkpa;

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :catchall_0
    move-exception p0

    .line 42
    goto :goto_1

    .line 43
    :cond_0
    :goto_0
    monitor-exit p1

    .line 44
    return-object p0

    .line 45
    :goto_1
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    throw p0

    .line 47
    :cond_1
    return-object p0

    .line 48
    :cond_2
    const/4 p0, 0x0

    .line 49
    throw p0

    .line 50
    :cond_3
    sget-object p0, Lo/aerereppraa;->zzg:Lo/aerereppraa;

    .line 51
    .line 52
    return-object p0

    .line 53
    :cond_4
    new-instance p0, Lo/iuririnn;

    .line 54
    .line 55
    sget-object p1, Lo/aerereppraa;->zzg:Lo/aerereppraa;

    .line 56
    .line 57
    invoke-direct {p0, p1}, Lo/rdidep;-><init>(Lo/eedpierrup;)V

    .line 58
    .line 59
    .line 60
    return-object p0

    .line 61
    :cond_5
    new-instance p0, Lo/aerereppraa;

    .line 62
    .line 63
    invoke-direct {p0}, Lo/eedpierrup;-><init>()V

    .line 64
    .line 65
    .line 66
    return-object p0

    .line 67
    :cond_6
    const-string p0, "zzb"

    .line 68
    .line 69
    const-string p1, "zze"

    .line 70
    .line 71
    const-string v0, "zzf"

    .line 72
    .line 73
    filled-new-array {p0, p1, v0}, [Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    sget-object p1, Lo/aerereppraa;->zzg:Lo/aerereppraa;

    .line 78
    .line 79
    const-string v0, "\u0004\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u1009\u0000\u0002\u1009\u0001"

    .line 80
    .line 81
    new-instance v1, Lo/nuirdpaeu;

    .line 82
    .line 83
    invoke-direct {v1, p1, v0, p0}, Lo/nuirdpaeu;-><init>(Lo/uukddp;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    return-object v1

    .line 87
    :cond_7
    const/4 p0, 0x1

    .line 88
    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 89
    .line 90
    .line 91
    move-result-object p0

    .line 92
    return-object p0
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
.end method

.method public final kaepinunirek()Lo/ikrraapuk;
    .locals 0

    .line 1
    iget-object p0, p0, Lo/aerereppraa;->zzf:Lo/ikrraapuk;

    .line 2
    .line 3
    if-nez p0, :cond_0

    .line 4
    .line 5
    invoke-static {}, Lo/ikrraapuk;->nnnpkknidue()Lo/ikrraapuk;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    :cond_0
    return-object p0
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
.end method

.method public final nnnpkknidue()Lo/irrpki;
    .locals 0

    .line 1
    iget-object p0, p0, Lo/aerereppraa;->zze:Lo/irrpki;

    .line 2
    .line 3
    if-nez p0, :cond_0

    .line 4
    .line 5
    invoke-static {}, Lo/irrpki;->aeprpu()Lo/irrpki;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    :cond_0
    return-object p0
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
.end method

.method public final synthetic uarduadkp(Lo/irrpki;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lo/aerereppraa;->zze:Lo/irrpki;

    .line 2
    .line 3
    iget p1, p0, Lo/aerereppraa;->zzb:I

    .line 4
    .line 5
    or-int/lit8 p1, p1, 0x1

    .line 6
    .line 7
    iput p1, p0, Lo/aerereppraa;->zzb:I

    .line 8
    .line 9
    return-void
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
.end method
