.class public final synthetic Lo/aadprau;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/AutoCloseable;


# instance fields
.field public final synthetic dikdannunk:Lo/andrnau;

.field public final synthetic rpupp:Lo/pnreanadnad;


# direct methods
.method public synthetic constructor <init>(Lo/andrnau;Lo/pnreanadnad;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lo/aadprau;->dikdannunk:Lo/andrnau;

    iput-object p2, p0, Lo/aadprau;->rpupp:Lo/pnreanadnad;

    return-void
.end method


# virtual methods
.method public final close()V
    .locals 1

    .line 1
    iget-object v0, p0, Lo/aadprau;->dikdannunk:Lo/andrnau;

    .line 2
    .line 3
    iget-object p0, p0, Lo/aadprau;->rpupp:Lo/pnreanadnad;

    .line 4
    .line 5
    invoke-virtual {v0, p0}, Lo/andrnau;->aiupunrka(Lo/idiaidukua;)V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
.end method
