.class public final synthetic Lo/anneraupp;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lo/nkkiurdaipku;
.implements Lo/ndkiaun;
.implements Lo/rieuadnr;
.implements Lo/ikarkdu;
.implements Lo/enepekekiur;


# instance fields
.field public final synthetic aaidaieneai:Ljava/lang/Object;

.field public final synthetic aareerpeir:Ljava/lang/Object;

.field public final synthetic dikdannunk:I

.field public final synthetic rpupp:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p4, p0, Lo/anneraupp;->dikdannunk:I

    iput-object p1, p0, Lo/anneraupp;->rpupp:Ljava/lang/Object;

    iput-object p2, p0, Lo/anneraupp;->aareerpeir:Ljava/lang/Object;

    iput-object p3, p0, Lo/anneraupp;->aaidaieneai:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lo/anneraupp;->dikdannunk:I

    .line 4
    .line 5
    const-string v2, "bytes"

    .line 6
    .line 7
    const-string v3, "PRAGMA page_size"

    .line 8
    .line 9
    const-string v4, "PRAGMA page_count"

    .line 10
    .line 11
    const/4 v5, 0x6

    .line 12
    const/4 v6, 0x5

    .line 13
    const/4 v7, 0x4

    .line 14
    const/4 v8, 0x3

    .line 15
    sget-object v9, Lo/uuaeniu;->aaidaieneai:Lo/uuaeniu;

    .line 16
    .line 17
    const/4 v10, 0x2

    .line 18
    const/4 v12, 0x0

    .line 19
    const/4 v13, 0x1

    .line 20
    iget-object v14, v0, Lo/anneraupp;->aaidaieneai:Ljava/lang/Object;

    .line 21
    .line 22
    iget-object v15, v0, Lo/anneraupp;->aareerpeir:Ljava/lang/Object;

    .line 23
    .line 24
    iget-object v0, v0, Lo/anneraupp;->rpupp:Ljava/lang/Object;

    .line 25
    .line 26
    packed-switch v1, :pswitch_data_0

    .line 27
    .line 28
    .line 29
    check-cast v0, Lo/eidak;

    .line 30
    .line 31
    check-cast v15, Ljava/util/HashMap;

    .line 32
    .line 33
    check-cast v14, Lo/rnppe;

    .line 34
    .line 35
    iget-object v1, v14, Lo/rnppe;->aaidaieneai:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v1, Ljava/util/ArrayList;

    .line 38
    .line 39
    move-object/from16 v2, p1

    .line 40
    .line 41
    check-cast v2, Landroid/database/Cursor;

    .line 42
    .line 43
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    :goto_0
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    .line 47
    .line 48
    .line 49
    move-result v11

    .line 50
    if-eqz v11, :cond_8

    .line 51
    .line 52
    invoke-interface {v2, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v11

    .line 56
    invoke-interface {v2, v13}, Landroid/database/Cursor;->getInt(I)I

    .line 57
    .line 58
    .line 59
    move-result v12

    .line 60
    sget-object v17, Lo/uuaeniu;->rpupp:Lo/uuaeniu;

    .line 61
    .line 62
    if-nez v12, :cond_0

    .line 63
    .line 64
    :goto_1
    move-object/from16 v5, v17

    .line 65
    .line 66
    goto :goto_2

    .line 67
    :cond_0
    if-ne v12, v13, :cond_1

    .line 68
    .line 69
    sget-object v17, Lo/uuaeniu;->aareerpeir:Lo/uuaeniu;

    .line 70
    .line 71
    goto :goto_1

    .line 72
    :cond_1
    if-ne v12, v10, :cond_2

    .line 73
    .line 74
    move-object v5, v9

    .line 75
    goto :goto_2

    .line 76
    :cond_2
    if-ne v12, v8, :cond_3

    .line 77
    .line 78
    sget-object v17, Lo/uuaeniu;->iureria:Lo/uuaeniu;

    .line 79
    .line 80
    goto :goto_1

    .line 81
    :cond_3
    if-ne v12, v7, :cond_4

    .line 82
    .line 83
    sget-object v17, Lo/uuaeniu;->rrkrpe:Lo/uuaeniu;

    .line 84
    .line 85
    goto :goto_1

    .line 86
    :cond_4
    if-ne v12, v6, :cond_5

    .line 87
    .line 88
    sget-object v17, Lo/uuaeniu;->ikpeepa:Lo/uuaeniu;

    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_5
    if-ne v12, v5, :cond_6

    .line 92
    .line 93
    sget-object v17, Lo/uuaeniu;->riuiea:Lo/uuaeniu;

    .line 94
    .line 95
    goto :goto_1

    .line 96
    :cond_6
    const-string v5, "%n is not valid. No matched LogEventDropped-Reason found. Treated it as REASON_UNKNOWN"

    .line 97
    .line 98
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 99
    .line 100
    .line 101
    move-result-object v12

    .line 102
    const-string v6, "SQLiteEventStore"

    .line 103
    .line 104
    invoke-static {v6, v5, v12}, Lo/nkeiak;->kapkrnkiiiea(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    goto :goto_1

    .line 108
    :goto_2
    invoke-interface {v2, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 109
    .line 110
    .line 111
    move-result-wide v7

    .line 112
    invoke-virtual {v15, v11}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result v17

    .line 116
    if-nez v17, :cond_7

    .line 117
    .line 118
    new-instance v6, Ljava/util/ArrayList;

    .line 119
    .line 120
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v15, v11, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    :cond_7
    invoke-virtual {v15, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v6

    .line 130
    check-cast v6, Ljava/util/List;

    .line 131
    .line 132
    new-instance v11, Lo/edapapukip;

    .line 133
    .line 134
    invoke-direct {v11, v7, v8, v5}, Lo/edapapukip;-><init>(JLo/uuaeniu;)V

    .line 135
    .line 136
    .line 137
    invoke-interface {v6, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    const/4 v5, 0x6

    .line 141
    const/4 v6, 0x5

    .line 142
    const/4 v7, 0x4

    .line 143
    const/4 v8, 0x3

    .line 144
    const/4 v12, 0x0

    .line 145
    goto :goto_0

    .line 146
    :cond_8
    invoke-virtual {v15}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 147
    .line 148
    .line 149
    move-result-object v2

    .line 150
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 151
    .line 152
    .line 153
    move-result-object v2

    .line 154
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 155
    .line 156
    .line 157
    move-result v5

    .line 158
    if-eqz v5, :cond_9

    .line 159
    .line 160
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v5

    .line 164
    check-cast v5, Ljava/util/Map$Entry;

    .line 165
    .line 166
    sget v6, Lo/idakenrae;->pepeunri:I

    .line 167
    .line 168
    new-instance v6, Ljava/util/ArrayList;

    .line 169
    .line 170
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 171
    .line 172
    .line 173
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v6

    .line 177
    check-cast v6, Ljava/lang/String;

    .line 178
    .line 179
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    move-result-object v5

    .line 183
    check-cast v5, Ljava/util/List;

    .line 184
    .line 185
    new-instance v7, Lo/idakenrae;

    .line 186
    .line 187
    invoke-static {v5}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 188
    .line 189
    .line 190
    move-result-object v5

    .line 191
    invoke-direct {v7, v6, v5}, Lo/idakenrae;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 192
    .line 193
    .line 194
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 195
    .line 196
    .line 197
    goto :goto_3

    .line 198
    :cond_9
    iget-object v2, v0, Lo/eidak;->rpupp:Lo/narpepprui;

    .line 199
    .line 200
    invoke-interface {v2}, Lo/narpepprui;->nkpkuui()J

    .line 201
    .line 202
    .line 203
    move-result-wide v5

    .line 204
    new-instance v2, Lo/idikd;

    .line 205
    .line 206
    invoke-direct {v2, v5, v6}, Lo/idikd;-><init>(J)V

    .line 207
    .line 208
    .line 209
    invoke-virtual {v0, v2}, Lo/eidak;->ndpnikda(Lo/enepekekiur;)Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object v2

    .line 213
    check-cast v2, Lo/epieak;

    .line 214
    .line 215
    iput-object v2, v14, Lo/rnppe;->aareerpeir:Ljava/lang/Object;

    .line 216
    .line 217
    invoke-virtual {v0}, Lo/eidak;->dpunpe()Landroid/database/sqlite/SQLiteDatabase;

    .line 218
    .line 219
    .line 220
    move-result-object v2

    .line 221
    invoke-virtual {v2, v4}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    .line 222
    .line 223
    .line 224
    move-result-object v2

    .line 225
    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteStatement;->simpleQueryForLong()J

    .line 226
    .line 227
    .line 228
    move-result-wide v4

    .line 229
    invoke-virtual {v0}, Lo/eidak;->dpunpe()Landroid/database/sqlite/SQLiteDatabase;

    .line 230
    .line 231
    .line 232
    move-result-object v2

    .line 233
    invoke-virtual {v2, v3}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    .line 234
    .line 235
    .line 236
    move-result-object v2

    .line 237
    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteStatement;->simpleQueryForLong()J

    .line 238
    .line 239
    .line 240
    move-result-wide v2

    .line 241
    mul-long/2addr v2, v4

    .line 242
    sget-object v4, Lo/rkkiknpipe;->aiupunrka:Lo/rkkiknpipe;

    .line 243
    .line 244
    iget-wide v4, v4, Lo/rkkiknpipe;->dpunpe:J

    .line 245
    .line 246
    new-instance v6, Lo/pikipauu;

    .line 247
    .line 248
    invoke-direct {v6, v2, v3, v4, v5}, Lo/pikipauu;-><init>(JJ)V

    .line 249
    .line 250
    .line 251
    new-instance v2, Lo/adniudanna;

    .line 252
    .line 253
    invoke-direct {v2, v6}, Lo/adniudanna;-><init>(Lo/pikipauu;)V

    .line 254
    .line 255
    .line 256
    iput-object v2, v14, Lo/rnppe;->iureria:Ljava/lang/Object;

    .line 257
    .line 258
    iget-object v0, v0, Lo/eidak;->iureria:Lo/endiune;

    .line 259
    .line 260
    invoke-interface {v0}, Lo/endiune;->get()Ljava/lang/Object;

    .line 261
    .line 262
    .line 263
    move-result-object v0

    .line 264
    check-cast v0, Ljava/lang/String;

    .line 265
    .line 266
    iput-object v0, v14, Lo/rnppe;->rpupp:Ljava/lang/Object;

    .line 267
    .line 268
    new-instance v0, Lo/peiip;

    .line 269
    .line 270
    iget-object v2, v14, Lo/rnppe;->aareerpeir:Ljava/lang/Object;

    .line 271
    .line 272
    check-cast v2, Lo/epieak;

    .line 273
    .line 274
    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 275
    .line 276
    .line 277
    move-result-object v1

    .line 278
    iget-object v3, v14, Lo/rnppe;->iureria:Ljava/lang/Object;

    .line 279
    .line 280
    check-cast v3, Lo/adniudanna;

    .line 281
    .line 282
    iget-object v4, v14, Lo/rnppe;->rpupp:Ljava/lang/Object;

    .line 283
    .line 284
    check-cast v4, Ljava/lang/String;

    .line 285
    .line 286
    invoke-direct {v0, v2, v1, v3, v4}, Lo/peiip;-><init>(Lo/epieak;Ljava/util/List;Lo/adniudanna;Ljava/lang/String;)V

    .line 287
    .line 288
    .line 289
    return-object v0

    .line 290
    :pswitch_0
    check-cast v0, Lo/eidak;

    .line 291
    .line 292
    check-cast v15, Ljava/util/ArrayList;

    .line 293
    .line 294
    check-cast v14, Lo/ekunerpp;

    .line 295
    .line 296
    move-object/from16 v1, p1

    .line 297
    .line 298
    check-cast v1, Landroid/database/Cursor;

    .line 299
    .line 300
    :goto_4
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    .line 301
    .line 302
    .line 303
    move-result v3

    .line 304
    if-eqz v3, :cond_16

    .line 305
    .line 306
    const/4 v3, 0x0

    .line 307
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getLong(I)J

    .line 308
    .line 309
    .line 310
    move-result-wide v4

    .line 311
    const/4 v3, 0x7

    .line 312
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getInt(I)I

    .line 313
    .line 314
    .line 315
    move-result v3

    .line 316
    if-eqz v3, :cond_a

    .line 317
    .line 318
    move v3, v13

    .line 319
    goto :goto_5

    .line 320
    :cond_a
    const/4 v3, 0x0

    .line 321
    :goto_5
    new-instance v7, Lo/euepa;

    .line 322
    .line 323
    invoke-direct {v7}, Lo/euepa;-><init>()V

    .line 324
    .line 325
    .line 326
    new-instance v6, Ljava/util/HashMap;

    .line 327
    .line 328
    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    .line 329
    .line 330
    .line 331
    iput-object v6, v7, Lo/euepa;->nkpkuui:Ljava/lang/Object;

    .line 332
    .line 333
    invoke-interface {v1, v13}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 334
    .line 335
    .line 336
    move-result-object v6

    .line 337
    if-eqz v6, :cond_15

    .line 338
    .line 339
    iput-object v6, v7, Lo/euepa;->dpeakapiakpa:Ljava/lang/Object;

    .line 340
    .line 341
    invoke-interface {v1, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 342
    .line 343
    .line 344
    move-result-wide v8

    .line 345
    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 346
    .line 347
    .line 348
    move-result-object v6

    .line 349
    iput-object v6, v7, Lo/euepa;->adadnadrr:Ljava/lang/Object;

    .line 350
    .line 351
    const/4 v12, 0x3

    .line 352
    invoke-interface {v1, v12}, Landroid/database/Cursor;->getLong(I)J

    .line 353
    .line 354
    .line 355
    move-result-wide v8

    .line 356
    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 357
    .line 358
    .line 359
    move-result-object v6

    .line 360
    iput-object v6, v7, Lo/euepa;->dedr:Ljava/lang/Object;

    .line 361
    .line 362
    if-eqz v3, :cond_c

    .line 363
    .line 364
    new-instance v3, Lo/edrpukane;

    .line 365
    .line 366
    const/4 v6, 0x4

    .line 367
    invoke-interface {v1, v6}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 368
    .line 369
    .line 370
    move-result-object v8

    .line 371
    if-nez v8, :cond_b

    .line 372
    .line 373
    sget-object v8, Lo/eidak;->rrkrpe:Lo/npnra;

    .line 374
    .line 375
    :goto_6
    const/4 v9, 0x5

    .line 376
    goto :goto_7

    .line 377
    :cond_b
    new-instance v9, Lo/npnra;

    .line 378
    .line 379
    invoke-direct {v9, v8}, Lo/npnra;-><init>(Ljava/lang/String;)V

    .line 380
    .line 381
    .line 382
    move-object v8, v9

    .line 383
    goto :goto_6

    .line 384
    :goto_7
    invoke-interface {v1, v9}, Landroid/database/Cursor;->getBlob(I)[B

    .line 385
    .line 386
    .line 387
    move-result-object v6

    .line 388
    invoke-direct {v3, v8, v6}, Lo/edrpukane;-><init>(Lo/npnra;[B)V

    .line 389
    .line 390
    .line 391
    iput-object v3, v7, Lo/euepa;->aiupunrka:Ljava/lang/Object;

    .line 392
    .line 393
    move-object/from16 v22, v0

    .line 394
    .line 395
    const/16 v21, 0x0

    .line 396
    .line 397
    :goto_8
    const/4 v0, 0x6

    .line 398
    goto/16 :goto_c

    .line 399
    .line 400
    :cond_c
    const/4 v9, 0x5

    .line 401
    new-instance v3, Lo/edrpukane;

    .line 402
    .line 403
    const/4 v6, 0x4

    .line 404
    invoke-interface {v1, v6}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 405
    .line 406
    .line 407
    move-result-object v8

    .line 408
    if-nez v8, :cond_d

    .line 409
    .line 410
    sget-object v8, Lo/eidak;->rrkrpe:Lo/npnra;

    .line 411
    .line 412
    goto :goto_9

    .line 413
    :cond_d
    new-instance v6, Lo/npnra;

    .line 414
    .line 415
    invoke-direct {v6, v8}, Lo/npnra;-><init>(Ljava/lang/String;)V

    .line 416
    .line 417
    .line 418
    move-object v8, v6

    .line 419
    :goto_9
    invoke-virtual {v0}, Lo/eidak;->dpunpe()Landroid/database/sqlite/SQLiteDatabase;

    .line 420
    .line 421
    .line 422
    move-result-object v18

    .line 423
    filled-new-array {v2}, [Ljava/lang/String;

    .line 424
    .line 425
    .line 426
    move-result-object v20

    .line 427
    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 428
    .line 429
    .line 430
    move-result-object v6

    .line 431
    filled-new-array {v6}, [Ljava/lang/String;

    .line 432
    .line 433
    .line 434
    move-result-object v22

    .line 435
    const/16 v24, 0x0

    .line 436
    .line 437
    const-string v25, "sequence_num"

    .line 438
    .line 439
    const-string v19, "event_payloads"

    .line 440
    .line 441
    const-string v21, "event_id = ?"

    .line 442
    .line 443
    const/16 v23, 0x0

    .line 444
    .line 445
    invoke-virtual/range {v18 .. v25}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    .line 446
    .line 447
    .line 448
    move-result-object v6

    .line 449
    :try_start_0
    move-object v9, v6

    .line 450
    check-cast v9, Landroid/database/Cursor;

    .line 451
    .line 452
    new-instance v10, Ljava/util/ArrayList;

    .line 453
    .line 454
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 455
    .line 456
    .line 457
    const/4 v12, 0x0

    .line 458
    :goto_a
    invoke-interface {v9}, Landroid/database/Cursor;->moveToNext()Z

    .line 459
    .line 460
    .line 461
    move-result v20

    .line 462
    if-eqz v20, :cond_e

    .line 463
    .line 464
    const/4 v13, 0x0

    .line 465
    const/16 v21, 0x0

    .line 466
    .line 467
    invoke-interface {v9, v13}, Landroid/database/Cursor;->getBlob(I)[B

    .line 468
    .line 469
    .line 470
    move-result-object v11

    .line 471
    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 472
    .line 473
    .line 474
    array-length v11, v11

    .line 475
    add-int/2addr v12, v11

    .line 476
    const/4 v13, 0x1

    .line 477
    goto :goto_a

    .line 478
    :cond_e
    const/16 v21, 0x0

    .line 479
    .line 480
    new-array v9, v12, [B

    .line 481
    .line 482
    const/4 v11, 0x0

    .line 483
    const/4 v12, 0x0

    .line 484
    :goto_b
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 485
    .line 486
    .line 487
    move-result v13

    .line 488
    if-ge v11, v13, :cond_f

    .line 489
    .line 490
    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 491
    .line 492
    .line 493
    move-result-object v13

    .line 494
    check-cast v13, [B

    .line 495
    .line 496
    move-object/from16 v22, v0

    .line 497
    .line 498
    array-length v0, v13
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 499
    move-object/from16 p1, v6

    .line 500
    .line 501
    const/4 v6, 0x0

    .line 502
    :try_start_1
    invoke-static {v13, v6, v9, v12, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 503
    .line 504
    .line 505
    array-length v0, v13
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 506
    add-int/2addr v12, v0

    .line 507
    add-int/lit8 v11, v11, 0x1

    .line 508
    .line 509
    move-object/from16 v6, p1

    .line 510
    .line 511
    move-object/from16 v0, v22

    .line 512
    .line 513
    goto :goto_b

    .line 514
    :catchall_0
    move-exception v0

    .line 515
    goto :goto_d

    .line 516
    :cond_f
    move-object/from16 v22, v0

    .line 517
    .line 518
    move-object/from16 p1, v6

    .line 519
    .line 520
    invoke-interface/range {p1 .. p1}, Landroid/database/Cursor;->close()V

    .line 521
    .line 522
    .line 523
    invoke-direct {v3, v8, v9}, Lo/edrpukane;-><init>(Lo/npnra;[B)V

    .line 524
    .line 525
    .line 526
    iput-object v3, v7, Lo/euepa;->aiupunrka:Ljava/lang/Object;

    .line 527
    .line 528
    goto/16 :goto_8

    .line 529
    .line 530
    :goto_c
    invoke-interface {v1, v0}, Landroid/database/Cursor;->isNull(I)Z

    .line 531
    .line 532
    .line 533
    move-result v3

    .line 534
    if-nez v3, :cond_10

    .line 535
    .line 536
    invoke-interface {v1, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 537
    .line 538
    .line 539
    move-result v3

    .line 540
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 541
    .line 542
    .line 543
    move-result-object v3

    .line 544
    iput-object v3, v7, Lo/euepa;->irkari:Ljava/lang/Object;

    .line 545
    .line 546
    :cond_10
    const/16 v3, 0x8

    .line 547
    .line 548
    invoke-interface {v1, v3}, Landroid/database/Cursor;->isNull(I)Z

    .line 549
    .line 550
    .line 551
    move-result v6

    .line 552
    if-nez v6, :cond_11

    .line 553
    .line 554
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getInt(I)I

    .line 555
    .line 556
    .line 557
    move-result v3

    .line 558
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 559
    .line 560
    .line 561
    move-result-object v3

    .line 562
    iput-object v3, v7, Lo/euepa;->iiunkaippn:Ljava/lang/Object;

    .line 563
    .line 564
    :cond_11
    const/16 v3, 0x9

    .line 565
    .line 566
    invoke-interface {v1, v3}, Landroid/database/Cursor;->isNull(I)Z

    .line 567
    .line 568
    .line 569
    move-result v6

    .line 570
    if-nez v6, :cond_12

    .line 571
    .line 572
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 573
    .line 574
    .line 575
    move-result-object v3

    .line 576
    iput-object v3, v7, Lo/euepa;->pepeunri:Ljava/lang/Object;

    .line 577
    .line 578
    :cond_12
    const/16 v3, 0xa

    .line 579
    .line 580
    invoke-interface {v1, v3}, Landroid/database/Cursor;->isNull(I)Z

    .line 581
    .line 582
    .line 583
    move-result v6

    .line 584
    if-nez v6, :cond_13

    .line 585
    .line 586
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getBlob(I)[B

    .line 587
    .line 588
    .line 589
    move-result-object v3

    .line 590
    iput-object v3, v7, Lo/euepa;->kikaa:Ljava/lang/Object;

    .line 591
    .line 592
    :cond_13
    const/16 v3, 0xb

    .line 593
    .line 594
    invoke-interface {v1, v3}, Landroid/database/Cursor;->isNull(I)Z

    .line 595
    .line 596
    .line 597
    move-result v6

    .line 598
    if-nez v6, :cond_14

    .line 599
    .line 600
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getBlob(I)[B

    .line 601
    .line 602
    .line 603
    move-result-object v3

    .line 604
    iput-object v3, v7, Lo/euepa;->uikrdedi:Ljava/lang/Object;

    .line 605
    .line 606
    :cond_14
    invoke-virtual {v7}, Lo/euepa;->pepeunri()Lo/durdkeeur;

    .line 607
    .line 608
    .line 609
    move-result-object v3

    .line 610
    new-instance v6, Lo/niiek;

    .line 611
    .line 612
    invoke-direct {v6, v4, v5, v14, v3}, Lo/niiek;-><init>(JLo/ekunerpp;Lo/durdkeeur;)V

    .line 613
    .line 614
    .line 615
    invoke-virtual {v15, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 616
    .line 617
    .line 618
    move-object/from16 v0, v22

    .line 619
    .line 620
    const/4 v10, 0x2

    .line 621
    const/4 v13, 0x1

    .line 622
    goto/16 :goto_4

    .line 623
    .line 624
    :catchall_1
    move-exception v0

    .line 625
    move-object/from16 p1, v6

    .line 626
    .line 627
    :goto_d
    invoke-interface/range {p1 .. p1}, Landroid/database/Cursor;->close()V

    .line 628
    .line 629
    .line 630
    throw v0

    .line 631
    :cond_15
    const/16 v21, 0x0

    .line 632
    .line 633
    const-string v0, "Null transportName"

    .line 634
    .line 635
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 636
    .line 637
    .line 638
    goto :goto_e

    .line 639
    :cond_16
    const/16 v21, 0x0

    .line 640
    .line 641
    :goto_e
    return-object v21

    .line 642
    :pswitch_1
    const/16 v21, 0x0

    .line 643
    .line 644
    check-cast v0, Lo/eidak;

    .line 645
    .line 646
    check-cast v15, Lo/durdkeeur;

    .line 647
    .line 648
    iget-object v1, v15, Lo/durdkeeur;->pepeunri:Lo/edrpukane;

    .line 649
    .line 650
    iget-object v5, v15, Lo/durdkeeur;->dpunpe:Ljava/lang/String;

    .line 651
    .line 652
    check-cast v14, Lo/ekunerpp;

    .line 653
    .line 654
    move-object/from16 v6, p1

    .line 655
    .line 656
    check-cast v6, Landroid/database/sqlite/SQLiteDatabase;

    .line 657
    .line 658
    const/16 v16, 0x0

    .line 659
    .line 660
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 661
    .line 662
    .line 663
    move-result-object v7

    .line 664
    invoke-virtual {v0}, Lo/eidak;->dpunpe()Landroid/database/sqlite/SQLiteDatabase;

    .line 665
    .line 666
    .line 667
    move-result-object v8

    .line 668
    invoke-virtual {v8, v4}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    .line 669
    .line 670
    .line 671
    move-result-object v4

    .line 672
    invoke-virtual {v4}, Landroid/database/sqlite/SQLiteStatement;->simpleQueryForLong()J

    .line 673
    .line 674
    .line 675
    move-result-wide v10

    .line 676
    invoke-virtual {v0}, Lo/eidak;->dpunpe()Landroid/database/sqlite/SQLiteDatabase;

    .line 677
    .line 678
    .line 679
    move-result-object v4

    .line 680
    invoke-virtual {v4, v3}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    .line 681
    .line 682
    .line 683
    move-result-object v3

    .line 684
    invoke-virtual {v3}, Landroid/database/sqlite/SQLiteStatement;->simpleQueryForLong()J

    .line 685
    .line 686
    .line 687
    move-result-wide v3

    .line 688
    mul-long/2addr v3, v10

    .line 689
    iget-object v8, v0, Lo/eidak;->aaidaieneai:Lo/rkkiknpipe;

    .line 690
    .line 691
    iget-wide v10, v8, Lo/rkkiknpipe;->dpunpe:J

    .line 692
    .line 693
    cmp-long v3, v3, v10

    .line 694
    .line 695
    if-ltz v3, :cond_17

    .line 696
    .line 697
    const-wide/16 v1, 0x1

    .line 698
    .line 699
    invoke-virtual {v0, v1, v2, v9, v5}, Lo/eidak;->ukin(JLo/uuaeniu;Ljava/lang/String;)V

    .line 700
    .line 701
    .line 702
    const-wide/16 v0, -0x1

    .line 703
    .line 704
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 705
    .line 706
    .line 707
    move-result-object v0

    .line 708
    goto/16 :goto_14

    .line 709
    .line 710
    :cond_17
    invoke-static {v6, v14}, Lo/eidak;->adadnadrr(Landroid/database/sqlite/SQLiteDatabase;Lo/ekunerpp;)Ljava/lang/Long;

    .line 711
    .line 712
    .line 713
    move-result-object v0

    .line 714
    if-eqz v0, :cond_18

    .line 715
    .line 716
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 717
    .line 718
    .line 719
    move-result-wide v3

    .line 720
    goto :goto_f

    .line 721
    :cond_18
    new-instance v0, Landroid/content/ContentValues;

    .line 722
    .line 723
    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 724
    .line 725
    .line 726
    const-string v3, "backend_name"

    .line 727
    .line 728
    iget-object v4, v14, Lo/ekunerpp;->dpunpe:Ljava/lang/String;

    .line 729
    .line 730
    invoke-virtual {v0, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 731
    .line 732
    .line 733
    iget-object v3, v14, Lo/ekunerpp;->pepeunri:Lo/ikknaarr;

    .line 734
    .line 735
    invoke-static {v3}, Lo/aeduidar;->dpunpe(Lo/ikknaarr;)I

    .line 736
    .line 737
    .line 738
    move-result v3

    .line 739
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 740
    .line 741
    .line 742
    move-result-object v3

    .line 743
    const-string v4, "priority"

    .line 744
    .line 745
    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 746
    .line 747
    .line 748
    const-string v3, "next_request_ms"

    .line 749
    .line 750
    invoke-virtual {v0, v3, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 751
    .line 752
    .line 753
    iget-object v3, v14, Lo/ekunerpp;->dpeakapiakpa:[B

    .line 754
    .line 755
    if-eqz v3, :cond_19

    .line 756
    .line 757
    const-string v4, "extras"

    .line 758
    .line 759
    const/4 v13, 0x0

    .line 760
    invoke-static {v3, v13}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 761
    .line 762
    .line 763
    move-result-object v3

    .line 764
    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 765
    .line 766
    .line 767
    :cond_19
    const-string v3, "transport_contexts"

    .line 768
    .line 769
    move-object/from16 v4, v21

    .line 770
    .line 771
    invoke-virtual {v6, v3, v4, v0}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    .line 772
    .line 773
    .line 774
    move-result-wide v9

    .line 775
    move-wide v3, v9

    .line 776
    :goto_f
    iget v0, v8, Lo/rkkiknpipe;->iiunkaippn:I

    .line 777
    .line 778
    iget-object v8, v1, Lo/edrpukane;->dpeakapiakpa:[B

    .line 779
    .line 780
    array-length v9, v8

    .line 781
    if-gt v9, v0, :cond_1a

    .line 782
    .line 783
    const/4 v9, 0x1

    .line 784
    goto :goto_10

    .line 785
    :cond_1a
    const/4 v9, 0x0

    .line 786
    :goto_10
    new-instance v10, Landroid/content/ContentValues;

    .line 787
    .line 788
    invoke-direct {v10}, Landroid/content/ContentValues;-><init>()V

    .line 789
    .line 790
    .line 791
    const-string v11, "context_id"

    .line 792
    .line 793
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 794
    .line 795
    .line 796
    move-result-object v3

    .line 797
    invoke-virtual {v10, v11, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 798
    .line 799
    .line 800
    const-string v3, "transport_name"

    .line 801
    .line 802
    invoke-virtual {v10, v3, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 803
    .line 804
    .line 805
    iget-wide v3, v15, Lo/durdkeeur;->irkari:J

    .line 806
    .line 807
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 808
    .line 809
    .line 810
    move-result-object v3

    .line 811
    const-string v4, "timestamp_ms"

    .line 812
    .line 813
    invoke-virtual {v10, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 814
    .line 815
    .line 816
    iget-wide v3, v15, Lo/durdkeeur;->iiunkaippn:J

    .line 817
    .line 818
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 819
    .line 820
    .line 821
    move-result-object v3

    .line 822
    const-string v4, "uptime_ms"

    .line 823
    .line 824
    invoke-virtual {v10, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 825
    .line 826
    .line 827
    iget-object v1, v1, Lo/edrpukane;->dpunpe:Lo/npnra;

    .line 828
    .line 829
    iget-object v1, v1, Lo/npnra;->dpunpe:Ljava/lang/String;

    .line 830
    .line 831
    const-string v3, "payload_encoding"

    .line 832
    .line 833
    invoke-virtual {v10, v3, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 834
    .line 835
    .line 836
    const-string v1, "code"

    .line 837
    .line 838
    iget-object v3, v15, Lo/durdkeeur;->dpeakapiakpa:Ljava/lang/Integer;

    .line 839
    .line 840
    invoke-virtual {v10, v1, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 841
    .line 842
    .line 843
    const-string v1, "num_attempts"

    .line 844
    .line 845
    invoke-virtual {v10, v1, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 846
    .line 847
    .line 848
    const-string v1, "inline"

    .line 849
    .line 850
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 851
    .line 852
    .line 853
    move-result-object v3

    .line 854
    invoke-virtual {v10, v1, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Boolean;)V

    .line 855
    .line 856
    .line 857
    if-eqz v9, :cond_1b

    .line 858
    .line 859
    move-object v1, v8

    .line 860
    goto :goto_11

    .line 861
    :cond_1b
    const/4 v13, 0x0

    .line 862
    new-array v1, v13, [B

    .line 863
    .line 864
    :goto_11
    const-string v3, "payload"

    .line 865
    .line 866
    invoke-virtual {v10, v3, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    .line 867
    .line 868
    .line 869
    const-string v1, "product_id"

    .line 870
    .line 871
    iget-object v3, v15, Lo/durdkeeur;->adadnadrr:Ljava/lang/Integer;

    .line 872
    .line 873
    invoke-virtual {v10, v1, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 874
    .line 875
    .line 876
    const-string v1, "pseudonymous_id"

    .line 877
    .line 878
    iget-object v3, v15, Lo/durdkeeur;->dedr:Ljava/lang/String;

    .line 879
    .line 880
    invoke-virtual {v10, v1, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 881
    .line 882
    .line 883
    const-string v1, "experiment_ids_clear_blob"

    .line 884
    .line 885
    iget-object v3, v15, Lo/durdkeeur;->nkpkuui:[B

    .line 886
    .line 887
    invoke-virtual {v10, v1, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    .line 888
    .line 889
    .line 890
    const-string v1, "experiment_ids_encrypted_blob"

    .line 891
    .line 892
    iget-object v3, v15, Lo/durdkeeur;->kikaa:[B

    .line 893
    .line 894
    invoke-virtual {v10, v1, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    .line 895
    .line 896
    .line 897
    const-string v1, "events"

    .line 898
    .line 899
    const/4 v4, 0x0

    .line 900
    invoke-virtual {v6, v1, v4, v10}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    .line 901
    .line 902
    .line 903
    move-result-wide v10

    .line 904
    const-string v1, "event_id"

    .line 905
    .line 906
    if-nez v9, :cond_1c

    .line 907
    .line 908
    array-length v3, v8

    .line 909
    int-to-double v3, v3

    .line 910
    int-to-double v12, v0

    .line 911
    div-double/2addr v3, v12

    .line 912
    invoke-static {v3, v4}, Ljava/lang/Math;->ceil(D)D

    .line 913
    .line 914
    .line 915
    move-result-wide v3

    .line 916
    double-to-int v3, v3

    .line 917
    const/4 v13, 0x1

    .line 918
    :goto_12
    if-gt v13, v3, :cond_1c

    .line 919
    .line 920
    add-int/lit8 v4, v13, -0x1

    .line 921
    .line 922
    mul-int/2addr v4, v0

    .line 923
    mul-int v5, v13, v0

    .line 924
    .line 925
    array-length v7, v8

    .line 926
    invoke-static {v5, v7}, Ljava/lang/Math;->min(II)I

    .line 927
    .line 928
    .line 929
    move-result v5

    .line 930
    invoke-static {v8, v4, v5}, Ljava/util/Arrays;->copyOfRange([BII)[B

    .line 931
    .line 932
    .line 933
    move-result-object v4

    .line 934
    new-instance v5, Landroid/content/ContentValues;

    .line 935
    .line 936
    invoke-direct {v5}, Landroid/content/ContentValues;-><init>()V

    .line 937
    .line 938
    .line 939
    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 940
    .line 941
    .line 942
    move-result-object v7

    .line 943
    invoke-virtual {v5, v1, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 944
    .line 945
    .line 946
    const-string v7, "sequence_num"

    .line 947
    .line 948
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 949
    .line 950
    .line 951
    move-result-object v9

    .line 952
    invoke-virtual {v5, v7, v9}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 953
    .line 954
    .line 955
    invoke-virtual {v5, v2, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    .line 956
    .line 957
    .line 958
    const-string v4, "event_payloads"

    .line 959
    .line 960
    const/4 v7, 0x0

    .line 961
    invoke-virtual {v6, v4, v7, v5}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    .line 962
    .line 963
    .line 964
    add-int/lit8 v13, v13, 0x1

    .line 965
    .line 966
    goto :goto_12

    .line 967
    :cond_1c
    iget-object v0, v15, Lo/durdkeeur;->aiupunrka:Ljava/util/Map;

    .line 968
    .line 969
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 970
    .line 971
    .line 972
    move-result-object v0

    .line 973
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 974
    .line 975
    .line 976
    move-result-object v0

    .line 977
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 978
    .line 979
    .line 980
    move-result-object v0

    .line 981
    :goto_13
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 982
    .line 983
    .line 984
    move-result v2

    .line 985
    if-eqz v2, :cond_1d

    .line 986
    .line 987
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 988
    .line 989
    .line 990
    move-result-object v2

    .line 991
    check-cast v2, Ljava/util/Map$Entry;

    .line 992
    .line 993
    new-instance v3, Landroid/content/ContentValues;

    .line 994
    .line 995
    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    .line 996
    .line 997
    .line 998
    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 999
    .line 1000
    .line 1001
    move-result-object v4

    .line 1002
    invoke-virtual {v3, v1, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    .line 1003
    .line 1004
    .line 1005
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 1006
    .line 1007
    .line 1008
    move-result-object v4

    .line 1009
    check-cast v4, Ljava/lang/String;

    .line 1010
    .line 1011
    const-string v5, "name"

    .line 1012
    .line 1013
    invoke-virtual {v3, v5, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 1014
    .line 1015
    .line 1016
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 1017
    .line 1018
    .line 1019
    move-result-object v2

    .line 1020
    check-cast v2, Ljava/lang/String;

    .line 1021
    .line 1022
    const-string v4, "value"

    .line 1023
    .line 1024
    invoke-virtual {v3, v4, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 1025
    .line 1026
    .line 1027
    const-string v2, "event_metadata"

    .line 1028
    .line 1029
    const/4 v4, 0x0

    .line 1030
    invoke-virtual {v6, v2, v4, v3}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    .line 1031
    .line 1032
    .line 1033
    goto :goto_13

    .line 1034
    :cond_1d
    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1035
    .line 1036
    .line 1037
    move-result-object v0

    .line 1038
    :goto_14
    return-object v0

    .line 1039
    :pswitch_data_0
    .packed-switch 0x5
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
.end method

.method public dpeakapiakpa()V
    .locals 3

    .line 1
    iget-object v0, p0, Lo/anneraupp;->rpupp:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lo/anpnud;

    .line 4
    .line 5
    iget-object v1, p0, Lo/anneraupp;->aareerpeir:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lo/uiaikdrrr;

    .line 8
    .line 9
    iget-object p0, p0, Lo/anneraupp;->aaidaieneai:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast p0, Lo/rnpueprd;

    .line 12
    .line 13
    invoke-virtual {v0}, Lo/anpnud;->ekrraa()Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    if-nez v2, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    iget-object v1, v1, Lo/uiaikdrrr;->aaidaieneai:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v1, Lo/pria;

    .line 23
    .line 24
    if-nez v1, :cond_1

    .line 25
    .line 26
    :goto_0
    return-void

    .line 27
    :cond_1
    const/4 v2, 0x1

    .line 28
    invoke-virtual {v0, p0, v1, v2}, Lo/anpnud;->pepeunri(Lo/rnpueprd;Lo/pria;Z)V

    .line 29
    .line 30
    .line 31
    sget-object p0, Lo/anpnud;->kapkrnkiiiea:Ljava/lang/Object;

    .line 32
    .line 33
    monitor-enter p0

    .line 34
    :try_start_0
    iget-object v1, v0, Lo/anpnud;->ekrraa:Landroid/util/Pair;

    .line 35
    .line 36
    if-eqz v1, :cond_2

    .line 37
    .line 38
    iget-object v1, v0, Lo/anpnud;->aiupunrka:Lo/arpea;

    .line 39
    .line 40
    const-string v2, "Updating state from update queued during doAction"

    .line 41
    .line 42
    invoke-virtual {v1, v2}, Lo/arpea;->ppipdprui(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    iget-object v1, v0, Lo/anpnud;->ekrraa:Landroid/util/Pair;

    .line 46
    .line 47
    iget-object v2, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v2, Lo/pria;

    .line 50
    .line 51
    iget-object v1, v1, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v1, Lo/aeie;

    .line 54
    .line 55
    invoke-virtual {v0, v2, v1}, Lo/anpnud;->aiupunrka(Lo/pria;Lo/aeie;)V

    .line 56
    .line 57
    .line 58
    const/4 v1, 0x0

    .line 59
    iput-object v1, v0, Lo/anpnud;->ekrraa:Landroid/util/Pair;

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :catchall_0
    move-exception v0

    .line 63
    goto :goto_2

    .line 64
    :cond_2
    :goto_1
    monitor-exit p0

    .line 65
    return-void

    .line 66
    :goto_2
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 67
    throw v0
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
.end method

.method public dpunpe(Lo/naenikid;)V
    .locals 7

    .line 1
    iget-object v0, p0, Lo/anneraupp;->rpupp:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lo/rdekeaei;

    .line 4
    .line 5
    iget-object v1, p0, Lo/anneraupp;->aareerpeir:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lo/uunduidn;

    .line 8
    .line 9
    iget-object p0, p0, Lo/anneraupp;->aaidaieneai:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast p0, Lo/uurnpurrdi;

    .line 12
    .line 13
    iget-object v0, v0, Lo/rdekeaei;->rpupp:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Lo/kpkknrer;

    .line 16
    .line 17
    new-instance v2, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string v3, "Preview transformation info updated. "

    .line 20
    .line 21
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    const-string v3, "PreviewView"

    .line 32
    .line 33
    invoke-static {v3, v2}, Lo/uraa;->ndpnikda(Ljava/lang/String;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    invoke-interface {v1}, Lo/uunduidn;->ekrraa()Lo/parkkkdp;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    invoke-interface {v1}, Lo/unrn;->iiunkaippn()I

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    const/4 v2, 0x0

    .line 45
    const/4 v3, 0x1

    .line 46
    if-nez v1, :cond_0

    .line 47
    .line 48
    move v1, v3

    .line 49
    goto :goto_0

    .line 50
    :cond_0
    move v1, v2

    .line 51
    :goto_0
    iget-object v4, v0, Lo/kpkknrer;->aaidaieneai:Lo/edananupar;

    .line 52
    .line 53
    iget-object p0, p0, Lo/uurnpurrdi;->dpeakapiakpa:Landroid/util/Size;

    .line 54
    .line 55
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    new-instance v5, Ljava/lang/StringBuilder;

    .line 59
    .line 60
    const-string v6, "Transformation info set: "

    .line 61
    .line 62
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    const-string v6, " "

    .line 69
    .line 70
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 77
    .line 78
    .line 79
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v5

    .line 86
    const-string v6, "PreviewTransform"

    .line 87
    .line 88
    invoke-static {v6, v5}, Lo/uraa;->ndpnikda(Ljava/lang/String;Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    iget-object v5, p1, Lo/naenikid;->dpunpe:Landroid/graphics/Rect;

    .line 92
    .line 93
    iput-object v5, v4, Lo/edananupar;->dpeakapiakpa:Landroid/graphics/Rect;

    .line 94
    .line 95
    iget v5, p1, Lo/naenikid;->dpeakapiakpa:I

    .line 96
    .line 97
    iput v5, v4, Lo/edananupar;->pepeunri:I

    .line 98
    .line 99
    iget v5, p1, Lo/naenikid;->pepeunri:I

    .line 100
    .line 101
    iput v5, v4, Lo/edananupar;->iiunkaippn:I

    .line 102
    .line 103
    iput-object p0, v4, Lo/edananupar;->dpunpe:Landroid/util/Size;

    .line 104
    .line 105
    iput-boolean v1, v4, Lo/edananupar;->aiupunrka:Z

    .line 106
    .line 107
    iget-boolean p0, p1, Lo/naenikid;->irkari:Z

    .line 108
    .line 109
    iput-boolean p0, v4, Lo/edananupar;->adadnadrr:Z

    .line 110
    .line 111
    iget-object p0, p1, Lo/naenikid;->iiunkaippn:Landroid/graphics/Matrix;

    .line 112
    .line 113
    iput-object p0, v4, Lo/edananupar;->irkari:Landroid/graphics/Matrix;

    .line 114
    .line 115
    const/4 p0, -0x1

    .line 116
    if-eq v5, p0, :cond_2

    .line 117
    .line 118
    iget-object p0, v0, Lo/kpkknrer;->rpupp:Lo/paeiduku;

    .line 119
    .line 120
    if-eqz p0, :cond_1

    .line 121
    .line 122
    instance-of p0, p0, Lo/kuuunrrddir;

    .line 123
    .line 124
    if-eqz p0, :cond_1

    .line 125
    .line 126
    goto :goto_1

    .line 127
    :cond_1
    iput-boolean v2, v0, Lo/kpkknrer;->iureria:Z

    .line 128
    .line 129
    goto :goto_2

    .line 130
    :cond_2
    :goto_1
    iput-boolean v3, v0, Lo/kpkknrer;->iureria:Z

    .line 131
    .line 132
    :goto_2
    invoke-virtual {v0}, Lo/kpkknrer;->dpunpe()V

    .line 133
    .line 134
    .line 135
    return-void
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
.end method

.method public irkari()V
    .locals 4

    .line 1
    iget-object v0, p0, Lo/anneraupp;->rpupp:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lo/rdekeaei;

    .line 4
    .line 5
    iget-object v1, p0, Lo/anneraupp;->aareerpeir:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lo/paarkadunea;

    .line 8
    .line 9
    iget-object p0, p0, Lo/anneraupp;->aaidaieneai:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast p0, Lo/uunduidn;

    .line 12
    .line 13
    iget-object v0, v0, Lo/rdekeaei;->rpupp:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Lo/kpkknrer;

    .line 16
    .line 17
    iget-object v0, v0, Lo/kpkknrer;->ikpeepa:Ljava/util/concurrent/atomic/AtomicReference;

    .line 18
    .line 19
    :cond_0
    const/4 v2, 0x0

    .line 20
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    if-eqz v3, :cond_1

    .line 25
    .line 26
    sget-object v0, Lo/inupiadurunk;->dikdannunk:Lo/inupiadurunk;

    .line 27
    .line 28
    invoke-virtual {v1, v0}, Lo/paarkadunea;->dpeakapiakpa(Lo/inupiadurunk;)V

    .line 29
    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_1
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    if-eq v3, v1, :cond_0

    .line 37
    .line 38
    :goto_0
    iget-object v0, v1, Lo/paarkadunea;->iiunkaippn:Lo/kapdruuneke;

    .line 39
    .line 40
    if-eqz v0, :cond_2

    .line 41
    .line 42
    const/4 v3, 0x0

    .line 43
    invoke-interface {v0, v3}, Ljava/util/concurrent/Future;->cancel(Z)Z

    .line 44
    .line 45
    .line 46
    iput-object v2, v1, Lo/paarkadunea;->iiunkaippn:Lo/kapdruuneke;

    .line 47
    .line 48
    :cond_2
    invoke-interface {p0}, Lo/uunduidn;->pepeunri()Lo/nkirndda;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    invoke-interface {p0, v1}, Lo/nkirndda;->dpunpe(Lo/pdkpaaedp;)V

    .line 53
    .line 54
    .line 55
    return-void
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
.end method

.method public pepeunri()Ljava/lang/Object;
    .locals 9

    .line 1
    iget-object v0, p0, Lo/anneraupp;->rpupp:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lo/knrdkararnu;

    .line 4
    .line 5
    iget-object v1, p0, Lo/anneraupp;->aareerpeir:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lo/ekunerpp;

    .line 8
    .line 9
    iget-object p0, p0, Lo/anneraupp;->aaidaieneai:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast p0, Lo/durdkeeur;

    .line 12
    .line 13
    iget-object v2, v0, Lo/knrdkararnu;->irkari:Lo/eidak;

    .line 14
    .line 15
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    iget-object v3, v1, Lo/ekunerpp;->pepeunri:Lo/ikknaarr;

    .line 19
    .line 20
    iget-object v4, p0, Lo/durdkeeur;->dpunpe:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v5, v1, Lo/ekunerpp;->dpunpe:Ljava/lang/String;

    .line 23
    .line 24
    const-string v6, "SQLiteEventStore"

    .line 25
    .line 26
    invoke-static {v6}, Lo/nkeiak;->uarduadkp(Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v6

    .line 30
    const/4 v7, 0x3

    .line 31
    invoke-static {v6, v7}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 32
    .line 33
    .line 34
    move-result v7

    .line 35
    if-eqz v7, :cond_0

    .line 36
    .line 37
    new-instance v7, Ljava/lang/StringBuilder;

    .line 38
    .line 39
    const-string v8, "Storing event with priority="

    .line 40
    .line 41
    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    const-string v3, ", name="

    .line 48
    .line 49
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    const-string v3, " for destination "

    .line 56
    .line 57
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    invoke-static {v6, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 68
    .line 69
    .line 70
    :cond_0
    new-instance v3, Lo/anneraupp;

    .line 71
    .line 72
    const/4 v4, 0x5

    .line 73
    invoke-direct {v3, v2, p0, v1, v4}, Lo/anneraupp;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v2, v3}, Lo/eidak;->ndpnikda(Lo/enepekekiur;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    check-cast p0, Ljava/lang/Long;

    .line 81
    .line 82
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    iget-object p0, v0, Lo/knrdkararnu;->dpunpe:Lo/rnpueprd;

    .line 86
    .line 87
    const/4 v0, 0x1

    .line 88
    const/4 v2, 0x0

    .line 89
    invoke-virtual {p0, v1, v0, v2}, Lo/rnpueprd;->rudnpkpkrkpi(Lo/ekunerpp;IZ)V

    .line 90
    .line 91
    .line 92
    const/4 p0, 0x0

    .line 93
    return-object p0
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
.end method

.method public ukin(Lo/irnnkdrkia;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, Lo/anneraupp;->rpupp:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lo/drruiir;

    .line 4
    .line 5
    iget-object v1, p0, Lo/anneraupp;->aareerpeir:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 8
    .line 9
    iget-object p0, p0, Lo/anneraupp;->aaidaieneai:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast p0, Lo/aninikni;

    .line 12
    .line 13
    invoke-virtual {p1}, Lo/irnnkdrkia;->adadnadrr()Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    const/4 v3, 0x0

    .line 18
    if-eqz v2, :cond_0

    .line 19
    .line 20
    invoke-virtual {p1}, Lo/irnnkdrkia;->iiunkaippn()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    invoke-virtual {v0, p0}, Lo/drruiir;->pepeunri(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    invoke-virtual {p1}, Lo/irnnkdrkia;->irkari()Ljava/lang/Exception;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    if-eqz v2, :cond_1

    .line 33
    .line 34
    invoke-virtual {p1}, Lo/irnnkdrkia;->irkari()Ljava/lang/Exception;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    invoke-virtual {v0, p0}, Lo/drruiir;->dpeakapiakpa(Ljava/lang/Exception;)Z

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_1
    const/4 p1, 0x1

    .line 43
    invoke-virtual {v1, p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    .line 44
    .line 45
    .line 46
    move-result p1

    .line 47
    if-eqz p1, :cond_2

    .line 48
    .line 49
    iget-object p0, p0, Lo/aninikni;->rpupp:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p0, Lo/dpkreiuaur;

    .line 52
    .line 53
    iget-object p0, p0, Lo/dpkreiuaur;->rpupp:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast p0, Lo/nupadk;

    .line 56
    .line 57
    invoke-virtual {p0, v3}, Lo/nupadk;->ndpnikda(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    :cond_2
    :goto_0
    invoke-static {v3}, Lcom/google/android/gms/tasks/Tasks;->irkari(Ljava/lang/Object;)Lo/nupadk;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    return-object p0
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
.end method
