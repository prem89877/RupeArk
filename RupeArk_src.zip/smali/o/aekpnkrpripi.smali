.class public final Lo/aekpnkrpripi;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final dpunpe:Lo/dkrikkuar;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lo/edkrkak;

    .line 2
    .line 3
    invoke-direct {v0}, Lo/edkrkak;-><init>()V

    .line 4
    .line 5
    .line 6
    sget-object v1, Lo/pdrkniu;->dpunpe:Lo/pdrkniu;

    .line 7
    .line 8
    const-class v2, Lo/rnea;

    .line 9
    .line 10
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 11
    .line 12
    .line 13
    const-class v2, Lo/ipipkpua;

    .line 14
    .line 15
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 16
    .line 17
    .line 18
    sget-object v1, Lo/rpann;->dpunpe:Lo/rpann;

    .line 19
    .line 20
    const-class v2, Lo/rddup;

    .line 21
    .line 22
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 23
    .line 24
    .line 25
    const-class v2, Lo/inddedpri;

    .line 26
    .line 27
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 28
    .line 29
    .line 30
    sget-object v1, Lo/epupiini;->dpunpe:Lo/epupiini;

    .line 31
    .line 32
    const-class v2, Lo/kudukanp;

    .line 33
    .line 34
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 35
    .line 36
    .line 37
    const-class v2, Lo/einkiirund;

    .line 38
    .line 39
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 40
    .line 41
    .line 42
    sget-object v1, Lo/punnrdknpdrk;->dpunpe:Lo/punnrdknpdrk;

    .line 43
    .line 44
    const-class v2, Lo/puakdi;

    .line 45
    .line 46
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 47
    .line 48
    .line 49
    const-class v2, Lo/piae;

    .line 50
    .line 51
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 52
    .line 53
    .line 54
    sget-object v1, Lo/eadadiuap;->dpunpe:Lo/eadadiuap;

    .line 55
    .line 56
    const-class v2, Lo/punrruekikd;

    .line 57
    .line 58
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 59
    .line 60
    .line 61
    const-class v2, Lo/eiinpuueae;

    .line 62
    .line 63
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 64
    .line 65
    .line 66
    sget-object v1, Lo/kpdndiperrii;->dpunpe:Lo/kpdndiperrii;

    .line 67
    .line 68
    const-class v2, Lo/aerardueaak;

    .line 69
    .line 70
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 71
    .line 72
    .line 73
    const-class v2, Lo/aaidrnernuid;

    .line 74
    .line 75
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 76
    .line 77
    .line 78
    sget-object v1, Lo/aprdurkpe;->dpunpe:Lo/aprdurkpe;

    .line 79
    .line 80
    const-class v2, Lo/eieuia;

    .line 81
    .line 82
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 83
    .line 84
    .line 85
    const-class v2, Lo/udpadan;

    .line 86
    .line 87
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 88
    .line 89
    .line 90
    sget-object v1, Lo/epaapi;->dpunpe:Lo/epaapi;

    .line 91
    .line 92
    const-class v2, Lo/eeaipkri;

    .line 93
    .line 94
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 95
    .line 96
    .line 97
    const-class v2, Lo/dnpidedind;

    .line 98
    .line 99
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 100
    .line 101
    .line 102
    sget-object v1, Lo/ipipd;->dpunpe:Lo/ipipd;

    .line 103
    .line 104
    const-class v2, Lo/eeraudnu;

    .line 105
    .line 106
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 107
    .line 108
    .line 109
    const-class v2, Lo/krknuidau;

    .line 110
    .line 111
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 112
    .line 113
    .line 114
    sget-object v1, Lo/nnuippepae;->dpunpe:Lo/nnuippepae;

    .line 115
    .line 116
    const-class v2, Lo/kdriuua;

    .line 117
    .line 118
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 119
    .line 120
    .line 121
    const-class v2, Lo/iaind;

    .line 122
    .line 123
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 124
    .line 125
    .line 126
    sget-object v1, Lo/eupirpuer;->dpunpe:Lo/eupirpuer;

    .line 127
    .line 128
    const-class v2, Lo/idnanknr;

    .line 129
    .line 130
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 131
    .line 132
    .line 133
    const-class v2, Lo/iaurerii;

    .line 134
    .line 135
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 136
    .line 137
    .line 138
    sget-object v1, Lo/pnudupaper;->dpunpe:Lo/pnudupaper;

    .line 139
    .line 140
    const-class v2, Lo/eeiuanenurdd;

    .line 141
    .line 142
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 143
    .line 144
    .line 145
    const-class v2, Lo/kidd;

    .line 146
    .line 147
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 148
    .line 149
    .line 150
    sget-object v1, Lo/kkuek;->dpunpe:Lo/kkuek;

    .line 151
    .line 152
    const-class v2, Lo/knuuripa;

    .line 153
    .line 154
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 155
    .line 156
    .line 157
    const-class v2, Lo/dukar;

    .line 158
    .line 159
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 160
    .line 161
    .line 162
    sget-object v1, Lo/npnipe;->dpunpe:Lo/npnipe;

    .line 163
    .line 164
    const-class v2, Lo/kkiiiped;

    .line 165
    .line 166
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 167
    .line 168
    .line 169
    const-class v2, Lo/diikaeukernu;

    .line 170
    .line 171
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 172
    .line 173
    .line 174
    sget-object v1, Lo/kard;->dpunpe:Lo/kard;

    .line 175
    .line 176
    const-class v2, Lo/nprurukd;

    .line 177
    .line 178
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 179
    .line 180
    .line 181
    const-class v2, Lo/ikniirdr;

    .line 182
    .line 183
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 184
    .line 185
    .line 186
    sget-object v1, Lo/nakrniakei;->dpunpe:Lo/nakrniakei;

    .line 187
    .line 188
    const-class v2, Lo/eipip;

    .line 189
    .line 190
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 191
    .line 192
    .line 193
    const-class v2, Lo/pkdniunanrap;

    .line 194
    .line 195
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 196
    .line 197
    .line 198
    sget-object v1, Lo/ppeknpaa;->dpunpe:Lo/ppeknpaa;

    .line 199
    .line 200
    const-class v2, Lo/kudndpiid;

    .line 201
    .line 202
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 203
    .line 204
    .line 205
    const-class v2, Lo/rerdp;

    .line 206
    .line 207
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 208
    .line 209
    .line 210
    sget-object v1, Lo/epkaukuriu;->dpunpe:Lo/epkaukuriu;

    .line 211
    .line 212
    const-class v2, Lo/edrda;

    .line 213
    .line 214
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 215
    .line 216
    .line 217
    const-class v2, Lo/nduknu;

    .line 218
    .line 219
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 220
    .line 221
    .line 222
    sget-object v1, Lo/reapureker;->dpunpe:Lo/reapureker;

    .line 223
    .line 224
    const-class v2, Lo/raikunrua;

    .line 225
    .line 226
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 227
    .line 228
    .line 229
    const-class v2, Lo/kapnpued;

    .line 230
    .line 231
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 232
    .line 233
    .line 234
    sget-object v1, Lo/ruuaed;->dpunpe:Lo/ruuaed;

    .line 235
    .line 236
    const-class v2, Lo/dunrp;

    .line 237
    .line 238
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 239
    .line 240
    .line 241
    const-class v2, Lo/kdeunek;

    .line 242
    .line 243
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 244
    .line 245
    .line 246
    sget-object v1, Lo/arpprnik;->dpunpe:Lo/arpprnik;

    .line 247
    .line 248
    const-class v2, Lo/iapkpnauiu;

    .line 249
    .line 250
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 251
    .line 252
    .line 253
    const-class v2, Lo/riarpu;

    .line 254
    .line 255
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 256
    .line 257
    .line 258
    sget-object v1, Lo/reakpaurr;->dpunpe:Lo/reakpaurr;

    .line 259
    .line 260
    const-class v2, Lo/neiaerani;

    .line 261
    .line 262
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 263
    .line 264
    .line 265
    const-class v2, Lo/rdpi;

    .line 266
    .line 267
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 268
    .line 269
    .line 270
    sget-object v1, Lo/rppnk;->dpunpe:Lo/rppnk;

    .line 271
    .line 272
    const-class v2, Lo/ruiauaenura;

    .line 273
    .line 274
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 275
    .line 276
    .line 277
    const-class v2, Lo/udkppkdikn;

    .line 278
    .line 279
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 280
    .line 281
    .line 282
    sget-object v1, Lo/kriepdpi;->dpunpe:Lo/kriepdpi;

    .line 283
    .line 284
    const-class v2, Lo/euir;

    .line 285
    .line 286
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 287
    .line 288
    .line 289
    const-class v2, Lo/dnkk;

    .line 290
    .line 291
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 292
    .line 293
    .line 294
    sget-object v1, Lo/uiredudkier;->dpunpe:Lo/uiredudkier;

    .line 295
    .line 296
    const-class v2, Lo/ieeiuudnnp;

    .line 297
    .line 298
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 299
    .line 300
    .line 301
    const-class v2, Lo/erdnreiknru;

    .line 302
    .line 303
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 304
    .line 305
    .line 306
    sget-object v1, Lo/nner;->dpunpe:Lo/nner;

    .line 307
    .line 308
    const-class v2, Lo/enpkiid;

    .line 309
    .line 310
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 311
    .line 312
    .line 313
    const-class v2, Lo/aipkrdara;

    .line 314
    .line 315
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 316
    .line 317
    .line 318
    sget-object v1, Lo/nirnieii;->dpunpe:Lo/nirnieii;

    .line 319
    .line 320
    const-class v2, Lo/prdrda;

    .line 321
    .line 322
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 323
    .line 324
    .line 325
    const-class v2, Lo/epkdpnkiiea;

    .line 326
    .line 327
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 328
    .line 329
    .line 330
    sget-object v1, Lo/druriiirnu;->dpunpe:Lo/druriiirnu;

    .line 331
    .line 332
    const-class v2, Lo/aidnrd;

    .line 333
    .line 334
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 335
    .line 336
    .line 337
    const-class v2, Lo/inkdduirr;

    .line 338
    .line 339
    invoke-virtual {v0, v2, v1}, Lo/edkrkak;->dpunpe(Ljava/lang/Class;Lo/dkidendppad;)Lo/ieaepae;

    .line 340
    .line 341
    .line 342
    const/4 v1, 0x1

    .line 343
    iput-boolean v1, v0, Lo/edkrkak;->irkari:Z

    .line 344
    .line 345
    new-instance v1, Lo/dkrikkuar;

    .line 346
    .line 347
    invoke-direct {v1, v0}, Lo/dkrikkuar;-><init>(Ljava/lang/Object;)V

    .line 348
    .line 349
    .line 350
    sput-object v1, Lo/aekpnkrpripi;->dpunpe:Lo/dkrikkuar;

    .line 351
    .line 352
    return-void
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
.end method

.method public static adadnadrr(Landroid/util/JsonReader;)Lo/riarpu;
    .locals 6

    .line 1
    new-instance v0, Lo/nnueareupend;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 7
    .line 8
    .line 9
    :goto_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_5

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    const/4 v3, 0x2

    .line 27
    const/4 v4, 0x1

    .line 28
    const/4 v5, -0x1

    .line 29
    sparse-switch v2, :sswitch_data_0

    .line 30
    .line 31
    .line 32
    goto :goto_1

    .line 33
    :sswitch_0
    const-string v2, "importance"

    .line 34
    .line 35
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-nez v1, :cond_0

    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_0
    const/4 v5, 0x3

    .line 43
    goto :goto_1

    .line 44
    :sswitch_1
    const-string v2, "defaultProcess"

    .line 45
    .line 46
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-nez v1, :cond_1

    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_1
    move v5, v3

    .line 54
    goto :goto_1

    .line 55
    :sswitch_2
    const-string v2, "processName"

    .line 56
    .line 57
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-nez v1, :cond_2

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_2
    move v5, v4

    .line 65
    goto :goto_1

    .line 66
    :sswitch_3
    const-string v2, "pid"

    .line 67
    .line 68
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    if-nez v1, :cond_3

    .line 73
    .line 74
    goto :goto_1

    .line 75
    :cond_3
    const/4 v5, 0x0

    .line 76
    :goto_1
    packed-switch v5, :pswitch_data_0

    .line 77
    .line 78
    .line 79
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 80
    .line 81
    .line 82
    goto :goto_0

    .line 83
    :pswitch_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextInt()I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    iput v1, v0, Lo/nnueareupend;->pepeunri:I

    .line 88
    .line 89
    iget-byte v1, v0, Lo/nnueareupend;->iiunkaippn:B

    .line 90
    .line 91
    or-int/2addr v1, v3

    .line 92
    int-to-byte v1, v1

    .line 93
    iput-byte v1, v0, Lo/nnueareupend;->iiunkaippn:B

    .line 94
    .line 95
    goto :goto_0

    .line 96
    :pswitch_1
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextBoolean()Z

    .line 97
    .line 98
    .line 99
    move-result v1

    .line 100
    iput-boolean v1, v0, Lo/nnueareupend;->irkari:Z

    .line 101
    .line 102
    iget-byte v1, v0, Lo/nnueareupend;->iiunkaippn:B

    .line 103
    .line 104
    or-int/lit8 v1, v1, 0x4

    .line 105
    .line 106
    int-to-byte v1, v1

    .line 107
    iput-byte v1, v0, Lo/nnueareupend;->iiunkaippn:B

    .line 108
    .line 109
    goto :goto_0

    .line 110
    :pswitch_2
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    if-eqz v1, :cond_4

    .line 115
    .line 116
    iput-object v1, v0, Lo/nnueareupend;->dpunpe:Ljava/lang/String;

    .line 117
    .line 118
    goto :goto_0

    .line 119
    :cond_4
    const-string p0, "Null processName"

    .line 120
    .line 121
    invoke-static {p0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    const/4 p0, 0x0

    .line 125
    return-object p0

    .line 126
    :pswitch_3
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextInt()I

    .line 127
    .line 128
    .line 129
    move-result v1

    .line 130
    iput v1, v0, Lo/nnueareupend;->dpeakapiakpa:I

    .line 131
    .line 132
    iget-byte v1, v0, Lo/nnueareupend;->iiunkaippn:B

    .line 133
    .line 134
    or-int/2addr v1, v4

    .line 135
    int-to-byte v1, v1

    .line 136
    iput-byte v1, v0, Lo/nnueareupend;->iiunkaippn:B

    .line 137
    .line 138
    goto/16 :goto_0

    .line 139
    .line 140
    :cond_5
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 141
    .line 142
    .line 143
    invoke-virtual {v0}, Lo/nnueareupend;->dpunpe()Lo/riarpu;

    .line 144
    .line 145
    .line 146
    move-result-object p0

    .line 147
    return-object p0

    .line 148
    nop

    .line 149
    :sswitch_data_0
    .sparse-switch
        0x1b18b -> :sswitch_3
        0xc0f3d9a -> :sswitch_2
        0x650184ee -> :sswitch_1
        0x7eb2da74 -> :sswitch_0
    .end sparse-switch

    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
.end method

.method public static aiupunrka(Landroid/util/JsonReader;)Lo/dukar;
    .locals 12

    .line 1
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    const/4 v1, 0x0

    .line 6
    move v2, v0

    .line 7
    move v8, v2

    .line 8
    move-object v4, v1

    .line 9
    move-object v5, v4

    .line 10
    move-object v6, v5

    .line 11
    move-object v7, v6

    .line 12
    :goto_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    const/4 v9, 0x1

    .line 17
    if-eqz v3, :cond_7

    .line 18
    .line 19
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 27
    .line 28
    .line 29
    move-result v10

    .line 30
    const/4 v11, -0x1

    .line 31
    sparse-switch v10, :sswitch_data_0

    .line 32
    .line 33
    .line 34
    :goto_1
    move v9, v11

    .line 35
    goto :goto_2

    .line 36
    :sswitch_0
    const-string v9, "overflowCount"

    .line 37
    .line 38
    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    if-nez v3, :cond_0

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_0
    const/4 v9, 0x4

    .line 46
    goto :goto_2

    .line 47
    :sswitch_1
    const-string v9, "causedBy"

    .line 48
    .line 49
    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    if-nez v3, :cond_1

    .line 54
    .line 55
    goto :goto_1

    .line 56
    :cond_1
    const/4 v9, 0x3

    .line 57
    goto :goto_2

    .line 58
    :sswitch_2
    const-string v9, "type"

    .line 59
    .line 60
    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v3

    .line 64
    if-nez v3, :cond_2

    .line 65
    .line 66
    goto :goto_1

    .line 67
    :cond_2
    const/4 v9, 0x2

    .line 68
    goto :goto_2

    .line 69
    :sswitch_3
    const-string v10, "reason"

    .line 70
    .line 71
    invoke-virtual {v3, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v3

    .line 75
    if-nez v3, :cond_4

    .line 76
    .line 77
    goto :goto_1

    .line 78
    :sswitch_4
    const-string v9, "frames"

    .line 79
    .line 80
    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v3

    .line 84
    if-nez v3, :cond_3

    .line 85
    .line 86
    goto :goto_1

    .line 87
    :cond_3
    move v9, v0

    .line 88
    :cond_4
    :goto_2
    packed-switch v9, :pswitch_data_0

    .line 89
    .line 90
    .line 91
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 92
    .line 93
    .line 94
    goto :goto_0

    .line 95
    :pswitch_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextInt()I

    .line 96
    .line 97
    .line 98
    move-result v8

    .line 99
    or-int/lit8 v2, v2, 0x1

    .line 100
    .line 101
    int-to-byte v2, v2

    .line 102
    goto :goto_0

    .line 103
    :pswitch_1
    invoke-static {p0}, Lo/aekpnkrpripi;->aiupunrka(Landroid/util/JsonReader;)Lo/dukar;

    .line 104
    .line 105
    .line 106
    move-result-object v7

    .line 107
    goto :goto_0

    .line 108
    :pswitch_2
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v4

    .line 112
    if-eqz v4, :cond_5

    .line 113
    .line 114
    goto :goto_0

    .line 115
    :cond_5
    const-string p0, "Null type"

    .line 116
    .line 117
    invoke-static {p0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    return-object v1

    .line 121
    :pswitch_3
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v5

    .line 125
    goto :goto_0

    .line 126
    :pswitch_4
    new-instance v3, Lo/kniuuerekaup;

    .line 127
    .line 128
    const/16 v6, 0x11

    .line 129
    .line 130
    invoke-direct {v3, v6}, Lo/kniuuerekaup;-><init>(I)V

    .line 131
    .line 132
    .line 133
    invoke-static {p0, v3}, Lo/aekpnkrpripi;->irkari(Landroid/util/JsonReader;Lo/kniuuerekaup;)Ljava/util/List;

    .line 134
    .line 135
    .line 136
    move-result-object v6

    .line 137
    if-eqz v6, :cond_6

    .line 138
    .line 139
    goto :goto_0

    .line 140
    :cond_6
    const-string p0, "Null frames"

    .line 141
    .line 142
    invoke-static {p0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    return-object v1

    .line 146
    :cond_7
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 147
    .line 148
    .line 149
    if-ne v2, v9, :cond_9

    .line 150
    .line 151
    if-eqz v4, :cond_9

    .line 152
    .line 153
    if-nez v6, :cond_8

    .line 154
    .line 155
    goto :goto_3

    .line 156
    :cond_8
    new-instance v3, Lo/dukar;

    .line 157
    .line 158
    invoke-direct/range {v3 .. v8}, Lo/dukar;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Lo/knuuripa;I)V

    .line 159
    .line 160
    .line 161
    return-object v3

    .line 162
    :cond_9
    :goto_3
    new-instance p0, Ljava/lang/StringBuilder;

    .line 163
    .line 164
    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    .line 165
    .line 166
    .line 167
    if-nez v4, :cond_a

    .line 168
    .line 169
    const-string v0, " type"

    .line 170
    .line 171
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    :cond_a
    if-nez v6, :cond_b

    .line 175
    .line 176
    const-string v0, " frames"

    .line 177
    .line 178
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 179
    .line 180
    .line 181
    :cond_b
    and-int/lit8 v0, v2, 0x1

    .line 182
    .line 183
    if-nez v0, :cond_c

    .line 184
    .line 185
    const-string v0, " overflowCount"

    .line 186
    .line 187
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 188
    .line 189
    .line 190
    :cond_c
    const-string v0, "Missing required properties:"

    .line 191
    .line 192
    invoke-static {v0, p0}, Lo/nrkepnpirid;->ndpnikda(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 193
    .line 194
    .line 195
    move-result-object p0

    .line 196
    invoke-static {p0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 197
    .line 198
    .line 199
    return-object v1

    .line 200
    nop

    .line 201
    :sswitch_data_0
    .sparse-switch
        -0x4b7d7b5a -> :sswitch_4
        -0x37ba6dbc -> :sswitch_3
        0x368f3a -> :sswitch_2
        0x57bc6d2 -> :sswitch_1
        0x22acde2d -> :sswitch_0
    .end sparse-switch

    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
.end method

.method public static dedr(Landroid/util/JsonReader;)Lo/pkdniunanrap;
    .locals 6

    .line 1
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    move-object v1, v0

    .line 6
    :goto_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 7
    .line 8
    .line 9
    move-result v2

    .line 10
    if-eqz v2, :cond_4

    .line 11
    .line 12
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    const-string v3, "profilingTrigger"

    .line 20
    .line 21
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    if-nez v2, :cond_0

    .line 26
    .line 27
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 32
    .line 33
    .line 34
    const/4 v1, 0x0

    .line 35
    move v2, v1

    .line 36
    :goto_1
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 37
    .line 38
    .line 39
    move-result v3

    .line 40
    const/4 v4, 0x1

    .line 41
    if-eqz v3, :cond_2

    .line 42
    .line 43
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    .line 49
    .line 50
    const-string v5, "trigger"

    .line 51
    .line 52
    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v3

    .line 56
    if-nez v3, :cond_1

    .line 57
    .line 58
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 59
    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_1
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextInt()I

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    move v2, v1

    .line 67
    move v1, v4

    .line 68
    goto :goto_1

    .line 69
    :cond_2
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 70
    .line 71
    .line 72
    if-ne v1, v4, :cond_3

    .line 73
    .line 74
    new-instance v1, Lo/rerdp;

    .line 75
    .line 76
    invoke-direct {v1, v2}, Lo/rerdp;-><init>(I)V

    .line 77
    .line 78
    .line 79
    goto :goto_0

    .line 80
    :cond_3
    const-string p0, "Missing required properties: trigger"

    .line 81
    .line 82
    invoke-static {p0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    return-object v0

    .line 86
    :cond_4
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 87
    .line 88
    .line 89
    if-eqz v1, :cond_5

    .line 90
    .line 91
    new-instance p0, Lo/pkdniunanrap;

    .line 92
    .line 93
    invoke-direct {p0, v1}, Lo/pkdniunanrap;-><init>(Lo/rerdp;)V

    .line 94
    .line 95
    .line 96
    return-object p0

    .line 97
    :cond_5
    const-string p0, "Missing required properties: profilingTrigger"

    .line 98
    .line 99
    invoke-static {p0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    return-object v0
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
.end method

.method public static dpeakapiakpa(Landroid/util/JsonReader;)Lo/kdeunek;
    .locals 5

    .line 1
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    move-object v1, v0

    .line 6
    move-object v2, v1

    .line 7
    :goto_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    if-eqz v3, :cond_4

    .line 12
    .line 13
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    const-string v4, "key"

    .line 21
    .line 22
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v4

    .line 26
    if-nez v4, :cond_2

    .line 27
    .line 28
    const-string v4, "value"

    .line 29
    .line 30
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    if-nez v3, :cond_0

    .line 35
    .line 36
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 37
    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    if-eqz v2, :cond_1

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_1
    const-string p0, "Null value"

    .line 48
    .line 49
    invoke-static {p0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    return-object v0

    .line 53
    :cond_2
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    if-eqz v1, :cond_3

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_3
    const-string p0, "Null key"

    .line 61
    .line 62
    invoke-static {p0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    return-object v0

    .line 66
    :cond_4
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 67
    .line 68
    .line 69
    if-eqz v1, :cond_6

    .line 70
    .line 71
    if-nez v2, :cond_5

    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_5
    new-instance p0, Lo/kdeunek;

    .line 75
    .line 76
    invoke-direct {p0, v1, v2}, Lo/kdeunek;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    return-object p0

    .line 80
    :cond_6
    :goto_1
    new-instance p0, Ljava/lang/StringBuilder;

    .line 81
    .line 82
    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    .line 83
    .line 84
    .line 85
    if-nez v1, :cond_7

    .line 86
    .line 87
    const-string v1, " key"

    .line 88
    .line 89
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    :cond_7
    if-nez v2, :cond_8

    .line 93
    .line 94
    const-string v1, " value"

    .line 95
    .line 96
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    :cond_8
    const-string v1, "Missing required properties:"

    .line 100
    .line 101
    invoke-static {v1, p0}, Lo/nrkepnpirid;->ndpnikda(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object p0

    .line 105
    invoke-static {p0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    return-object v0
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
.end method

.method public static dpunpe(Landroid/util/JsonReader;)Lo/kidd;
    .locals 7

    .line 1
    new-instance v0, Lo/npkr;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 7
    .line 8
    .line 9
    :goto_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_6

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    const/4 v3, 0x4

    .line 27
    const/4 v4, 0x2

    .line 28
    const/4 v5, 0x1

    .line 29
    const/4 v6, -0x1

    .line 30
    sparse-switch v2, :sswitch_data_0

    .line 31
    .line 32
    .line 33
    goto :goto_1

    .line 34
    :sswitch_0
    const-string v2, "importance"

    .line 35
    .line 36
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    if-nez v1, :cond_0

    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_0
    move v6, v3

    .line 44
    goto :goto_1

    .line 45
    :sswitch_1
    const-string v2, "file"

    .line 46
    .line 47
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-nez v1, :cond_1

    .line 52
    .line 53
    goto :goto_1

    .line 54
    :cond_1
    const/4 v6, 0x3

    .line 55
    goto :goto_1

    .line 56
    :sswitch_2
    const-string v2, "pc"

    .line 57
    .line 58
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    if-nez v1, :cond_2

    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_2
    move v6, v4

    .line 66
    goto :goto_1

    .line 67
    :sswitch_3
    const-string v2, "symbol"

    .line 68
    .line 69
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    if-nez v1, :cond_3

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_3
    move v6, v5

    .line 77
    goto :goto_1

    .line 78
    :sswitch_4
    const-string v2, "offset"

    .line 79
    .line 80
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    if-nez v1, :cond_4

    .line 85
    .line 86
    goto :goto_1

    .line 87
    :cond_4
    const/4 v6, 0x0

    .line 88
    :goto_1
    packed-switch v6, :pswitch_data_0

    .line 89
    .line 90
    .line 91
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 92
    .line 93
    .line 94
    goto :goto_0

    .line 95
    :pswitch_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextInt()I

    .line 96
    .line 97
    .line 98
    move-result v1

    .line 99
    iput v1, v0, Lo/npkr;->iiunkaippn:I

    .line 100
    .line 101
    iget-byte v1, v0, Lo/npkr;->aiupunrka:B

    .line 102
    .line 103
    or-int/2addr v1, v3

    .line 104
    int-to-byte v1, v1

    .line 105
    iput-byte v1, v0, Lo/npkr;->aiupunrka:B

    .line 106
    .line 107
    goto :goto_0

    .line 108
    :pswitch_1
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    iput-object v1, v0, Lo/npkr;->pepeunri:Ljava/lang/String;

    .line 113
    .line 114
    goto :goto_0

    .line 115
    :pswitch_2
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextLong()J

    .line 116
    .line 117
    .line 118
    move-result-wide v1

    .line 119
    iput-wide v1, v0, Lo/npkr;->dpunpe:J

    .line 120
    .line 121
    iget-byte v1, v0, Lo/npkr;->aiupunrka:B

    .line 122
    .line 123
    or-int/2addr v1, v5

    .line 124
    int-to-byte v1, v1

    .line 125
    iput-byte v1, v0, Lo/npkr;->aiupunrka:B

    .line 126
    .line 127
    goto :goto_0

    .line 128
    :pswitch_3
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    if-eqz v1, :cond_5

    .line 133
    .line 134
    iput-object v1, v0, Lo/npkr;->dpeakapiakpa:Ljava/lang/String;

    .line 135
    .line 136
    goto :goto_0

    .line 137
    :cond_5
    const-string p0, "Null symbol"

    .line 138
    .line 139
    invoke-static {p0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    const/4 p0, 0x0

    .line 143
    return-object p0

    .line 144
    :pswitch_4
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextLong()J

    .line 145
    .line 146
    .line 147
    move-result-wide v1

    .line 148
    iput-wide v1, v0, Lo/npkr;->irkari:J

    .line 149
    .line 150
    iget-byte v1, v0, Lo/npkr;->aiupunrka:B

    .line 151
    .line 152
    or-int/2addr v1, v4

    .line 153
    int-to-byte v1, v1

    .line 154
    iput-byte v1, v0, Lo/npkr;->aiupunrka:B

    .line 155
    .line 156
    goto/16 :goto_0

    .line 157
    .line 158
    :cond_6
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 159
    .line 160
    .line 161
    invoke-virtual {v0}, Lo/npkr;->dpunpe()Lo/kidd;

    .line 162
    .line 163
    .line 164
    move-result-object p0

    .line 165
    return-object p0

    .line 166
    nop

    .line 167
    :sswitch_data_0
    .sparse-switch
        -0x3cc89b6d -> :sswitch_4
        -0x34e68a68 -> :sswitch_3
        0xdf3 -> :sswitch_2
        0x2ff57c -> :sswitch_1
        0x7eb2da74 -> :sswitch_0
    .end sparse-switch

    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
.end method

.method public static iiunkaippn(Landroid/util/JsonReader;)Lo/dnpidedind;
    .locals 31

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v1, Lo/kenreradaipn;

    .line 4
    .line 5
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0}, Landroid/util/JsonReader;->beginObject()V

    .line 9
    .line 10
    .line 11
    :goto_0
    invoke-virtual {v0}, Landroid/util/JsonReader;->hasNext()Z

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    if-eqz v2, :cond_3c

    .line 16
    .line 17
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    const/4 v9, 0x0

    .line 29
    const/4 v10, 0x1

    .line 30
    sparse-switch v3, :sswitch_data_0

    .line 31
    .line 32
    .line 33
    :goto_1
    const/4 v2, -0x1

    .line 34
    goto :goto_2

    .line 35
    :sswitch_0
    const-string v3, "timestamp"

    .line 36
    .line 37
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    if-nez v2, :cond_0

    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_0
    const/4 v2, 0x5

    .line 45
    goto :goto_2

    .line 46
    :sswitch_1
    const-string v3, "type"

    .line 47
    .line 48
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    if-nez v2, :cond_1

    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_1
    const/4 v2, 0x4

    .line 56
    goto :goto_2

    .line 57
    :sswitch_2
    const-string v3, "log"

    .line 58
    .line 59
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v2

    .line 63
    if-nez v2, :cond_2

    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_2
    const/4 v2, 0x3

    .line 67
    goto :goto_2

    .line 68
    :sswitch_3
    const-string v3, "app"

    .line 69
    .line 70
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v2

    .line 74
    if-nez v2, :cond_3

    .line 75
    .line 76
    goto :goto_1

    .line 77
    :cond_3
    const/4 v2, 0x2

    .line 78
    goto :goto_2

    .line 79
    :sswitch_4
    const-string v3, "rollouts"

    .line 80
    .line 81
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v2

    .line 85
    if-nez v2, :cond_4

    .line 86
    .line 87
    goto :goto_1

    .line 88
    :cond_4
    move v2, v10

    .line 89
    goto :goto_2

    .line 90
    :sswitch_5
    const-string v3, "device"

    .line 91
    .line 92
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v2

    .line 96
    if-nez v2, :cond_5

    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_5
    move v2, v9

    .line 100
    :goto_2
    const/16 v3, 0x10

    .line 101
    .line 102
    const/4 v11, 0x0

    .line 103
    packed-switch v2, :pswitch_data_0

    .line 104
    .line 105
    .line 106
    invoke-virtual {v0}, Landroid/util/JsonReader;->skipValue()V

    .line 107
    .line 108
    .line 109
    goto :goto_0

    .line 110
    :pswitch_0
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextLong()J

    .line 111
    .line 112
    .line 113
    move-result-wide v2

    .line 114
    iput-wide v2, v1, Lo/kenreradaipn;->dpunpe:J

    .line 115
    .line 116
    iget-byte v2, v1, Lo/kenreradaipn;->adadnadrr:B

    .line 117
    .line 118
    or-int/2addr v2, v10

    .line 119
    int-to-byte v2, v2

    .line 120
    iput-byte v2, v1, Lo/kenreradaipn;->adadnadrr:B

    .line 121
    .line 122
    goto :goto_0

    .line 123
    :pswitch_1
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    if-eqz v2, :cond_6

    .line 128
    .line 129
    iput-object v2, v1, Lo/kenreradaipn;->dpeakapiakpa:Ljava/lang/String;

    .line 130
    .line 131
    goto :goto_0

    .line 132
    :cond_6
    const-string v0, "Null type"

    .line 133
    .line 134
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    return-object v11

    .line 138
    :pswitch_2
    invoke-virtual {v0}, Landroid/util/JsonReader;->beginObject()V

    .line 139
    .line 140
    .line 141
    move-object v2, v11

    .line 142
    :goto_3
    invoke-virtual {v0}, Landroid/util/JsonReader;->hasNext()Z

    .line 143
    .line 144
    .line 145
    move-result v3

    .line 146
    if-eqz v3, :cond_9

    .line 147
    .line 148
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v3

    .line 152
    const-string v4, "content"

    .line 153
    .line 154
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v3

    .line 158
    if-eqz v3, :cond_8

    .line 159
    .line 160
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v2

    .line 164
    if-eqz v2, :cond_7

    .line 165
    .line 166
    goto :goto_3

    .line 167
    :cond_7
    const-string v0, "Null content"

    .line 168
    .line 169
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    return-object v11

    .line 173
    :cond_8
    invoke-virtual {v0}, Landroid/util/JsonReader;->skipValue()V

    .line 174
    .line 175
    .line 176
    goto :goto_3

    .line 177
    :cond_9
    invoke-virtual {v0}, Landroid/util/JsonReader;->endObject()V

    .line 178
    .line 179
    .line 180
    if-eqz v2, :cond_a

    .line 181
    .line 182
    new-instance v3, Lo/udkppkdikn;

    .line 183
    .line 184
    invoke-direct {v3, v2}, Lo/udkppkdikn;-><init>(Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    iput-object v3, v1, Lo/kenreradaipn;->iiunkaippn:Lo/ruiauaenura;

    .line 188
    .line 189
    goto/16 :goto_0

    .line 190
    .line 191
    :cond_a
    const-string v0, "Missing required properties: content"

    .line 192
    .line 193
    invoke-static {v0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    return-object v11

    .line 197
    :pswitch_3
    invoke-virtual {v0}, Landroid/util/JsonReader;->beginObject()V

    .line 198
    .line 199
    .line 200
    move v2, v9

    .line 201
    move/from16 v19, v2

    .line 202
    .line 203
    move-object v13, v11

    .line 204
    move-object v14, v13

    .line 205
    move-object v15, v14

    .line 206
    move-object/from16 v16, v15

    .line 207
    .line 208
    move-object/from16 v17, v16

    .line 209
    .line 210
    move-object/from16 v18, v17

    .line 211
    .line 212
    :goto_4
    invoke-virtual {v0}, Landroid/util/JsonReader;->hasNext()Z

    .line 213
    .line 214
    .line 215
    move-result v12

    .line 216
    const-string v4, "Missing required properties:"

    .line 217
    .line 218
    if-eqz v12, :cond_2c

    .line 219
    .line 220
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object v12

    .line 224
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 225
    .line 226
    .line 227
    invoke-virtual {v12}, Ljava/lang/String;->hashCode()I

    .line 228
    .line 229
    .line 230
    move-result v20

    .line 231
    sparse-switch v20, :sswitch_data_1

    .line 232
    .line 233
    .line 234
    :goto_5
    const/4 v5, -0x1

    .line 235
    goto :goto_6

    .line 236
    :sswitch_6
    const-string v5, "currentProcessDetails"

    .line 237
    .line 238
    invoke-virtual {v12, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 239
    .line 240
    .line 241
    move-result v5

    .line 242
    if-nez v5, :cond_b

    .line 243
    .line 244
    goto :goto_5

    .line 245
    :cond_b
    const/4 v5, 0x6

    .line 246
    goto :goto_6

    .line 247
    :sswitch_7
    const-string v5, "uiOrientation"

    .line 248
    .line 249
    invoke-virtual {v12, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 250
    .line 251
    .line 252
    move-result v5

    .line 253
    if-nez v5, :cond_c

    .line 254
    .line 255
    goto :goto_5

    .line 256
    :cond_c
    const/4 v5, 0x5

    .line 257
    goto :goto_6

    .line 258
    :sswitch_8
    const-string v5, "customAttributes"

    .line 259
    .line 260
    invoke-virtual {v12, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 261
    .line 262
    .line 263
    move-result v5

    .line 264
    if-nez v5, :cond_d

    .line 265
    .line 266
    goto :goto_5

    .line 267
    :cond_d
    const/4 v5, 0x4

    .line 268
    goto :goto_6

    .line 269
    :sswitch_9
    const-string v5, "internalKeys"

    .line 270
    .line 271
    invoke-virtual {v12, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    move-result v5

    .line 275
    if-nez v5, :cond_e

    .line 276
    .line 277
    goto :goto_5

    .line 278
    :cond_e
    const/4 v5, 0x3

    .line 279
    goto :goto_6

    .line 280
    :sswitch_a
    const-string v5, "execution"

    .line 281
    .line 282
    invoke-virtual {v12, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 283
    .line 284
    .line 285
    move-result v5

    .line 286
    if-nez v5, :cond_f

    .line 287
    .line 288
    goto :goto_5

    .line 289
    :cond_f
    const/4 v5, 0x2

    .line 290
    goto :goto_6

    .line 291
    :sswitch_b
    const-string v5, "background"

    .line 292
    .line 293
    invoke-virtual {v12, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 294
    .line 295
    .line 296
    move-result v5

    .line 297
    if-nez v5, :cond_10

    .line 298
    .line 299
    goto :goto_5

    .line 300
    :cond_10
    move v5, v10

    .line 301
    goto :goto_6

    .line 302
    :sswitch_c
    const-string v5, "appProcessDetails"

    .line 303
    .line 304
    invoke-virtual {v12, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 305
    .line 306
    .line 307
    move-result v5

    .line 308
    if-nez v5, :cond_11

    .line 309
    .line 310
    goto :goto_5

    .line 311
    :cond_11
    move v5, v9

    .line 312
    :goto_6
    packed-switch v5, :pswitch_data_1

    .line 313
    .line 314
    .line 315
    invoke-virtual {v0}, Landroid/util/JsonReader;->skipValue()V

    .line 316
    .line 317
    .line 318
    :goto_7
    move/from16 v28, v3

    .line 319
    .line 320
    :goto_8
    const/16 v29, 0x4

    .line 321
    .line 322
    const/16 v30, 0x2

    .line 323
    .line 324
    goto/16 :goto_16

    .line 325
    .line 326
    :pswitch_4
    invoke-static {v0}, Lo/aekpnkrpripi;->adadnadrr(Landroid/util/JsonReader;)Lo/riarpu;

    .line 327
    .line 328
    .line 329
    move-result-object v17

    .line 330
    goto :goto_7

    .line 331
    :pswitch_5
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextInt()I

    .line 332
    .line 333
    .line 334
    move-result v19

    .line 335
    move/from16 v28, v3

    .line 336
    .line 337
    move v2, v10

    .line 338
    goto :goto_8

    .line 339
    :pswitch_6
    new-instance v4, Ljava/util/ArrayList;

    .line 340
    .line 341
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 342
    .line 343
    .line 344
    invoke-virtual {v0}, Landroid/util/JsonReader;->beginArray()V

    .line 345
    .line 346
    .line 347
    :goto_9
    invoke-virtual {v0}, Landroid/util/JsonReader;->hasNext()Z

    .line 348
    .line 349
    .line 350
    move-result v5

    .line 351
    if-eqz v5, :cond_12

    .line 352
    .line 353
    invoke-static {v0}, Lo/aekpnkrpripi;->dpeakapiakpa(Landroid/util/JsonReader;)Lo/kdeunek;

    .line 354
    .line 355
    .line 356
    move-result-object v5

    .line 357
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 358
    .line 359
    .line 360
    goto :goto_9

    .line 361
    :cond_12
    invoke-virtual {v0}, Landroid/util/JsonReader;->endArray()V

    .line 362
    .line 363
    .line 364
    invoke-static {v4}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 365
    .line 366
    .line 367
    move-result-object v14

    .line 368
    goto :goto_7

    .line 369
    :pswitch_7
    new-instance v4, Ljava/util/ArrayList;

    .line 370
    .line 371
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 372
    .line 373
    .line 374
    invoke-virtual {v0}, Landroid/util/JsonReader;->beginArray()V

    .line 375
    .line 376
    .line 377
    :goto_a
    invoke-virtual {v0}, Landroid/util/JsonReader;->hasNext()Z

    .line 378
    .line 379
    .line 380
    move-result v5

    .line 381
    if-eqz v5, :cond_13

    .line 382
    .line 383
    invoke-static {v0}, Lo/aekpnkrpripi;->dpeakapiakpa(Landroid/util/JsonReader;)Lo/kdeunek;

    .line 384
    .line 385
    .line 386
    move-result-object v5

    .line 387
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 388
    .line 389
    .line 390
    goto :goto_a

    .line 391
    :cond_13
    invoke-virtual {v0}, Landroid/util/JsonReader;->endArray()V

    .line 392
    .line 393
    .line 394
    invoke-static {v4}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 395
    .line 396
    .line 397
    move-result-object v15

    .line 398
    goto :goto_7

    .line 399
    :pswitch_8
    invoke-virtual {v0}, Landroid/util/JsonReader;->beginObject()V

    .line 400
    .line 401
    .line 402
    move-object/from16 v22, v11

    .line 403
    .line 404
    move-object/from16 v23, v22

    .line 405
    .line 406
    move-object/from16 v24, v23

    .line 407
    .line 408
    move-object/from16 v25, v24

    .line 409
    .line 410
    move-object/from16 v26, v25

    .line 411
    .line 412
    move-object/from16 v27, v26

    .line 413
    .line 414
    :goto_b
    invoke-virtual {v0}, Landroid/util/JsonReader;->hasNext()Z

    .line 415
    .line 416
    .line 417
    move-result v5

    .line 418
    if-eqz v5, :cond_26

    .line 419
    .line 420
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 421
    .line 422
    .line 423
    move-result-object v5

    .line 424
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 425
    .line 426
    .line 427
    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    .line 428
    .line 429
    .line 430
    move-result v12

    .line 431
    sparse-switch v12, :sswitch_data_2

    .line 432
    .line 433
    .line 434
    :goto_c
    const/4 v5, -0x1

    .line 435
    goto :goto_d

    .line 436
    :sswitch_d
    const-string v12, "exception"

    .line 437
    .line 438
    invoke-virtual {v5, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 439
    .line 440
    .line 441
    move-result v5

    .line 442
    if-nez v5, :cond_14

    .line 443
    .line 444
    goto :goto_c

    .line 445
    :cond_14
    const/4 v5, 0x5

    .line 446
    goto :goto_d

    .line 447
    :sswitch_e
    const-string v12, "profilingManagerInfo"

    .line 448
    .line 449
    invoke-virtual {v5, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 450
    .line 451
    .line 452
    move-result v5

    .line 453
    if-nez v5, :cond_15

    .line 454
    .line 455
    goto :goto_c

    .line 456
    :cond_15
    const/4 v5, 0x4

    .line 457
    goto :goto_d

    .line 458
    :sswitch_f
    const-string v12, "binaries"

    .line 459
    .line 460
    invoke-virtual {v5, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 461
    .line 462
    .line 463
    move-result v5

    .line 464
    if-nez v5, :cond_16

    .line 465
    .line 466
    goto :goto_c

    .line 467
    :cond_16
    const/4 v5, 0x3

    .line 468
    goto :goto_d

    .line 469
    :sswitch_10
    const-string v12, "signal"

    .line 470
    .line 471
    invoke-virtual {v5, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 472
    .line 473
    .line 474
    move-result v5

    .line 475
    if-nez v5, :cond_17

    .line 476
    .line 477
    goto :goto_c

    .line 478
    :cond_17
    const/4 v5, 0x2

    .line 479
    goto :goto_d

    .line 480
    :sswitch_11
    const-string v12, "threads"

    .line 481
    .line 482
    invoke-virtual {v5, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 483
    .line 484
    .line 485
    move-result v5

    .line 486
    if-nez v5, :cond_18

    .line 487
    .line 488
    goto :goto_c

    .line 489
    :cond_18
    move v5, v10

    .line 490
    goto :goto_d

    .line 491
    :sswitch_12
    const-string v12, "appExitInfo"

    .line 492
    .line 493
    invoke-virtual {v5, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 494
    .line 495
    .line 496
    move-result v5

    .line 497
    if-nez v5, :cond_19

    .line 498
    .line 499
    goto :goto_c

    .line 500
    :cond_19
    move v5, v9

    .line 501
    :goto_d
    packed-switch v5, :pswitch_data_2

    .line 502
    .line 503
    .line 504
    invoke-virtual {v0}, Landroid/util/JsonReader;->skipValue()V

    .line 505
    .line 506
    .line 507
    :goto_e
    move/from16 v28, v3

    .line 508
    .line 509
    const/16 v29, 0x4

    .line 510
    .line 511
    const/16 v30, 0x2

    .line 512
    .line 513
    goto/16 :goto_13

    .line 514
    .line 515
    :pswitch_9
    invoke-static {v0}, Lo/aekpnkrpripi;->aiupunrka(Landroid/util/JsonReader;)Lo/dukar;

    .line 516
    .line 517
    .line 518
    move-result-object v23

    .line 519
    goto :goto_e

    .line 520
    :pswitch_a
    invoke-static {v0}, Lo/aekpnkrpripi;->dedr(Landroid/util/JsonReader;)Lo/pkdniunanrap;

    .line 521
    .line 522
    .line 523
    move-result-object v25

    .line 524
    goto :goto_e

    .line 525
    :pswitch_b
    new-instance v5, Lo/kniuuerekaup;

    .line 526
    .line 527
    invoke-direct {v5, v3}, Lo/kniuuerekaup;-><init>(I)V

    .line 528
    .line 529
    .line 530
    invoke-static {v0, v5}, Lo/aekpnkrpripi;->irkari(Landroid/util/JsonReader;Lo/kniuuerekaup;)Ljava/util/List;

    .line 531
    .line 532
    .line 533
    move-result-object v27

    .line 534
    if-eqz v27, :cond_1a

    .line 535
    .line 536
    goto :goto_e

    .line 537
    :cond_1a
    const-string v0, "Null binaries"

    .line 538
    .line 539
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 540
    .line 541
    .line 542
    return-object v11

    .line 543
    :pswitch_c
    invoke-virtual {v0}, Landroid/util/JsonReader;->beginObject()V

    .line 544
    .line 545
    .line 546
    const-wide/16 v12, 0x0

    .line 547
    .line 548
    move/from16 v28, v3

    .line 549
    .line 550
    move v5, v9

    .line 551
    move-object v3, v11

    .line 552
    move-object v6, v3

    .line 553
    const/16 v29, 0x4

    .line 554
    .line 555
    :goto_f
    invoke-virtual {v0}, Landroid/util/JsonReader;->hasNext()Z

    .line 556
    .line 557
    .line 558
    move-result v21

    .line 559
    if-eqz v21, :cond_20

    .line 560
    .line 561
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 562
    .line 563
    .line 564
    move-result-object v7

    .line 565
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 566
    .line 567
    .line 568
    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    .line 569
    .line 570
    .line 571
    move-result v21

    .line 572
    sparse-switch v21, :sswitch_data_3

    .line 573
    .line 574
    .line 575
    const/4 v7, -0x1

    .line 576
    const/16 v30, 0x2

    .line 577
    .line 578
    goto :goto_11

    .line 579
    :sswitch_13
    const/16 v30, 0x2

    .line 580
    .line 581
    const-string v8, "name"

    .line 582
    .line 583
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 584
    .line 585
    .line 586
    move-result v7

    .line 587
    if-nez v7, :cond_1b

    .line 588
    .line 589
    goto :goto_10

    .line 590
    :cond_1b
    move/from16 v7, v30

    .line 591
    .line 592
    goto :goto_11

    .line 593
    :sswitch_14
    const/16 v30, 0x2

    .line 594
    .line 595
    const-string v8, "code"

    .line 596
    .line 597
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 598
    .line 599
    .line 600
    move-result v7

    .line 601
    if-nez v7, :cond_1c

    .line 602
    .line 603
    goto :goto_10

    .line 604
    :cond_1c
    move v7, v10

    .line 605
    goto :goto_11

    .line 606
    :sswitch_15
    const/16 v30, 0x2

    .line 607
    .line 608
    const-string v8, "address"

    .line 609
    .line 610
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 611
    .line 612
    .line 613
    move-result v7

    .line 614
    if-nez v7, :cond_1d

    .line 615
    .line 616
    :goto_10
    const/4 v7, -0x1

    .line 617
    goto :goto_11

    .line 618
    :cond_1d
    move v7, v9

    .line 619
    :goto_11
    packed-switch v7, :pswitch_data_3

    .line 620
    .line 621
    .line 622
    invoke-virtual {v0}, Landroid/util/JsonReader;->skipValue()V

    .line 623
    .line 624
    .line 625
    goto :goto_f

    .line 626
    :pswitch_d
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 627
    .line 628
    .line 629
    move-result-object v3

    .line 630
    if-eqz v3, :cond_1e

    .line 631
    .line 632
    goto :goto_f

    .line 633
    :cond_1e
    const-string v0, "Null name"

    .line 634
    .line 635
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 636
    .line 637
    .line 638
    return-object v11

    .line 639
    :pswitch_e
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 640
    .line 641
    .line 642
    move-result-object v6

    .line 643
    if-eqz v6, :cond_1f

    .line 644
    .line 645
    goto :goto_f

    .line 646
    :cond_1f
    const-string v0, "Null code"

    .line 647
    .line 648
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 649
    .line 650
    .line 651
    return-object v11

    .line 652
    :pswitch_f
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextLong()J

    .line 653
    .line 654
    .line 655
    move-result-wide v7

    .line 656
    or-int/lit8 v5, v5, 0x1

    .line 657
    .line 658
    int-to-byte v5, v5

    .line 659
    move-wide v12, v7

    .line 660
    goto :goto_f

    .line 661
    :cond_20
    const/16 v30, 0x2

    .line 662
    .line 663
    invoke-virtual {v0}, Landroid/util/JsonReader;->endObject()V

    .line 664
    .line 665
    .line 666
    if-ne v5, v10, :cond_22

    .line 667
    .line 668
    if-eqz v3, :cond_22

    .line 669
    .line 670
    if-nez v6, :cond_21

    .line 671
    .line 672
    goto :goto_12

    .line 673
    :cond_21
    new-instance v5, Lo/nduknu;

    .line 674
    .line 675
    invoke-direct {v5, v3, v6, v12, v13}, Lo/nduknu;-><init>(Ljava/lang/String;Ljava/lang/String;J)V

    .line 676
    .line 677
    .line 678
    move-object/from16 v26, v5

    .line 679
    .line 680
    goto :goto_13

    .line 681
    :cond_22
    :goto_12
    new-instance v0, Ljava/lang/StringBuilder;

    .line 682
    .line 683
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 684
    .line 685
    .line 686
    if-nez v3, :cond_23

    .line 687
    .line 688
    const-string v1, " name"

    .line 689
    .line 690
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 691
    .line 692
    .line 693
    :cond_23
    if-nez v6, :cond_24

    .line 694
    .line 695
    const-string v1, " code"

    .line 696
    .line 697
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 698
    .line 699
    .line 700
    :cond_24
    and-int/lit8 v1, v5, 0x1

    .line 701
    .line 702
    if-nez v1, :cond_25

    .line 703
    .line 704
    const-string v1, " address"

    .line 705
    .line 706
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 707
    .line 708
    .line 709
    :cond_25
    invoke-static {v4, v0}, Lo/nrkepnpirid;->ndpnikda(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 710
    .line 711
    .line 712
    move-result-object v0

    .line 713
    invoke-static {v0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 714
    .line 715
    .line 716
    return-object v11

    .line 717
    :pswitch_10
    move/from16 v28, v3

    .line 718
    .line 719
    const/16 v29, 0x4

    .line 720
    .line 721
    const/16 v30, 0x2

    .line 722
    .line 723
    new-instance v3, Lo/kniuuerekaup;

    .line 724
    .line 725
    const/16 v5, 0xf

    .line 726
    .line 727
    invoke-direct {v3, v5}, Lo/kniuuerekaup;-><init>(I)V

    .line 728
    .line 729
    .line 730
    invoke-static {v0, v3}, Lo/aekpnkrpripi;->irkari(Landroid/util/JsonReader;Lo/kniuuerekaup;)Ljava/util/List;

    .line 731
    .line 732
    .line 733
    move-result-object v22

    .line 734
    goto :goto_13

    .line 735
    :pswitch_11
    move/from16 v28, v3

    .line 736
    .line 737
    const/16 v29, 0x4

    .line 738
    .line 739
    const/16 v30, 0x2

    .line 740
    .line 741
    invoke-static {v0}, Lo/aekpnkrpripi;->pepeunri(Landroid/util/JsonReader;)Lo/diikaeukernu;

    .line 742
    .line 743
    .line 744
    move-result-object v24

    .line 745
    :goto_13
    move/from16 v3, v28

    .line 746
    .line 747
    goto/16 :goto_b

    .line 748
    .line 749
    :cond_26
    move/from16 v28, v3

    .line 750
    .line 751
    const/16 v29, 0x4

    .line 752
    .line 753
    const/16 v30, 0x2

    .line 754
    .line 755
    invoke-virtual {v0}, Landroid/util/JsonReader;->endObject()V

    .line 756
    .line 757
    .line 758
    if-eqz v26, :cond_28

    .line 759
    .line 760
    if-nez v27, :cond_27

    .line 761
    .line 762
    goto :goto_14

    .line 763
    :cond_27
    new-instance v21, Lo/iaind;

    .line 764
    .line 765
    invoke-direct/range {v21 .. v27}, Lo/iaind;-><init>(Ljava/util/List;Lo/knuuripa;Lo/kkiiiped;Lo/eipip;Lo/nduknu;Ljava/util/List;)V

    .line 766
    .line 767
    .line 768
    move-object/from16 v13, v21

    .line 769
    .line 770
    goto :goto_16

    .line 771
    :cond_28
    :goto_14
    new-instance v0, Ljava/lang/StringBuilder;

    .line 772
    .line 773
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 774
    .line 775
    .line 776
    if-nez v26, :cond_29

    .line 777
    .line 778
    const-string v1, " signal"

    .line 779
    .line 780
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 781
    .line 782
    .line 783
    :cond_29
    if-nez v27, :cond_2a

    .line 784
    .line 785
    const-string v1, " binaries"

    .line 786
    .line 787
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 788
    .line 789
    .line 790
    :cond_2a
    invoke-static {v4, v0}, Lo/nrkepnpirid;->ndpnikda(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 791
    .line 792
    .line 793
    move-result-object v0

    .line 794
    invoke-static {v0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 795
    .line 796
    .line 797
    return-object v11

    .line 798
    :pswitch_12
    move/from16 v28, v3

    .line 799
    .line 800
    const/16 v29, 0x4

    .line 801
    .line 802
    const/16 v30, 0x2

    .line 803
    .line 804
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextBoolean()Z

    .line 805
    .line 806
    .line 807
    move-result v3

    .line 808
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 809
    .line 810
    .line 811
    move-result-object v16

    .line 812
    goto :goto_16

    .line 813
    :pswitch_13
    move/from16 v28, v3

    .line 814
    .line 815
    const/16 v29, 0x4

    .line 816
    .line 817
    const/16 v30, 0x2

    .line 818
    .line 819
    new-instance v3, Ljava/util/ArrayList;

    .line 820
    .line 821
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 822
    .line 823
    .line 824
    invoke-virtual {v0}, Landroid/util/JsonReader;->beginArray()V

    .line 825
    .line 826
    .line 827
    :goto_15
    invoke-virtual {v0}, Landroid/util/JsonReader;->hasNext()Z

    .line 828
    .line 829
    .line 830
    move-result v4

    .line 831
    if-eqz v4, :cond_2b

    .line 832
    .line 833
    invoke-static {v0}, Lo/aekpnkrpripi;->adadnadrr(Landroid/util/JsonReader;)Lo/riarpu;

    .line 834
    .line 835
    .line 836
    move-result-object v4

    .line 837
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 838
    .line 839
    .line 840
    goto :goto_15

    .line 841
    :cond_2b
    invoke-virtual {v0}, Landroid/util/JsonReader;->endArray()V

    .line 842
    .line 843
    .line 844
    invoke-static {v3}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 845
    .line 846
    .line 847
    move-result-object v18

    .line 848
    :goto_16
    move/from16 v3, v28

    .line 849
    .line 850
    goto/16 :goto_4

    .line 851
    .line 852
    :cond_2c
    invoke-virtual {v0}, Landroid/util/JsonReader;->endObject()V

    .line 853
    .line 854
    .line 855
    if-ne v2, v10, :cond_2e

    .line 856
    .line 857
    if-nez v13, :cond_2d

    .line 858
    .line 859
    goto :goto_17

    .line 860
    :cond_2d
    new-instance v12, Lo/krknuidau;

    .line 861
    .line 862
    invoke-direct/range {v12 .. v19}, Lo/krknuidau;-><init>(Lo/kdriuua;Ljava/util/List;Ljava/util/List;Ljava/lang/Boolean;Lo/iapkpnauiu;Ljava/util/List;I)V

    .line 863
    .line 864
    .line 865
    iput-object v12, v1, Lo/kenreradaipn;->pepeunri:Lo/eeraudnu;

    .line 866
    .line 867
    goto/16 :goto_0

    .line 868
    .line 869
    :cond_2e
    :goto_17
    new-instance v0, Ljava/lang/StringBuilder;

    .line 870
    .line 871
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 872
    .line 873
    .line 874
    if-nez v13, :cond_2f

    .line 875
    .line 876
    const-string v1, " execution"

    .line 877
    .line 878
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 879
    .line 880
    .line 881
    :cond_2f
    if-nez v2, :cond_30

    .line 882
    .line 883
    const-string v1, " uiOrientation"

    .line 884
    .line 885
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 886
    .line 887
    .line 888
    :cond_30
    invoke-static {v4, v0}, Lo/nrkepnpirid;->ndpnikda(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 889
    .line 890
    .line 891
    move-result-object v0

    .line 892
    invoke-static {v0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 893
    .line 894
    .line 895
    return-object v11

    .line 896
    :pswitch_14
    invoke-virtual {v0}, Landroid/util/JsonReader;->beginObject()V

    .line 897
    .line 898
    .line 899
    move-object v2, v11

    .line 900
    :goto_18
    invoke-virtual {v0}, Landroid/util/JsonReader;->hasNext()Z

    .line 901
    .line 902
    .line 903
    move-result v3

    .line 904
    if-eqz v3, :cond_33

    .line 905
    .line 906
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 907
    .line 908
    .line 909
    move-result-object v3

    .line 910
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 911
    .line 912
    .line 913
    const-string v4, "assignments"

    .line 914
    .line 915
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 916
    .line 917
    .line 918
    move-result v3

    .line 919
    if-nez v3, :cond_31

    .line 920
    .line 921
    invoke-virtual {v0}, Landroid/util/JsonReader;->skipValue()V

    .line 922
    .line 923
    .line 924
    goto :goto_18

    .line 925
    :cond_31
    new-instance v2, Lo/kniuuerekaup;

    .line 926
    .line 927
    const/16 v3, 0xe

    .line 928
    .line 929
    invoke-direct {v2, v3}, Lo/kniuuerekaup;-><init>(I)V

    .line 930
    .line 931
    .line 932
    invoke-static {v0, v2}, Lo/aekpnkrpripi;->irkari(Landroid/util/JsonReader;Lo/kniuuerekaup;)Ljava/util/List;

    .line 933
    .line 934
    .line 935
    move-result-object v2

    .line 936
    if-eqz v2, :cond_32

    .line 937
    .line 938
    goto :goto_18

    .line 939
    :cond_32
    const-string v0, "Null rolloutAssignments"

    .line 940
    .line 941
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 942
    .line 943
    .line 944
    return-object v11

    .line 945
    :cond_33
    invoke-virtual {v0}, Landroid/util/JsonReader;->endObject()V

    .line 946
    .line 947
    .line 948
    if-eqz v2, :cond_34

    .line 949
    .line 950
    new-instance v3, Lo/dnkk;

    .line 951
    .line 952
    invoke-direct {v3, v2}, Lo/dnkk;-><init>(Ljava/util/List;)V

    .line 953
    .line 954
    .line 955
    iput-object v3, v1, Lo/kenreradaipn;->aiupunrka:Lo/euir;

    .line 956
    .line 957
    goto/16 :goto_0

    .line 958
    .line 959
    :cond_34
    const-string v0, "Missing required properties: rolloutAssignments"

    .line 960
    .line 961
    invoke-static {v0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 962
    .line 963
    .line 964
    return-object v11

    .line 965
    :pswitch_15
    move/from16 v28, v3

    .line 966
    .line 967
    const/16 v29, 0x4

    .line 968
    .line 969
    const/16 v30, 0x2

    .line 970
    .line 971
    new-instance v2, Lo/rinnndipui;

    .line 972
    .line 973
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 974
    .line 975
    .line 976
    invoke-virtual {v0}, Landroid/util/JsonReader;->beginObject()V

    .line 977
    .line 978
    .line 979
    :goto_19
    invoke-virtual {v0}, Landroid/util/JsonReader;->hasNext()Z

    .line 980
    .line 981
    .line 982
    move-result v3

    .line 983
    if-eqz v3, :cond_3b

    .line 984
    .line 985
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 986
    .line 987
    .line 988
    move-result-object v3

    .line 989
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 990
    .line 991
    .line 992
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 993
    .line 994
    .line 995
    move-result v4

    .line 996
    sparse-switch v4, :sswitch_data_4

    .line 997
    .line 998
    .line 999
    :goto_1a
    const/4 v3, -0x1

    .line 1000
    goto :goto_1b

    .line 1001
    :sswitch_16
    const-string v4, "proximityOn"

    .line 1002
    .line 1003
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1004
    .line 1005
    .line 1006
    move-result v3

    .line 1007
    if-nez v3, :cond_35

    .line 1008
    .line 1009
    goto :goto_1a

    .line 1010
    :cond_35
    const/4 v3, 0x5

    .line 1011
    goto :goto_1b

    .line 1012
    :sswitch_17
    const-string v4, "ramUsed"

    .line 1013
    .line 1014
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1015
    .line 1016
    .line 1017
    move-result v3

    .line 1018
    if-nez v3, :cond_36

    .line 1019
    .line 1020
    goto :goto_1a

    .line 1021
    :cond_36
    move/from16 v3, v29

    .line 1022
    .line 1023
    goto :goto_1b

    .line 1024
    :sswitch_18
    const-string v4, "diskUsed"

    .line 1025
    .line 1026
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1027
    .line 1028
    .line 1029
    move-result v3

    .line 1030
    if-nez v3, :cond_37

    .line 1031
    .line 1032
    goto :goto_1a

    .line 1033
    :cond_37
    const/4 v3, 0x3

    .line 1034
    goto :goto_1b

    .line 1035
    :sswitch_19
    const-string v4, "orientation"

    .line 1036
    .line 1037
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1038
    .line 1039
    .line 1040
    move-result v3

    .line 1041
    if-nez v3, :cond_38

    .line 1042
    .line 1043
    goto :goto_1a

    .line 1044
    :cond_38
    move/from16 v3, v30

    .line 1045
    .line 1046
    goto :goto_1b

    .line 1047
    :sswitch_1a
    const-string v4, "batteryVelocity"

    .line 1048
    .line 1049
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1050
    .line 1051
    .line 1052
    move-result v3

    .line 1053
    if-nez v3, :cond_39

    .line 1054
    .line 1055
    goto :goto_1a

    .line 1056
    :cond_39
    move v3, v10

    .line 1057
    goto :goto_1b

    .line 1058
    :sswitch_1b
    const-string v4, "batteryLevel"

    .line 1059
    .line 1060
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1061
    .line 1062
    .line 1063
    move-result v3

    .line 1064
    if-nez v3, :cond_3a

    .line 1065
    .line 1066
    goto :goto_1a

    .line 1067
    :cond_3a
    move v3, v9

    .line 1068
    :goto_1b
    packed-switch v3, :pswitch_data_4

    .line 1069
    .line 1070
    .line 1071
    invoke-virtual {v0}, Landroid/util/JsonReader;->skipValue()V

    .line 1072
    .line 1073
    .line 1074
    goto :goto_19

    .line 1075
    :pswitch_16
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextBoolean()Z

    .line 1076
    .line 1077
    .line 1078
    move-result v3

    .line 1079
    iput-boolean v3, v2, Lo/rinnndipui;->pepeunri:Z

    .line 1080
    .line 1081
    iget-byte v3, v2, Lo/rinnndipui;->adadnadrr:B

    .line 1082
    .line 1083
    or-int/lit8 v3, v3, 0x2

    .line 1084
    .line 1085
    int-to-byte v3, v3

    .line 1086
    iput-byte v3, v2, Lo/rinnndipui;->adadnadrr:B

    .line 1087
    .line 1088
    goto :goto_19

    .line 1089
    :pswitch_17
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextLong()J

    .line 1090
    .line 1091
    .line 1092
    move-result-wide v3

    .line 1093
    iput-wide v3, v2, Lo/rinnndipui;->iiunkaippn:J

    .line 1094
    .line 1095
    iget-byte v3, v2, Lo/rinnndipui;->adadnadrr:B

    .line 1096
    .line 1097
    or-int/lit8 v3, v3, 0x8

    .line 1098
    .line 1099
    int-to-byte v3, v3

    .line 1100
    iput-byte v3, v2, Lo/rinnndipui;->adadnadrr:B

    .line 1101
    .line 1102
    goto :goto_19

    .line 1103
    :pswitch_18
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextLong()J

    .line 1104
    .line 1105
    .line 1106
    move-result-wide v3

    .line 1107
    iput-wide v3, v2, Lo/rinnndipui;->aiupunrka:J

    .line 1108
    .line 1109
    iget-byte v3, v2, Lo/rinnndipui;->adadnadrr:B

    .line 1110
    .line 1111
    or-int/lit8 v3, v3, 0x10

    .line 1112
    .line 1113
    int-to-byte v3, v3

    .line 1114
    iput-byte v3, v2, Lo/rinnndipui;->adadnadrr:B

    .line 1115
    .line 1116
    goto/16 :goto_19

    .line 1117
    .line 1118
    :pswitch_19
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextInt()I

    .line 1119
    .line 1120
    .line 1121
    move-result v3

    .line 1122
    iput v3, v2, Lo/rinnndipui;->irkari:I

    .line 1123
    .line 1124
    iget-byte v3, v2, Lo/rinnndipui;->adadnadrr:B

    .line 1125
    .line 1126
    or-int/lit8 v3, v3, 0x4

    .line 1127
    .line 1128
    int-to-byte v3, v3

    .line 1129
    iput-byte v3, v2, Lo/rinnndipui;->adadnadrr:B

    .line 1130
    .line 1131
    goto/16 :goto_19

    .line 1132
    .line 1133
    :pswitch_1a
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextInt()I

    .line 1134
    .line 1135
    .line 1136
    move-result v3

    .line 1137
    iput v3, v2, Lo/rinnndipui;->dpeakapiakpa:I

    .line 1138
    .line 1139
    iget-byte v3, v2, Lo/rinnndipui;->adadnadrr:B

    .line 1140
    .line 1141
    or-int/2addr v3, v10

    .line 1142
    int-to-byte v3, v3

    .line 1143
    iput-byte v3, v2, Lo/rinnndipui;->adadnadrr:B

    .line 1144
    .line 1145
    goto/16 :goto_19

    .line 1146
    .line 1147
    :pswitch_1b
    invoke-virtual {v0}, Landroid/util/JsonReader;->nextDouble()D

    .line 1148
    .line 1149
    .line 1150
    move-result-wide v3

    .line 1151
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 1152
    .line 1153
    .line 1154
    move-result-object v3

    .line 1155
    iput-object v3, v2, Lo/rinnndipui;->dpunpe:Ljava/lang/Double;

    .line 1156
    .line 1157
    goto/16 :goto_19

    .line 1158
    .line 1159
    :cond_3b
    invoke-virtual {v0}, Landroid/util/JsonReader;->endObject()V

    .line 1160
    .line 1161
    .line 1162
    invoke-virtual {v2}, Lo/rinnndipui;->dpunpe()Lo/rdpi;

    .line 1163
    .line 1164
    .line 1165
    move-result-object v2

    .line 1166
    iput-object v2, v1, Lo/kenreradaipn;->irkari:Lo/neiaerani;

    .line 1167
    .line 1168
    goto/16 :goto_0

    .line 1169
    .line 1170
    :cond_3c
    invoke-virtual {v0}, Landroid/util/JsonReader;->endObject()V

    .line 1171
    .line 1172
    .line 1173
    invoke-virtual {v1}, Lo/kenreradaipn;->dpunpe()Lo/dnpidedind;

    .line 1174
    .line 1175
    .line 1176
    move-result-object v0

    .line 1177
    return-object v0

    .line 1178
    nop

    .line 1179
    :sswitch_data_0
    .sparse-switch
        -0x4f94e1aa -> :sswitch_5
        -0xf74cb1e -> :sswitch_4
        0x17a21 -> :sswitch_3
        0x1a344 -> :sswitch_2
        0x368f3a -> :sswitch_1
        0x3492916 -> :sswitch_0
    .end sparse-switch

    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_15
        :pswitch_14
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    :sswitch_data_1
    .sparse-switch
        -0x53c366ac -> :sswitch_c
        -0x4f67aad2 -> :sswitch_b
        -0x4106f4e8 -> :sswitch_a
        -0x4c83daf -> :sswitch_9
        0x211737a8 -> :sswitch_8
        0x375b6a9c -> :sswitch_7
        0x6e2222ac -> :sswitch_6
    .end sparse-switch

    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_13
        :pswitch_12
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
    .end packed-switch

    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    :sswitch_data_2
    .sparse-switch
        -0x51f6ffd3 -> :sswitch_12
        -0x4fbf4c57 -> :sswitch_11
        -0x35ca9158 -> :sswitch_10
        0x37e2e05f -> :sswitch_f
        0x577b9df5 -> :sswitch_e
        0x584fd04f -> :sswitch_d
    .end sparse-switch

    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
    .end packed-switch

    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    :sswitch_data_3
    .sparse-switch
        -0x4468640c -> :sswitch_15
        0x2eaded -> :sswitch_14
        0x337a8b -> :sswitch_13
    .end sparse-switch

    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    :pswitch_data_3
    .packed-switch 0x0
        :pswitch_f
        :pswitch_e
        :pswitch_d
    .end packed-switch

    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    :sswitch_data_4
    .sparse-switch
        -0x65d74289 -> :sswitch_1b
        -0x56c20df6 -> :sswitch_1a
        -0x55cd0a30 -> :sswitch_19
        0x10ad56fa -> :sswitch_18
        0x3a34d8fb -> :sswitch_17
        0x5a6876be -> :sswitch_16
    .end sparse-switch

    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    :pswitch_data_4
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
    .end packed-switch
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
.end method

.method public static irkari(Landroid/util/JsonReader;Lo/kniuuerekaup;)Ljava/util/List;
    .locals 22

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->beginArray()V

    .line 7
    .line 8
    .line 9
    :goto_0
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_3b

    .line 14
    .line 15
    move-object/from16 v1, p1

    .line 16
    .line 17
    iget v2, v1, Lo/kniuuerekaup;->dikdannunk:I

    .line 18
    .line 19
    const-string v3, " name"

    .line 20
    .line 21
    const-string v4, "Null name"

    .line 22
    .line 23
    const-string v5, "name"

    .line 24
    .line 25
    const/4 v6, 0x3

    .line 26
    const-string v8, "Missing required properties:"

    .line 27
    .line 28
    const/4 v9, 0x0

    .line 29
    const/4 v10, 0x2

    .line 30
    const/4 v11, 0x1

    .line 31
    const/4 v12, 0x0

    .line 32
    packed-switch v2, :pswitch_data_0

    .line 33
    .line 34
    .line 35
    invoke-static/range {p0 .. p0}, Lo/aekpnkrpripi;->dpunpe(Landroid/util/JsonReader;)Lo/kidd;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    move-object/from16 v15, p0

    .line 40
    .line 41
    goto/16 :goto_17

    .line 42
    .line 43
    :pswitch_0
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->beginObject()V

    .line 44
    .line 45
    .line 46
    const-wide/16 v13, 0x0

    .line 47
    .line 48
    move v2, v9

    .line 49
    move-object/from16 v20, v12

    .line 50
    .line 51
    move-object/from16 v21, v20

    .line 52
    .line 53
    move-wide/from16 v16, v13

    .line 54
    .line 55
    move-wide/from16 v18, v16

    .line 56
    .line 57
    :goto_1
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 58
    .line 59
    .line 60
    move-result v13

    .line 61
    if-eqz v13, :cond_5

    .line 62
    .line 63
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v13

    .line 67
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    .line 69
    .line 70
    invoke-virtual {v13}, Ljava/lang/String;->hashCode()I

    .line 71
    .line 72
    .line 73
    move-result v14

    .line 74
    sparse-switch v14, :sswitch_data_0

    .line 75
    .line 76
    .line 77
    :goto_2
    const/4 v13, -0x1

    .line 78
    goto :goto_3

    .line 79
    :sswitch_0
    const-string v14, "baseAddress"

    .line 80
    .line 81
    invoke-virtual {v13, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v13

    .line 85
    if-nez v13, :cond_0

    .line 86
    .line 87
    goto :goto_2

    .line 88
    :cond_0
    move v13, v6

    .line 89
    goto :goto_3

    .line 90
    :sswitch_1
    const-string v14, "uuid"

    .line 91
    .line 92
    invoke-virtual {v13, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v13

    .line 96
    if-nez v13, :cond_1

    .line 97
    .line 98
    goto :goto_2

    .line 99
    :cond_1
    move v13, v10

    .line 100
    goto :goto_3

    .line 101
    :sswitch_2
    const-string v14, "size"

    .line 102
    .line 103
    invoke-virtual {v13, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    move-result v13

    .line 107
    if-nez v13, :cond_2

    .line 108
    .line 109
    goto :goto_2

    .line 110
    :cond_2
    move v13, v11

    .line 111
    goto :goto_3

    .line 112
    :sswitch_3
    invoke-virtual {v13, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result v13

    .line 116
    if-nez v13, :cond_3

    .line 117
    .line 118
    goto :goto_2

    .line 119
    :cond_3
    move v13, v9

    .line 120
    :goto_3
    packed-switch v13, :pswitch_data_1

    .line 121
    .line 122
    .line 123
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->skipValue()V

    .line 124
    .line 125
    .line 126
    goto :goto_1

    .line 127
    :pswitch_1
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextLong()J

    .line 128
    .line 129
    .line 130
    move-result-wide v13

    .line 131
    or-int/lit8 v2, v2, 0x1

    .line 132
    .line 133
    int-to-byte v2, v2

    .line 134
    move-wide/from16 v16, v13

    .line 135
    .line 136
    goto :goto_1

    .line 137
    :pswitch_2
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v13

    .line 141
    invoke-static {v13, v10}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 142
    .line 143
    .line 144
    move-result-object v13

    .line 145
    new-instance v14, Ljava/lang/String;

    .line 146
    .line 147
    sget-object v15, Lo/rnea;->dpunpe:Ljava/nio/charset/Charset;

    .line 148
    .line 149
    invoke-direct {v14, v13, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 150
    .line 151
    .line 152
    move-object/from16 v21, v14

    .line 153
    .line 154
    goto :goto_1

    .line 155
    :pswitch_3
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextLong()J

    .line 156
    .line 157
    .line 158
    move-result-wide v13

    .line 159
    or-int/lit8 v2, v2, 0x2

    .line 160
    .line 161
    int-to-byte v2, v2

    .line 162
    move-wide/from16 v18, v13

    .line 163
    .line 164
    goto :goto_1

    .line 165
    :pswitch_4
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object v20

    .line 169
    if-eqz v20, :cond_4

    .line 170
    .line 171
    goto :goto_1

    .line 172
    :cond_4
    invoke-static {v4}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    goto :goto_5

    .line 176
    :cond_5
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->endObject()V

    .line 177
    .line 178
    .line 179
    if-ne v2, v6, :cond_7

    .line 180
    .line 181
    if-nez v20, :cond_6

    .line 182
    .line 183
    goto :goto_4

    .line 184
    :cond_6
    new-instance v15, Lo/kapnpued;

    .line 185
    .line 186
    invoke-direct/range {v15 .. v21}, Lo/kapnpued;-><init>(JJLjava/lang/String;Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    move-object v12, v15

    .line 190
    goto :goto_5

    .line 191
    :cond_7
    :goto_4
    new-instance v4, Ljava/lang/StringBuilder;

    .line 192
    .line 193
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 194
    .line 195
    .line 196
    and-int/lit8 v5, v2, 0x1

    .line 197
    .line 198
    if-nez v5, :cond_8

    .line 199
    .line 200
    const-string v5, " baseAddress"

    .line 201
    .line 202
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 203
    .line 204
    .line 205
    :cond_8
    and-int/lit8 v2, v2, 0x2

    .line 206
    .line 207
    if-nez v2, :cond_9

    .line 208
    .line 209
    const-string v2, " size"

    .line 210
    .line 211
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 212
    .line 213
    .line 214
    :cond_9
    if-nez v20, :cond_a

    .line 215
    .line 216
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 217
    .line 218
    .line 219
    :cond_a
    invoke-static {v8, v4}, Lo/nrkepnpirid;->ndpnikda(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 220
    .line 221
    .line 222
    move-result-object v2

    .line 223
    invoke-static {v2}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 224
    .line 225
    .line 226
    :goto_5
    move-object/from16 v15, p0

    .line 227
    .line 228
    :goto_6
    move-object v2, v12

    .line 229
    goto/16 :goto_17

    .line 230
    .line 231
    :pswitch_5
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->beginObject()V

    .line 232
    .line 233
    .line 234
    move v2, v9

    .line 235
    move v14, v2

    .line 236
    move-object v6, v12

    .line 237
    move-object v13, v6

    .line 238
    :goto_7
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 239
    .line 240
    .line 241
    move-result v15

    .line 242
    if-eqz v15, :cond_10

    .line 243
    .line 244
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v15

    .line 248
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 249
    .line 250
    .line 251
    invoke-virtual {v15}, Ljava/lang/String;->hashCode()I

    .line 252
    .line 253
    .line 254
    move-result v16

    .line 255
    sparse-switch v16, :sswitch_data_1

    .line 256
    .line 257
    .line 258
    :goto_8
    const/4 v7, -0x1

    .line 259
    goto :goto_9

    .line 260
    :sswitch_4
    const-string v7, "importance"

    .line 261
    .line 262
    invoke-virtual {v15, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 263
    .line 264
    .line 265
    move-result v7

    .line 266
    if-nez v7, :cond_b

    .line 267
    .line 268
    goto :goto_8

    .line 269
    :cond_b
    move v7, v10

    .line 270
    goto :goto_9

    .line 271
    :sswitch_5
    invoke-virtual {v15, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    move-result v7

    .line 275
    if-nez v7, :cond_c

    .line 276
    .line 277
    goto :goto_8

    .line 278
    :cond_c
    move v7, v11

    .line 279
    goto :goto_9

    .line 280
    :sswitch_6
    const-string v7, "frames"

    .line 281
    .line 282
    invoke-virtual {v15, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 283
    .line 284
    .line 285
    move-result v7

    .line 286
    if-nez v7, :cond_d

    .line 287
    .line 288
    goto :goto_8

    .line 289
    :cond_d
    move v7, v9

    .line 290
    :goto_9
    packed-switch v7, :pswitch_data_2

    .line 291
    .line 292
    .line 293
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->skipValue()V

    .line 294
    .line 295
    .line 296
    :goto_a
    move-object/from16 v15, p0

    .line 297
    .line 298
    goto :goto_7

    .line 299
    :pswitch_6
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextInt()I

    .line 300
    .line 301
    .line 302
    move-result v14

    .line 303
    or-int/lit8 v2, v2, 0x1

    .line 304
    .line 305
    int-to-byte v2, v2

    .line 306
    goto :goto_a

    .line 307
    :pswitch_7
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 308
    .line 309
    .line 310
    move-result-object v6

    .line 311
    if-eqz v6, :cond_e

    .line 312
    .line 313
    goto :goto_a

    .line 314
    :cond_e
    invoke-static {v4}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 315
    .line 316
    .line 317
    goto :goto_5

    .line 318
    :pswitch_8
    new-instance v7, Lo/kniuuerekaup;

    .line 319
    .line 320
    const/16 v13, 0x11

    .line 321
    .line 322
    invoke-direct {v7, v13}, Lo/kniuuerekaup;-><init>(I)V

    .line 323
    .line 324
    .line 325
    move-object/from16 v15, p0

    .line 326
    .line 327
    invoke-static {v15, v7}, Lo/aekpnkrpripi;->irkari(Landroid/util/JsonReader;Lo/kniuuerekaup;)Ljava/util/List;

    .line 328
    .line 329
    .line 330
    move-result-object v13

    .line 331
    if-eqz v13, :cond_f

    .line 332
    .line 333
    goto :goto_7

    .line 334
    :cond_f
    const-string v2, "Null frames"

    .line 335
    .line 336
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 337
    .line 338
    .line 339
    goto :goto_6

    .line 340
    :cond_10
    move-object/from16 v15, p0

    .line 341
    .line 342
    invoke-virtual {v15}, Landroid/util/JsonReader;->endObject()V

    .line 343
    .line 344
    .line 345
    if-ne v2, v11, :cond_12

    .line 346
    .line 347
    if-eqz v6, :cond_12

    .line 348
    .line 349
    if-nez v13, :cond_11

    .line 350
    .line 351
    goto :goto_b

    .line 352
    :cond_11
    new-instance v12, Lo/iaurerii;

    .line 353
    .line 354
    invoke-direct {v12, v14, v6, v13}, Lo/iaurerii;-><init>(ILjava/lang/String;Ljava/util/List;)V

    .line 355
    .line 356
    .line 357
    goto/16 :goto_6

    .line 358
    .line 359
    :cond_12
    :goto_b
    new-instance v4, Ljava/lang/StringBuilder;

    .line 360
    .line 361
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 362
    .line 363
    .line 364
    if-nez v6, :cond_13

    .line 365
    .line 366
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 367
    .line 368
    .line 369
    :cond_13
    and-int/lit8 v2, v2, 0x1

    .line 370
    .line 371
    if-nez v2, :cond_14

    .line 372
    .line 373
    const-string v2, " importance"

    .line 374
    .line 375
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 376
    .line 377
    .line 378
    :cond_14
    if-nez v13, :cond_15

    .line 379
    .line 380
    const-string v2, " frames"

    .line 381
    .line 382
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 383
    .line 384
    .line 385
    :cond_15
    invoke-static {v8, v4}, Lo/nrkepnpirid;->ndpnikda(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 386
    .line 387
    .line 388
    move-result-object v2

    .line 389
    invoke-static {v2}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 390
    .line 391
    .line 392
    goto/16 :goto_6

    .line 393
    .line 394
    :pswitch_9
    move-object/from16 v15, p0

    .line 395
    .line 396
    new-instance v2, Lo/raiiniupuik;

    .line 397
    .line 398
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 399
    .line 400
    .line 401
    invoke-virtual {v15}, Landroid/util/JsonReader;->beginObject()V

    .line 402
    .line 403
    .line 404
    :goto_c
    invoke-virtual {v15}, Landroid/util/JsonReader;->hasNext()Z

    .line 405
    .line 406
    .line 407
    move-result v3

    .line 408
    if-eqz v3, :cond_25

    .line 409
    .line 410
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 411
    .line 412
    .line 413
    move-result-object v3

    .line 414
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 415
    .line 416
    .line 417
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 418
    .line 419
    .line 420
    move-result v4

    .line 421
    sparse-switch v4, :sswitch_data_2

    .line 422
    .line 423
    .line 424
    :goto_d
    const/4 v3, -0x1

    .line 425
    goto :goto_e

    .line 426
    :sswitch_7
    const-string v4, "parameterValue"

    .line 427
    .line 428
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 429
    .line 430
    .line 431
    move-result v3

    .line 432
    if-nez v3, :cond_16

    .line 433
    .line 434
    goto :goto_d

    .line 435
    :cond_16
    move v3, v6

    .line 436
    goto :goto_e

    .line 437
    :sswitch_8
    const-string v4, "rolloutVariant"

    .line 438
    .line 439
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 440
    .line 441
    .line 442
    move-result v3

    .line 443
    if-nez v3, :cond_17

    .line 444
    .line 445
    goto :goto_d

    .line 446
    :cond_17
    move v3, v10

    .line 447
    goto :goto_e

    .line 448
    :sswitch_9
    const-string v4, "templateVersion"

    .line 449
    .line 450
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 451
    .line 452
    .line 453
    move-result v3

    .line 454
    if-nez v3, :cond_18

    .line 455
    .line 456
    goto :goto_d

    .line 457
    :cond_18
    move v3, v11

    .line 458
    goto :goto_e

    .line 459
    :sswitch_a
    const-string v4, "parameterKey"

    .line 460
    .line 461
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 462
    .line 463
    .line 464
    move-result v3

    .line 465
    if-nez v3, :cond_19

    .line 466
    .line 467
    goto :goto_d

    .line 468
    :cond_19
    move v3, v9

    .line 469
    :goto_e
    packed-switch v3, :pswitch_data_3

    .line 470
    .line 471
    .line 472
    invoke-virtual {v15}, Landroid/util/JsonReader;->skipValue()V

    .line 473
    .line 474
    .line 475
    goto :goto_c

    .line 476
    :pswitch_a
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 477
    .line 478
    .line 479
    move-result-object v3

    .line 480
    if-eqz v3, :cond_1a

    .line 481
    .line 482
    iput-object v3, v2, Lo/raiiniupuik;->pepeunri:Ljava/lang/String;

    .line 483
    .line 484
    goto :goto_c

    .line 485
    :cond_1a
    const-string v2, "Null parameterValue"

    .line 486
    .line 487
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 488
    .line 489
    .line 490
    goto/16 :goto_6

    .line 491
    .line 492
    :pswitch_b
    invoke-virtual {v15}, Landroid/util/JsonReader;->beginObject()V

    .line 493
    .line 494
    .line 495
    move-object v3, v12

    .line 496
    move-object v4, v3

    .line 497
    :goto_f
    invoke-virtual {v15}, Landroid/util/JsonReader;->hasNext()Z

    .line 498
    .line 499
    .line 500
    move-result v5

    .line 501
    if-eqz v5, :cond_1f

    .line 502
    .line 503
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 504
    .line 505
    .line 506
    move-result-object v5

    .line 507
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 508
    .line 509
    .line 510
    const-string v7, "variantId"

    .line 511
    .line 512
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 513
    .line 514
    .line 515
    move-result v7

    .line 516
    if-nez v7, :cond_1d

    .line 517
    .line 518
    const-string v7, "rolloutId"

    .line 519
    .line 520
    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 521
    .line 522
    .line 523
    move-result v5

    .line 524
    if-nez v5, :cond_1b

    .line 525
    .line 526
    invoke-virtual {v15}, Landroid/util/JsonReader;->skipValue()V

    .line 527
    .line 528
    .line 529
    goto :goto_f

    .line 530
    :cond_1b
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 531
    .line 532
    .line 533
    move-result-object v3

    .line 534
    if-eqz v3, :cond_1c

    .line 535
    .line 536
    goto :goto_f

    .line 537
    :cond_1c
    const-string v2, "Null rolloutId"

    .line 538
    .line 539
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 540
    .line 541
    .line 542
    goto/16 :goto_6

    .line 543
    .line 544
    :cond_1d
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 545
    .line 546
    .line 547
    move-result-object v4

    .line 548
    if-eqz v4, :cond_1e

    .line 549
    .line 550
    goto :goto_f

    .line 551
    :cond_1e
    const-string v2, "Null variantId"

    .line 552
    .line 553
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 554
    .line 555
    .line 556
    goto/16 :goto_6

    .line 557
    .line 558
    :cond_1f
    invoke-virtual {v15}, Landroid/util/JsonReader;->endObject()V

    .line 559
    .line 560
    .line 561
    if-eqz v3, :cond_21

    .line 562
    .line 563
    if-nez v4, :cond_20

    .line 564
    .line 565
    goto :goto_10

    .line 566
    :cond_20
    new-instance v5, Lo/aipkrdara;

    .line 567
    .line 568
    invoke-direct {v5, v3, v4}, Lo/aipkrdara;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 569
    .line 570
    .line 571
    iput-object v5, v2, Lo/raiiniupuik;->dpunpe:Lo/aipkrdara;

    .line 572
    .line 573
    goto/16 :goto_c

    .line 574
    .line 575
    :cond_21
    :goto_10
    new-instance v2, Ljava/lang/StringBuilder;

    .line 576
    .line 577
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 578
    .line 579
    .line 580
    if-nez v3, :cond_22

    .line 581
    .line 582
    const-string v3, " rolloutId"

    .line 583
    .line 584
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 585
    .line 586
    .line 587
    :cond_22
    if-nez v4, :cond_23

    .line 588
    .line 589
    const-string v3, " variantId"

    .line 590
    .line 591
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 592
    .line 593
    .line 594
    :cond_23
    invoke-static {v8, v2}, Lo/nrkepnpirid;->ndpnikda(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 595
    .line 596
    .line 597
    move-result-object v2

    .line 598
    invoke-static {v2}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 599
    .line 600
    .line 601
    goto/16 :goto_6

    .line 602
    .line 603
    :pswitch_c
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextLong()J

    .line 604
    .line 605
    .line 606
    move-result-wide v3

    .line 607
    iput-wide v3, v2, Lo/raiiniupuik;->irkari:J

    .line 608
    .line 609
    iget-byte v3, v2, Lo/raiiniupuik;->iiunkaippn:B

    .line 610
    .line 611
    or-int/2addr v3, v11

    .line 612
    int-to-byte v3, v3

    .line 613
    iput-byte v3, v2, Lo/raiiniupuik;->iiunkaippn:B

    .line 614
    .line 615
    goto/16 :goto_c

    .line 616
    .line 617
    :pswitch_d
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 618
    .line 619
    .line 620
    move-result-object v3

    .line 621
    if-eqz v3, :cond_24

    .line 622
    .line 623
    iput-object v3, v2, Lo/raiiniupuik;->dpeakapiakpa:Ljava/lang/String;

    .line 624
    .line 625
    goto/16 :goto_c

    .line 626
    .line 627
    :cond_24
    const-string v2, "Null parameterKey"

    .line 628
    .line 629
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 630
    .line 631
    .line 632
    goto/16 :goto_6

    .line 633
    .line 634
    :cond_25
    invoke-virtual {v15}, Landroid/util/JsonReader;->endObject()V

    .line 635
    .line 636
    .line 637
    invoke-virtual {v2}, Lo/raiiniupuik;->dpunpe()Lo/erdnreiknru;

    .line 638
    .line 639
    .line 640
    move-result-object v12

    .line 641
    goto/16 :goto_6

    .line 642
    .line 643
    :pswitch_e
    move-object/from16 v15, p0

    .line 644
    .line 645
    invoke-virtual {v15}, Landroid/util/JsonReader;->beginObject()V

    .line 646
    .line 647
    .line 648
    move-object v2, v12

    .line 649
    move-object v3, v2

    .line 650
    :goto_11
    invoke-virtual {v15}, Landroid/util/JsonReader;->hasNext()Z

    .line 651
    .line 652
    .line 653
    move-result v4

    .line 654
    if-eqz v4, :cond_2a

    .line 655
    .line 656
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 657
    .line 658
    .line 659
    move-result-object v4

    .line 660
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 661
    .line 662
    .line 663
    const-string v5, "filename"

    .line 664
    .line 665
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 666
    .line 667
    .line 668
    move-result v5

    .line 669
    if-nez v5, :cond_28

    .line 670
    .line 671
    const-string v5, "contents"

    .line 672
    .line 673
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 674
    .line 675
    .line 676
    move-result v4

    .line 677
    if-nez v4, :cond_26

    .line 678
    .line 679
    invoke-virtual {v15}, Landroid/util/JsonReader;->skipValue()V

    .line 680
    .line 681
    .line 682
    goto :goto_11

    .line 683
    :cond_26
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 684
    .line 685
    .line 686
    move-result-object v3

    .line 687
    invoke-static {v3, v10}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 688
    .line 689
    .line 690
    move-result-object v3

    .line 691
    if-eqz v3, :cond_27

    .line 692
    .line 693
    goto :goto_11

    .line 694
    :cond_27
    const-string v2, "Null contents"

    .line 695
    .line 696
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 697
    .line 698
    .line 699
    goto/16 :goto_6

    .line 700
    .line 701
    :cond_28
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 702
    .line 703
    .line 704
    move-result-object v2

    .line 705
    if-eqz v2, :cond_29

    .line 706
    .line 707
    goto :goto_11

    .line 708
    :cond_29
    const-string v2, "Null filename"

    .line 709
    .line 710
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 711
    .line 712
    .line 713
    goto/16 :goto_6

    .line 714
    .line 715
    :cond_2a
    invoke-virtual {v15}, Landroid/util/JsonReader;->endObject()V

    .line 716
    .line 717
    .line 718
    if-eqz v2, :cond_2c

    .line 719
    .line 720
    if-nez v3, :cond_2b

    .line 721
    .line 722
    goto :goto_12

    .line 723
    :cond_2b
    new-instance v12, Lo/inkdduirr;

    .line 724
    .line 725
    invoke-direct {v12, v2, v3}, Lo/inkdduirr;-><init>(Ljava/lang/String;[B)V

    .line 726
    .line 727
    .line 728
    goto/16 :goto_6

    .line 729
    .line 730
    :cond_2c
    :goto_12
    new-instance v4, Ljava/lang/StringBuilder;

    .line 731
    .line 732
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 733
    .line 734
    .line 735
    if-nez v2, :cond_2d

    .line 736
    .line 737
    const-string v2, " filename"

    .line 738
    .line 739
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 740
    .line 741
    .line 742
    :cond_2d
    if-nez v3, :cond_2e

    .line 743
    .line 744
    const-string v2, " contents"

    .line 745
    .line 746
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 747
    .line 748
    .line 749
    :cond_2e
    invoke-static {v8, v4}, Lo/nrkepnpirid;->ndpnikda(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 750
    .line 751
    .line 752
    move-result-object v2

    .line 753
    invoke-static {v2}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 754
    .line 755
    .line 756
    goto/16 :goto_6

    .line 757
    .line 758
    :pswitch_f
    move-object/from16 v15, p0

    .line 759
    .line 760
    invoke-virtual {v15}, Landroid/util/JsonReader;->beginObject()V

    .line 761
    .line 762
    .line 763
    move-object v2, v12

    .line 764
    move-object v3, v2

    .line 765
    move-object v4, v3

    .line 766
    :goto_13
    invoke-virtual {v15}, Landroid/util/JsonReader;->hasNext()Z

    .line 767
    .line 768
    .line 769
    move-result v5

    .line 770
    if-eqz v5, :cond_35

    .line 771
    .line 772
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 773
    .line 774
    .line 775
    move-result-object v5

    .line 776
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 777
    .line 778
    .line 779
    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    .line 780
    .line 781
    .line 782
    move-result v6

    .line 783
    sparse-switch v6, :sswitch_data_3

    .line 784
    .line 785
    .line 786
    :goto_14
    const/4 v5, -0x1

    .line 787
    goto :goto_15

    .line 788
    :sswitch_b
    const-string v6, "buildId"

    .line 789
    .line 790
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 791
    .line 792
    .line 793
    move-result v5

    .line 794
    if-nez v5, :cond_2f

    .line 795
    .line 796
    goto :goto_14

    .line 797
    :cond_2f
    move v5, v10

    .line 798
    goto :goto_15

    .line 799
    :sswitch_c
    const-string v6, "arch"

    .line 800
    .line 801
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 802
    .line 803
    .line 804
    move-result v5

    .line 805
    if-nez v5, :cond_30

    .line 806
    .line 807
    goto :goto_14

    .line 808
    :cond_30
    move v5, v11

    .line 809
    goto :goto_15

    .line 810
    :sswitch_d
    const-string v6, "libraryName"

    .line 811
    .line 812
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 813
    .line 814
    .line 815
    move-result v5

    .line 816
    if-nez v5, :cond_31

    .line 817
    .line 818
    goto :goto_14

    .line 819
    :cond_31
    move v5, v9

    .line 820
    :goto_15
    packed-switch v5, :pswitch_data_4

    .line 821
    .line 822
    .line 823
    invoke-virtual {v15}, Landroid/util/JsonReader;->skipValue()V

    .line 824
    .line 825
    .line 826
    goto :goto_13

    .line 827
    :pswitch_10
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 828
    .line 829
    .line 830
    move-result-object v4

    .line 831
    if-eqz v4, :cond_32

    .line 832
    .line 833
    goto :goto_13

    .line 834
    :cond_32
    const-string v2, "Null buildId"

    .line 835
    .line 836
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 837
    .line 838
    .line 839
    goto/16 :goto_6

    .line 840
    .line 841
    :pswitch_11
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 842
    .line 843
    .line 844
    move-result-object v2

    .line 845
    if-eqz v2, :cond_33

    .line 846
    .line 847
    goto :goto_13

    .line 848
    :cond_33
    const-string v2, "Null arch"

    .line 849
    .line 850
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 851
    .line 852
    .line 853
    goto/16 :goto_6

    .line 854
    .line 855
    :pswitch_12
    invoke-virtual {v15}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 856
    .line 857
    .line 858
    move-result-object v3

    .line 859
    if-eqz v3, :cond_34

    .line 860
    .line 861
    goto :goto_13

    .line 862
    :cond_34
    const-string v2, "Null libraryName"

    .line 863
    .line 864
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 865
    .line 866
    .line 867
    goto/16 :goto_6

    .line 868
    .line 869
    :cond_35
    invoke-virtual {v15}, Landroid/util/JsonReader;->endObject()V

    .line 870
    .line 871
    .line 872
    if-eqz v2, :cond_37

    .line 873
    .line 874
    if-eqz v3, :cond_37

    .line 875
    .line 876
    if-nez v4, :cond_36

    .line 877
    .line 878
    goto :goto_16

    .line 879
    :cond_36
    new-instance v12, Lo/ikniirdr;

    .line 880
    .line 881
    invoke-direct {v12, v2, v3, v4}, Lo/ikniirdr;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 882
    .line 883
    .line 884
    goto/16 :goto_6

    .line 885
    .line 886
    :cond_37
    :goto_16
    new-instance v5, Ljava/lang/StringBuilder;

    .line 887
    .line 888
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 889
    .line 890
    .line 891
    if-nez v2, :cond_38

    .line 892
    .line 893
    const-string v2, " arch"

    .line 894
    .line 895
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 896
    .line 897
    .line 898
    :cond_38
    if-nez v3, :cond_39

    .line 899
    .line 900
    const-string v2, " libraryName"

    .line 901
    .line 902
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 903
    .line 904
    .line 905
    :cond_39
    if-nez v4, :cond_3a

    .line 906
    .line 907
    const-string v2, " buildId"

    .line 908
    .line 909
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 910
    .line 911
    .line 912
    :cond_3a
    invoke-static {v8, v5}, Lo/nrkepnpirid;->ndpnikda(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 913
    .line 914
    .line 915
    move-result-object v2

    .line 916
    invoke-static {v2}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 917
    .line 918
    .line 919
    goto/16 :goto_6

    .line 920
    .line 921
    :goto_17
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 922
    .line 923
    .line 924
    goto/16 :goto_0

    .line 925
    .line 926
    :cond_3b
    move-object/from16 v15, p0

    .line 927
    .line 928
    invoke-virtual {v15}, Landroid/util/JsonReader;->endArray()V

    .line 929
    .line 930
    .line 931
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 932
    .line 933
    .line 934
    move-result-object v0

    .line 935
    return-object v0

    .line 936
    nop

    .line 937
    :pswitch_data_0
    .packed-switch 0xc
        :pswitch_f
        :pswitch_e
        :pswitch_9
        :pswitch_5
        :pswitch_0
    .end packed-switch

    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    :sswitch_data_0
    .sparse-switch
        0x337a8b -> :sswitch_3
        0x35e001 -> :sswitch_2
        0x36f3bb -> :sswitch_1
        0x44c50fe3 -> :sswitch_0
    .end sparse-switch

    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch

    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    :sswitch_data_1
    .sparse-switch
        -0x4b7d7b5a -> :sswitch_6
        0x337a8b -> :sswitch_5
        0x7eb2da74 -> :sswitch_4
    .end sparse-switch

    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
    .end packed-switch

    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    :sswitch_data_2
    .sparse-switch
        -0x5b919a0a -> :sswitch_a
        -0x3d3b3502 -> :sswitch_9
        0x417d8d94 -> :sswitch_8
        0x4305cf48 -> :sswitch_7
    .end sparse-switch

    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    :pswitch_data_3
    .packed-switch 0x0
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
    .end packed-switch

    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    :sswitch_data_3
    .sparse-switch
        -0x2459c21a -> :sswitch_d
        0x2dd056 -> :sswitch_c
        0xdc3ec29 -> :sswitch_b
    .end sparse-switch

    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    :pswitch_data_4
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
    .end packed-switch
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
.end method

.method public static kikaa(Ljava/lang/String;)Lo/ipipkpua;
    .locals 2

    .line 1
    :try_start_0
    new-instance v0, Landroid/util/JsonReader;

    .line 2
    .line 3
    new-instance v1, Ljava/io/StringReader;

    .line 4
    .line 5
    invoke-direct {v1, p0}, Ljava/io/StringReader;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-direct {v0, v1}, Landroid/util/JsonReader;-><init>(Ljava/io/Reader;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 9
    .line 10
    .line 11
    :try_start_1
    invoke-static {v0}, Lo/aekpnkrpripi;->nkpkuui(Landroid/util/JsonReader;)Lo/ipipkpua;

    .line 12
    .line 13
    .line 14
    move-result-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 15
    :try_start_2
    invoke-virtual {v0}, Landroid/util/JsonReader;->close()V
    :try_end_2
    .catch Ljava/lang/IllegalStateException; {:try_start_2 .. :try_end_2} :catch_0

    .line 16
    .line 17
    .line 18
    return-object p0

    .line 19
    :catchall_0
    move-exception p0

    .line 20
    :try_start_3
    invoke-virtual {v0}, Landroid/util/JsonReader;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 21
    .line 22
    .line 23
    goto :goto_0

    .line 24
    :catchall_1
    move-exception v0

    .line 25
    :try_start_4
    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 26
    .line 27
    .line 28
    :goto_0
    throw p0
    :try_end_4
    .catch Ljava/lang/IllegalStateException; {:try_start_4 .. :try_end_4} :catch_0

    .line 29
    :catch_0
    move-exception p0

    .line 30
    new-instance v0, Ljava/io/IOException;

    .line 31
    .line 32
    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 33
    .line 34
    .line 35
    throw v0
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
.end method

.method public static nkpkuui(Landroid/util/JsonReader;)Lo/ipipkpua;
    .locals 30

    .line 1
    sget-object v0, Lo/rnea;->dpunpe:Ljava/nio/charset/Charset;

    .line 2
    .line 3
    new-instance v0, Lo/rpnnpaauuan;

    .line 4
    .line 5
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->beginObject()V

    .line 9
    .line 10
    .line 11
    :goto_0
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_4a

    .line 16
    .line 17
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    const-string v5, "displayVersion"

    .line 29
    .line 30
    const-string v7, "platform"

    .line 31
    .line 32
    const-string v8, "installationUuid"

    .line 33
    .line 34
    const-string v9, "buildVersion"

    .line 35
    .line 36
    const-string v10, "appQualitySessionId"

    .line 37
    .line 38
    const/4 v14, 0x5

    .line 39
    const/4 v15, 0x3

    .line 40
    const/16 v16, -0x1

    .line 41
    .line 42
    const/4 v3, 0x0

    .line 43
    const/16 v17, 0x4

    .line 44
    .line 45
    const/16 v18, 0x1

    .line 46
    .line 47
    const/4 v4, 0x2

    .line 48
    sparse-switch v2, :sswitch_data_0

    .line 49
    .line 50
    .line 51
    :goto_1
    move/from16 v1, v16

    .line 52
    .line 53
    goto/16 :goto_2

    .line 54
    .line 55
    :sswitch_0
    const-string v2, "session"

    .line 56
    .line 57
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-nez v1, :cond_0

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_0
    const/16 v1, 0xb

    .line 65
    .line 66
    goto/16 :goto_2

    .line 67
    .line 68
    :sswitch_1
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    if-nez v1, :cond_1

    .line 73
    .line 74
    goto :goto_1

    .line 75
    :cond_1
    const/16 v1, 0xa

    .line 76
    .line 77
    goto/16 :goto_2

    .line 78
    .line 79
    :sswitch_2
    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v1

    .line 83
    if-nez v1, :cond_2

    .line 84
    .line 85
    goto :goto_1

    .line 86
    :cond_2
    const/16 v1, 0x9

    .line 87
    .line 88
    goto/16 :goto_2

    .line 89
    .line 90
    :sswitch_3
    const-string v2, "firebaseInstallationId"

    .line 91
    .line 92
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v1

    .line 96
    if-nez v1, :cond_3

    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_3
    const/16 v1, 0x8

    .line 100
    .line 101
    goto/16 :goto_2

    .line 102
    .line 103
    :sswitch_4
    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    move-result v1

    .line 107
    if-nez v1, :cond_4

    .line 108
    .line 109
    goto :goto_1

    .line 110
    :cond_4
    const/4 v1, 0x7

    .line 111
    goto :goto_2

    .line 112
    :sswitch_5
    const-string v2, "gmpAppId"

    .line 113
    .line 114
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result v1

    .line 118
    if-nez v1, :cond_5

    .line 119
    .line 120
    goto :goto_1

    .line 121
    :cond_5
    const/4 v1, 0x6

    .line 122
    goto :goto_2

    .line 123
    :sswitch_6
    const-string v2, "firebaseAuthenticationToken"

    .line 124
    .line 125
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    move-result v1

    .line 129
    if-nez v1, :cond_6

    .line 130
    .line 131
    goto :goto_1

    .line 132
    :cond_6
    move v1, v14

    .line 133
    goto :goto_2

    .line 134
    :sswitch_7
    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v1

    .line 138
    if-nez v1, :cond_7

    .line 139
    .line 140
    goto :goto_1

    .line 141
    :cond_7
    move/from16 v1, v17

    .line 142
    .line 143
    goto :goto_2

    .line 144
    :sswitch_8
    const-string v2, "appExitInfo"

    .line 145
    .line 146
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 147
    .line 148
    .line 149
    move-result v1

    .line 150
    if-nez v1, :cond_8

    .line 151
    .line 152
    goto :goto_1

    .line 153
    :cond_8
    move v1, v15

    .line 154
    goto :goto_2

    .line 155
    :sswitch_9
    invoke-virtual {v1, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 156
    .line 157
    .line 158
    move-result v1

    .line 159
    if-nez v1, :cond_9

    .line 160
    .line 161
    goto :goto_1

    .line 162
    :cond_9
    move v1, v4

    .line 163
    goto :goto_2

    .line 164
    :sswitch_a
    const-string v2, "sdkVersion"

    .line 165
    .line 166
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 167
    .line 168
    .line 169
    move-result v1

    .line 170
    if-nez v1, :cond_a

    .line 171
    .line 172
    goto :goto_1

    .line 173
    :cond_a
    move/from16 v1, v18

    .line 174
    .line 175
    goto :goto_2

    .line 176
    :sswitch_b
    const-string v2, "ndkPayload"

    .line 177
    .line 178
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 179
    .line 180
    .line 181
    move-result v1

    .line 182
    if-nez v1, :cond_b

    .line 183
    .line 184
    goto/16 :goto_1

    .line 185
    .line 186
    :cond_b
    move v1, v3

    .line 187
    :goto_2
    const-string v2, "Null buildVersion"

    .line 188
    .line 189
    const/16 v19, 0x0

    .line 190
    .line 191
    packed-switch v1, :pswitch_data_0

    .line 192
    .line 193
    .line 194
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->skipValue()V

    .line 195
    .line 196
    .line 197
    :goto_3
    move-object/from16 v3, p0

    .line 198
    .line 199
    goto/16 :goto_0

    .line 200
    .line 201
    :pswitch_0
    new-instance v1, Lo/ueapnernia;

    .line 202
    .line 203
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 204
    .line 205
    .line 206
    iput-boolean v3, v1, Lo/ueapnernia;->aiupunrka:Z

    .line 207
    .line 208
    iget-byte v3, v1, Lo/ueapnernia;->uninpker:B

    .line 209
    .line 210
    or-int/2addr v3, v4

    .line 211
    int-to-byte v3, v3

    .line 212
    iput-byte v3, v1, Lo/ueapnernia;->uninpker:B

    .line 213
    .line 214
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->beginObject()V

    .line 215
    .line 216
    .line 217
    :goto_4
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 218
    .line 219
    .line 220
    move-result v3

    .line 221
    if-eqz v3, :cond_3f

    .line 222
    .line 223
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 224
    .line 225
    .line 226
    move-result-object v3

    .line 227
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 228
    .line 229
    .line 230
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 231
    .line 232
    .line 233
    move-result v20

    .line 234
    const-string v6, "identifier"

    .line 235
    .line 236
    sparse-switch v20, :sswitch_data_1

    .line 237
    .line 238
    .line 239
    :goto_5
    move/from16 v3, v16

    .line 240
    .line 241
    goto/16 :goto_6

    .line 242
    .line 243
    :sswitch_c
    const-string v11, "generatorType"

    .line 244
    .line 245
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 246
    .line 247
    .line 248
    move-result v3

    .line 249
    if-nez v3, :cond_c

    .line 250
    .line 251
    goto :goto_5

    .line 252
    :cond_c
    const/16 v3, 0xb

    .line 253
    .line 254
    goto/16 :goto_6

    .line 255
    .line 256
    :sswitch_d
    const-string v11, "crashed"

    .line 257
    .line 258
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    move-result v3

    .line 262
    if-nez v3, :cond_d

    .line 263
    .line 264
    goto :goto_5

    .line 265
    :cond_d
    const/16 v3, 0xa

    .line 266
    .line 267
    goto/16 :goto_6

    .line 268
    .line 269
    :sswitch_e
    const-string v11, "generator"

    .line 270
    .line 271
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    move-result v3

    .line 275
    if-nez v3, :cond_e

    .line 276
    .line 277
    goto :goto_5

    .line 278
    :cond_e
    const/16 v3, 0x9

    .line 279
    .line 280
    goto/16 :goto_6

    .line 281
    .line 282
    :sswitch_f
    const-string v11, "user"

    .line 283
    .line 284
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 285
    .line 286
    .line 287
    move-result v3

    .line 288
    if-nez v3, :cond_f

    .line 289
    .line 290
    goto :goto_5

    .line 291
    :cond_f
    const/16 v3, 0x8

    .line 292
    .line 293
    goto/16 :goto_6

    .line 294
    .line 295
    :sswitch_10
    const-string v11, "app"

    .line 296
    .line 297
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 298
    .line 299
    .line 300
    move-result v3

    .line 301
    if-nez v3, :cond_10

    .line 302
    .line 303
    goto :goto_5

    .line 304
    :cond_10
    const/4 v3, 0x7

    .line 305
    goto :goto_6

    .line 306
    :sswitch_11
    const-string v11, "os"

    .line 307
    .line 308
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 309
    .line 310
    .line 311
    move-result v3

    .line 312
    if-nez v3, :cond_11

    .line 313
    .line 314
    goto :goto_5

    .line 315
    :cond_11
    const/4 v3, 0x6

    .line 316
    goto :goto_6

    .line 317
    :sswitch_12
    const-string v11, "events"

    .line 318
    .line 319
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 320
    .line 321
    .line 322
    move-result v3

    .line 323
    if-nez v3, :cond_12

    .line 324
    .line 325
    goto :goto_5

    .line 326
    :cond_12
    move v3, v14

    .line 327
    goto :goto_6

    .line 328
    :sswitch_13
    const-string v11, "device"

    .line 329
    .line 330
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 331
    .line 332
    .line 333
    move-result v3

    .line 334
    if-nez v3, :cond_13

    .line 335
    .line 336
    goto :goto_5

    .line 337
    :cond_13
    move/from16 v3, v17

    .line 338
    .line 339
    goto :goto_6

    .line 340
    :sswitch_14
    const-string v11, "endedAt"

    .line 341
    .line 342
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 343
    .line 344
    .line 345
    move-result v3

    .line 346
    if-nez v3, :cond_14

    .line 347
    .line 348
    goto :goto_5

    .line 349
    :cond_14
    move v3, v15

    .line 350
    goto :goto_6

    .line 351
    :sswitch_15
    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 352
    .line 353
    .line 354
    move-result v3

    .line 355
    if-nez v3, :cond_15

    .line 356
    .line 357
    goto :goto_5

    .line 358
    :cond_15
    move v3, v4

    .line 359
    goto :goto_6

    .line 360
    :sswitch_16
    invoke-virtual {v3, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 361
    .line 362
    .line 363
    move-result v3

    .line 364
    if-nez v3, :cond_16

    .line 365
    .line 366
    goto :goto_5

    .line 367
    :cond_16
    move/from16 v3, v18

    .line 368
    .line 369
    goto :goto_6

    .line 370
    :sswitch_17
    const-string v11, "startedAt"

    .line 371
    .line 372
    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 373
    .line 374
    .line 375
    move-result v3

    .line 376
    if-nez v3, :cond_17

    .line 377
    .line 378
    goto/16 :goto_5

    .line 379
    .line 380
    :cond_17
    const/4 v3, 0x0

    .line 381
    :goto_6
    const-string v11, "version"

    .line 382
    .line 383
    const-string v21, "Null version"

    .line 384
    .line 385
    const-string v22, "Null identifier"

    .line 386
    .line 387
    packed-switch v3, :pswitch_data_1

    .line 388
    .line 389
    .line 390
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->skipValue()V

    .line 391
    .line 392
    .line 393
    :goto_7
    const/16 v29, 0x8

    .line 394
    .line 395
    goto/16 :goto_4

    .line 396
    .line 397
    :pswitch_1
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextInt()I

    .line 398
    .line 399
    .line 400
    move-result v3

    .line 401
    iput v3, v1, Lo/ueapnernia;->ndpnikda:I

    .line 402
    .line 403
    iget-byte v3, v1, Lo/ueapnernia;->uninpker:B

    .line 404
    .line 405
    or-int/lit8 v3, v3, 0x4

    .line 406
    .line 407
    int-to-byte v3, v3

    .line 408
    iput-byte v3, v1, Lo/ueapnernia;->uninpker:B

    .line 409
    .line 410
    goto :goto_7

    .line 411
    :pswitch_2
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextBoolean()Z

    .line 412
    .line 413
    .line 414
    move-result v3

    .line 415
    iput-boolean v3, v1, Lo/ueapnernia;->aiupunrka:Z

    .line 416
    .line 417
    iget-byte v3, v1, Lo/ueapnernia;->uninpker:B

    .line 418
    .line 419
    or-int/2addr v3, v4

    .line 420
    int-to-byte v3, v3

    .line 421
    iput-byte v3, v1, Lo/ueapnernia;->uninpker:B

    .line 422
    .line 423
    goto :goto_7

    .line 424
    :pswitch_3
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 425
    .line 426
    .line 427
    move-result-object v3

    .line 428
    if-eqz v3, :cond_18

    .line 429
    .line 430
    iput-object v3, v1, Lo/ueapnernia;->dpunpe:Ljava/lang/String;

    .line 431
    .line 432
    goto :goto_7

    .line 433
    :cond_18
    const-string v0, "Null generator"

    .line 434
    .line 435
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 436
    .line 437
    .line 438
    return-object v19

    .line 439
    :pswitch_4
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->beginObject()V

    .line 440
    .line 441
    .line 442
    move-object/from16 v3, v19

    .line 443
    .line 444
    :goto_8
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 445
    .line 446
    .line 447
    move-result v11

    .line 448
    if-eqz v11, :cond_1b

    .line 449
    .line 450
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 451
    .line 452
    .line 453
    move-result-object v11

    .line 454
    invoke-virtual {v11, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 455
    .line 456
    .line 457
    move-result v11

    .line 458
    if-eqz v11, :cond_1a

    .line 459
    .line 460
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 461
    .line 462
    .line 463
    move-result-object v3

    .line 464
    if-eqz v3, :cond_19

    .line 465
    .line 466
    goto :goto_8

    .line 467
    :cond_19
    invoke-static/range {v22 .. v22}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 468
    .line 469
    .line 470
    return-object v19

    .line 471
    :cond_1a
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->skipValue()V

    .line 472
    .line 473
    .line 474
    goto :goto_8

    .line 475
    :cond_1b
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->endObject()V

    .line 476
    .line 477
    .line 478
    if-eqz v3, :cond_1c

    .line 479
    .line 480
    new-instance v6, Lo/eiinpuueae;

    .line 481
    .line 482
    invoke-direct {v6, v3}, Lo/eiinpuueae;-><init>(Ljava/lang/String;)V

    .line 483
    .line 484
    .line 485
    iput-object v6, v1, Lo/ueapnernia;->dedr:Lo/punrruekikd;

    .line 486
    .line 487
    goto :goto_7

    .line 488
    :cond_1c
    const-string v0, "Missing required properties: identifier"

    .line 489
    .line 490
    invoke-static {v0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 491
    .line 492
    .line 493
    return-object v19

    .line 494
    :pswitch_5
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->beginObject()V

    .line 495
    .line 496
    .line 497
    move-object/from16 v23, v19

    .line 498
    .line 499
    move-object/from16 v24, v23

    .line 500
    .line 501
    move-object/from16 v25, v24

    .line 502
    .line 503
    move-object/from16 v26, v25

    .line 504
    .line 505
    move-object/from16 v27, v26

    .line 506
    .line 507
    move-object/from16 v3, v22

    .line 508
    .line 509
    move-object/from16 v22, v27

    .line 510
    .line 511
    :goto_9
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 512
    .line 513
    .line 514
    move-result v28

    .line 515
    if-eqz v28, :cond_25

    .line 516
    .line 517
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 518
    .line 519
    .line 520
    move-result-object v12

    .line 521
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 522
    .line 523
    .line 524
    invoke-virtual {v12}, Ljava/lang/String;->hashCode()I

    .line 525
    .line 526
    .line 527
    move-result v29

    .line 528
    sparse-switch v29, :sswitch_data_2

    .line 529
    .line 530
    .line 531
    :goto_a
    move/from16 v12, v16

    .line 532
    .line 533
    :goto_b
    const/16 v29, 0x8

    .line 534
    .line 535
    goto :goto_d

    .line 536
    :sswitch_18
    invoke-virtual {v12, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 537
    .line 538
    .line 539
    move-result v12

    .line 540
    if-nez v12, :cond_1d

    .line 541
    .line 542
    goto :goto_a

    .line 543
    :cond_1d
    move v12, v14

    .line 544
    goto :goto_b

    .line 545
    :sswitch_19
    invoke-virtual {v12, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 546
    .line 547
    .line 548
    move-result v12

    .line 549
    if-nez v12, :cond_1e

    .line 550
    .line 551
    goto :goto_a

    .line 552
    :cond_1e
    move/from16 v12, v17

    .line 553
    .line 554
    goto :goto_b

    .line 555
    :sswitch_1a
    invoke-virtual {v12, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 556
    .line 557
    .line 558
    move-result v12

    .line 559
    if-nez v12, :cond_1f

    .line 560
    .line 561
    goto :goto_a

    .line 562
    :cond_1f
    move v12, v15

    .line 563
    goto :goto_b

    .line 564
    :sswitch_1b
    const/16 v29, 0x8

    .line 565
    .line 566
    const-string v13, "developmentPlatformVersion"

    .line 567
    .line 568
    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 569
    .line 570
    .line 571
    move-result v12

    .line 572
    if-nez v12, :cond_20

    .line 573
    .line 574
    goto :goto_c

    .line 575
    :cond_20
    move v12, v4

    .line 576
    goto :goto_d

    .line 577
    :sswitch_1c
    const/16 v29, 0x8

    .line 578
    .line 579
    const-string v13, "developmentPlatform"

    .line 580
    .line 581
    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 582
    .line 583
    .line 584
    move-result v12

    .line 585
    if-nez v12, :cond_21

    .line 586
    .line 587
    goto :goto_c

    .line 588
    :cond_21
    move/from16 v12, v18

    .line 589
    .line 590
    goto :goto_d

    .line 591
    :sswitch_1d
    const/16 v29, 0x8

    .line 592
    .line 593
    invoke-virtual {v12, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 594
    .line 595
    .line 596
    move-result v12

    .line 597
    if-nez v12, :cond_22

    .line 598
    .line 599
    :goto_c
    move/from16 v12, v16

    .line 600
    .line 601
    goto :goto_d

    .line 602
    :cond_22
    const/4 v12, 0x0

    .line 603
    :goto_d
    packed-switch v12, :pswitch_data_2

    .line 604
    .line 605
    .line 606
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->skipValue()V

    .line 607
    .line 608
    .line 609
    goto :goto_9

    .line 610
    :pswitch_6
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 611
    .line 612
    .line 613
    move-result-object v24

    .line 614
    goto :goto_9

    .line 615
    :pswitch_7
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 616
    .line 617
    .line 618
    move-result-object v25

    .line 619
    goto :goto_9

    .line 620
    :pswitch_8
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 621
    .line 622
    .line 623
    move-result-object v23

    .line 624
    if-eqz v23, :cond_23

    .line 625
    .line 626
    goto :goto_9

    .line 627
    :cond_23
    invoke-static/range {v21 .. v21}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 628
    .line 629
    .line 630
    return-object v19

    .line 631
    :pswitch_9
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 632
    .line 633
    .line 634
    move-result-object v27

    .line 635
    goto :goto_9

    .line 636
    :pswitch_a
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 637
    .line 638
    .line 639
    move-result-object v26

    .line 640
    goto/16 :goto_9

    .line 641
    .line 642
    :pswitch_b
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 643
    .line 644
    .line 645
    move-result-object v22

    .line 646
    if-eqz v22, :cond_24

    .line 647
    .line 648
    goto/16 :goto_9

    .line 649
    .line 650
    :cond_24
    invoke-static {v3}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 651
    .line 652
    .line 653
    return-object v19

    .line 654
    :cond_25
    const/16 v29, 0x8

    .line 655
    .line 656
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->endObject()V

    .line 657
    .line 658
    .line 659
    if-eqz v22, :cond_27

    .line 660
    .line 661
    if-nez v23, :cond_26

    .line 662
    .line 663
    goto :goto_e

    .line 664
    :cond_26
    new-instance v21, Lo/einkiirund;

    .line 665
    .line 666
    invoke-direct/range {v21 .. v27}, Lo/einkiirund;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 667
    .line 668
    .line 669
    move-object/from16 v3, v21

    .line 670
    .line 671
    iput-object v3, v1, Lo/ueapnernia;->adadnadrr:Lo/kudukanp;

    .line 672
    .line 673
    goto/16 :goto_4

    .line 674
    .line 675
    :cond_27
    :goto_e
    new-instance v0, Ljava/lang/StringBuilder;

    .line 676
    .line 677
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 678
    .line 679
    .line 680
    if-nez v22, :cond_28

    .line 681
    .line 682
    const-string v1, " identifier"

    .line 683
    .line 684
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 685
    .line 686
    .line 687
    :cond_28
    if-nez v23, :cond_29

    .line 688
    .line 689
    const-string v1, " version"

    .line 690
    .line 691
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 692
    .line 693
    .line 694
    :cond_29
    const-string v1, "Missing required properties:"

    .line 695
    .line 696
    invoke-static {v1, v0}, Lo/nrkepnpirid;->ndpnikda(Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 697
    .line 698
    .line 699
    move-result-object v0

    .line 700
    invoke-static {v0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 701
    .line 702
    .line 703
    return-object v19

    .line 704
    :pswitch_c
    const/16 v29, 0x8

    .line 705
    .line 706
    new-instance v3, Lo/rara;

    .line 707
    .line 708
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 709
    .line 710
    .line 711
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->beginObject()V

    .line 712
    .line 713
    .line 714
    :goto_f
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 715
    .line 716
    .line 717
    move-result v6

    .line 718
    if-eqz v6, :cond_30

    .line 719
    .line 720
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 721
    .line 722
    .line 723
    move-result-object v6

    .line 724
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 725
    .line 726
    .line 727
    invoke-virtual {v6}, Ljava/lang/String;->hashCode()I

    .line 728
    .line 729
    .line 730
    move-result v12

    .line 731
    sparse-switch v12, :sswitch_data_3

    .line 732
    .line 733
    .line 734
    :goto_10
    move/from16 v6, v16

    .line 735
    .line 736
    goto :goto_11

    .line 737
    :sswitch_1e
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 738
    .line 739
    .line 740
    move-result v6

    .line 741
    if-nez v6, :cond_2a

    .line 742
    .line 743
    goto :goto_10

    .line 744
    :cond_2a
    move v6, v15

    .line 745
    goto :goto_11

    .line 746
    :sswitch_1f
    invoke-virtual {v6, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 747
    .line 748
    .line 749
    move-result v6

    .line 750
    if-nez v6, :cond_2b

    .line 751
    .line 752
    goto :goto_10

    .line 753
    :cond_2b
    move v6, v4

    .line 754
    goto :goto_11

    .line 755
    :sswitch_20
    const-string v12, "jailbroken"

    .line 756
    .line 757
    invoke-virtual {v6, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 758
    .line 759
    .line 760
    move-result v6

    .line 761
    if-nez v6, :cond_2c

    .line 762
    .line 763
    goto :goto_10

    .line 764
    :cond_2c
    move/from16 v6, v18

    .line 765
    .line 766
    goto :goto_11

    .line 767
    :sswitch_21
    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 768
    .line 769
    .line 770
    move-result v6

    .line 771
    if-nez v6, :cond_2d

    .line 772
    .line 773
    goto :goto_10

    .line 774
    :cond_2d
    const/4 v6, 0x0

    .line 775
    :goto_11
    packed-switch v6, :pswitch_data_3

    .line 776
    .line 777
    .line 778
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->skipValue()V

    .line 779
    .line 780
    .line 781
    goto :goto_f

    .line 782
    :pswitch_d
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextInt()I

    .line 783
    .line 784
    .line 785
    move-result v6

    .line 786
    iput v6, v3, Lo/rara;->dpunpe:I

    .line 787
    .line 788
    iget-byte v6, v3, Lo/rara;->iiunkaippn:B

    .line 789
    .line 790
    or-int/lit8 v6, v6, 0x1

    .line 791
    .line 792
    int-to-byte v6, v6

    .line 793
    iput-byte v6, v3, Lo/rara;->iiunkaippn:B

    .line 794
    .line 795
    goto :goto_f

    .line 796
    :pswitch_e
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 797
    .line 798
    .line 799
    move-result-object v6

    .line 800
    if-eqz v6, :cond_2e

    .line 801
    .line 802
    iput-object v6, v3, Lo/rara;->dpeakapiakpa:Ljava/lang/String;

    .line 803
    .line 804
    goto :goto_f

    .line 805
    :cond_2e
    invoke-static/range {v21 .. v21}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 806
    .line 807
    .line 808
    return-object v19

    .line 809
    :pswitch_f
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextBoolean()Z

    .line 810
    .line 811
    .line 812
    move-result v6

    .line 813
    iput-boolean v6, v3, Lo/rara;->irkari:Z

    .line 814
    .line 815
    iget-byte v6, v3, Lo/rara;->iiunkaippn:B

    .line 816
    .line 817
    or-int/2addr v6, v4

    .line 818
    int-to-byte v6, v6

    .line 819
    iput-byte v6, v3, Lo/rara;->iiunkaippn:B

    .line 820
    .line 821
    goto :goto_f

    .line 822
    :pswitch_10
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 823
    .line 824
    .line 825
    move-result-object v6

    .line 826
    if-eqz v6, :cond_2f

    .line 827
    .line 828
    iput-object v6, v3, Lo/rara;->pepeunri:Ljava/lang/String;

    .line 829
    .line 830
    goto :goto_f

    .line 831
    :cond_2f
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 832
    .line 833
    .line 834
    return-object v19

    .line 835
    :cond_30
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->endObject()V

    .line 836
    .line 837
    .line 838
    invoke-virtual {v3}, Lo/rara;->dpunpe()Lo/aaidrnernuid;

    .line 839
    .line 840
    .line 841
    move-result-object v3

    .line 842
    iput-object v3, v1, Lo/ueapnernia;->nkpkuui:Lo/aerardueaak;

    .line 843
    .line 844
    goto/16 :goto_4

    .line 845
    .line 846
    :pswitch_11
    const/16 v29, 0x8

    .line 847
    .line 848
    new-instance v3, Ljava/util/ArrayList;

    .line 849
    .line 850
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 851
    .line 852
    .line 853
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->beginArray()V

    .line 854
    .line 855
    .line 856
    :goto_12
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 857
    .line 858
    .line 859
    move-result v6

    .line 860
    if-eqz v6, :cond_31

    .line 861
    .line 862
    invoke-static/range {p0 .. p0}, Lo/aekpnkrpripi;->iiunkaippn(Landroid/util/JsonReader;)Lo/dnpidedind;

    .line 863
    .line 864
    .line 865
    move-result-object v6

    .line 866
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 867
    .line 868
    .line 869
    goto :goto_12

    .line 870
    :cond_31
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->endArray()V

    .line 871
    .line 872
    .line 873
    invoke-static {v3}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 874
    .line 875
    .line 876
    move-result-object v3

    .line 877
    iput-object v3, v1, Lo/ueapnernia;->uikrdedi:Ljava/util/List;

    .line 878
    .line 879
    goto/16 :goto_4

    .line 880
    .line 881
    :pswitch_12
    const/16 v29, 0x8

    .line 882
    .line 883
    new-instance v3, Lo/aaapau;

    .line 884
    .line 885
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 886
    .line 887
    .line 888
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->beginObject()V

    .line 889
    .line 890
    .line 891
    :goto_13
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 892
    .line 893
    .line 894
    move-result v6

    .line 895
    if-eqz v6, :cond_3e

    .line 896
    .line 897
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 898
    .line 899
    .line 900
    move-result-object v6

    .line 901
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 902
    .line 903
    .line 904
    invoke-virtual {v6}, Ljava/lang/String;->hashCode()I

    .line 905
    .line 906
    .line 907
    move-result v11

    .line 908
    sparse-switch v11, :sswitch_data_4

    .line 909
    .line 910
    .line 911
    :goto_14
    move/from16 v6, v16

    .line 912
    .line 913
    goto/16 :goto_15

    .line 914
    .line 915
    :sswitch_22
    const-string v11, "modelClass"

    .line 916
    .line 917
    invoke-virtual {v6, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 918
    .line 919
    .line 920
    move-result v6

    .line 921
    if-nez v6, :cond_32

    .line 922
    .line 923
    goto :goto_14

    .line 924
    :cond_32
    move/from16 v6, v29

    .line 925
    .line 926
    goto/16 :goto_15

    .line 927
    .line 928
    :sswitch_23
    const-string v11, "state"

    .line 929
    .line 930
    invoke-virtual {v6, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 931
    .line 932
    .line 933
    move-result v6

    .line 934
    if-nez v6, :cond_33

    .line 935
    .line 936
    goto :goto_14

    .line 937
    :cond_33
    const/4 v6, 0x7

    .line 938
    goto :goto_15

    .line 939
    :sswitch_24
    const-string v11, "model"

    .line 940
    .line 941
    invoke-virtual {v6, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 942
    .line 943
    .line 944
    move-result v6

    .line 945
    if-nez v6, :cond_34

    .line 946
    .line 947
    goto :goto_14

    .line 948
    :cond_34
    const/4 v6, 0x6

    .line 949
    goto :goto_15

    .line 950
    :sswitch_25
    const-string v11, "cores"

    .line 951
    .line 952
    invoke-virtual {v6, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 953
    .line 954
    .line 955
    move-result v6

    .line 956
    if-nez v6, :cond_35

    .line 957
    .line 958
    goto :goto_14

    .line 959
    :cond_35
    move v6, v14

    .line 960
    goto :goto_15

    .line 961
    :sswitch_26
    const-string v11, "diskSpace"

    .line 962
    .line 963
    invoke-virtual {v6, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 964
    .line 965
    .line 966
    move-result v6

    .line 967
    if-nez v6, :cond_36

    .line 968
    .line 969
    goto :goto_14

    .line 970
    :cond_36
    move/from16 v6, v17

    .line 971
    .line 972
    goto :goto_15

    .line 973
    :sswitch_27
    const-string v11, "arch"

    .line 974
    .line 975
    invoke-virtual {v6, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 976
    .line 977
    .line 978
    move-result v6

    .line 979
    if-nez v6, :cond_37

    .line 980
    .line 981
    goto :goto_14

    .line 982
    :cond_37
    move v6, v15

    .line 983
    goto :goto_15

    .line 984
    :sswitch_28
    const-string v11, "ram"

    .line 985
    .line 986
    invoke-virtual {v6, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 987
    .line 988
    .line 989
    move-result v6

    .line 990
    if-nez v6, :cond_38

    .line 991
    .line 992
    goto :goto_14

    .line 993
    :cond_38
    move v6, v4

    .line 994
    goto :goto_15

    .line 995
    :sswitch_29
    const-string v11, "manufacturer"

    .line 996
    .line 997
    invoke-virtual {v6, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 998
    .line 999
    .line 1000
    move-result v6

    .line 1001
    if-nez v6, :cond_39

    .line 1002
    .line 1003
    goto :goto_14

    .line 1004
    :cond_39
    move/from16 v6, v18

    .line 1005
    .line 1006
    goto :goto_15

    .line 1007
    :sswitch_2a
    const-string v11, "simulator"

    .line 1008
    .line 1009
    invoke-virtual {v6, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1010
    .line 1011
    .line 1012
    move-result v6

    .line 1013
    if-nez v6, :cond_3a

    .line 1014
    .line 1015
    goto :goto_14

    .line 1016
    :cond_3a
    const/4 v6, 0x0

    .line 1017
    :goto_15
    packed-switch v6, :pswitch_data_4

    .line 1018
    .line 1019
    .line 1020
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->skipValue()V

    .line 1021
    .line 1022
    .line 1023
    goto/16 :goto_13

    .line 1024
    .line 1025
    :pswitch_13
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1026
    .line 1027
    .line 1028
    move-result-object v6

    .line 1029
    if-eqz v6, :cond_3b

    .line 1030
    .line 1031
    iput-object v6, v3, Lo/aaapau;->nkpkuui:Ljava/lang/String;

    .line 1032
    .line 1033
    goto/16 :goto_13

    .line 1034
    .line 1035
    :cond_3b
    const-string v0, "Null modelClass"

    .line 1036
    .line 1037
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 1038
    .line 1039
    .line 1040
    return-object v19

    .line 1041
    :pswitch_14
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextInt()I

    .line 1042
    .line 1043
    .line 1044
    move-result v6

    .line 1045
    iput v6, v3, Lo/aaapau;->adadnadrr:I

    .line 1046
    .line 1047
    iget-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1048
    .line 1049
    or-int/lit8 v6, v6, 0x20

    .line 1050
    .line 1051
    int-to-byte v6, v6

    .line 1052
    iput-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1053
    .line 1054
    goto/16 :goto_13

    .line 1055
    .line 1056
    :pswitch_15
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1057
    .line 1058
    .line 1059
    move-result-object v6

    .line 1060
    if-eqz v6, :cond_3c

    .line 1061
    .line 1062
    iput-object v6, v3, Lo/aaapau;->dpeakapiakpa:Ljava/lang/String;

    .line 1063
    .line 1064
    goto/16 :goto_13

    .line 1065
    .line 1066
    :cond_3c
    const-string v0, "Null model"

    .line 1067
    .line 1068
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 1069
    .line 1070
    .line 1071
    return-object v19

    .line 1072
    :pswitch_16
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextInt()I

    .line 1073
    .line 1074
    .line 1075
    move-result v6

    .line 1076
    iput v6, v3, Lo/aaapau;->pepeunri:I

    .line 1077
    .line 1078
    iget-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1079
    .line 1080
    or-int/2addr v6, v4

    .line 1081
    int-to-byte v6, v6

    .line 1082
    iput-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1083
    .line 1084
    goto/16 :goto_13

    .line 1085
    .line 1086
    :pswitch_17
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextLong()J

    .line 1087
    .line 1088
    .line 1089
    move-result-wide v11

    .line 1090
    iput-wide v11, v3, Lo/aaapau;->iiunkaippn:J

    .line 1091
    .line 1092
    iget-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1093
    .line 1094
    or-int/lit8 v6, v6, 0x8

    .line 1095
    .line 1096
    int-to-byte v6, v6

    .line 1097
    iput-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1098
    .line 1099
    goto/16 :goto_13

    .line 1100
    .line 1101
    :pswitch_18
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextInt()I

    .line 1102
    .line 1103
    .line 1104
    move-result v6

    .line 1105
    iput v6, v3, Lo/aaapau;->dpunpe:I

    .line 1106
    .line 1107
    iget-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1108
    .line 1109
    or-int/lit8 v6, v6, 0x1

    .line 1110
    .line 1111
    int-to-byte v6, v6

    .line 1112
    iput-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1113
    .line 1114
    goto/16 :goto_13

    .line 1115
    .line 1116
    :pswitch_19
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextLong()J

    .line 1117
    .line 1118
    .line 1119
    move-result-wide v11

    .line 1120
    iput-wide v11, v3, Lo/aaapau;->irkari:J

    .line 1121
    .line 1122
    iget-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1123
    .line 1124
    or-int/lit8 v6, v6, 0x4

    .line 1125
    .line 1126
    int-to-byte v6, v6

    .line 1127
    iput-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1128
    .line 1129
    goto/16 :goto_13

    .line 1130
    .line 1131
    :pswitch_1a
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1132
    .line 1133
    .line 1134
    move-result-object v6

    .line 1135
    if-eqz v6, :cond_3d

    .line 1136
    .line 1137
    iput-object v6, v3, Lo/aaapau;->dedr:Ljava/lang/String;

    .line 1138
    .line 1139
    goto/16 :goto_13

    .line 1140
    .line 1141
    :cond_3d
    const-string v0, "Null manufacturer"

    .line 1142
    .line 1143
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 1144
    .line 1145
    .line 1146
    return-object v19

    .line 1147
    :pswitch_1b
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextBoolean()Z

    .line 1148
    .line 1149
    .line 1150
    move-result v6

    .line 1151
    iput-boolean v6, v3, Lo/aaapau;->aiupunrka:Z

    .line 1152
    .line 1153
    iget-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1154
    .line 1155
    or-int/lit8 v6, v6, 0x10

    .line 1156
    .line 1157
    int-to-byte v6, v6

    .line 1158
    iput-byte v6, v3, Lo/aaapau;->kikaa:B

    .line 1159
    .line 1160
    goto/16 :goto_13

    .line 1161
    .line 1162
    :cond_3e
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->endObject()V

    .line 1163
    .line 1164
    .line 1165
    invoke-virtual {v3}, Lo/aaapau;->dpunpe()Lo/udpadan;

    .line 1166
    .line 1167
    .line 1168
    move-result-object v3

    .line 1169
    iput-object v3, v1, Lo/ueapnernia;->kikaa:Lo/eieuia;

    .line 1170
    .line 1171
    goto/16 :goto_4

    .line 1172
    .line 1173
    :pswitch_1c
    const/16 v29, 0x8

    .line 1174
    .line 1175
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextLong()J

    .line 1176
    .line 1177
    .line 1178
    move-result-wide v11

    .line 1179
    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1180
    .line 1181
    .line 1182
    move-result-object v3

    .line 1183
    iput-object v3, v1, Lo/ueapnernia;->iiunkaippn:Ljava/lang/Long;

    .line 1184
    .line 1185
    goto/16 :goto_4

    .line 1186
    .line 1187
    :pswitch_1d
    const/16 v29, 0x8

    .line 1188
    .line 1189
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1190
    .line 1191
    .line 1192
    move-result-object v3

    .line 1193
    invoke-static {v3, v4}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 1194
    .line 1195
    .line 1196
    move-result-object v3

    .line 1197
    new-instance v6, Ljava/lang/String;

    .line 1198
    .line 1199
    sget-object v11, Lo/rnea;->dpunpe:Ljava/nio/charset/Charset;

    .line 1200
    .line 1201
    invoke-direct {v6, v3, v11}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 1202
    .line 1203
    .line 1204
    iput-object v6, v1, Lo/ueapnernia;->dpeakapiakpa:Ljava/lang/String;

    .line 1205
    .line 1206
    goto/16 :goto_4

    .line 1207
    .line 1208
    :pswitch_1e
    const/16 v29, 0x8

    .line 1209
    .line 1210
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1211
    .line 1212
    .line 1213
    move-result-object v3

    .line 1214
    iput-object v3, v1, Lo/ueapnernia;->pepeunri:Ljava/lang/String;

    .line 1215
    .line 1216
    goto/16 :goto_4

    .line 1217
    .line 1218
    :pswitch_1f
    const/16 v29, 0x8

    .line 1219
    .line 1220
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextLong()J

    .line 1221
    .line 1222
    .line 1223
    move-result-wide v11

    .line 1224
    iput-wide v11, v1, Lo/ueapnernia;->irkari:J

    .line 1225
    .line 1226
    iget-byte v3, v1, Lo/ueapnernia;->uninpker:B

    .line 1227
    .line 1228
    or-int/lit8 v3, v3, 0x1

    .line 1229
    .line 1230
    int-to-byte v3, v3

    .line 1231
    iput-byte v3, v1, Lo/ueapnernia;->uninpker:B

    .line 1232
    .line 1233
    goto/16 :goto_4

    .line 1234
    .line 1235
    :cond_3f
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->endObject()V

    .line 1236
    .line 1237
    .line 1238
    invoke-virtual {v1}, Lo/ueapnernia;->dpunpe()Lo/inddedpri;

    .line 1239
    .line 1240
    .line 1241
    move-result-object v1

    .line 1242
    iput-object v1, v0, Lo/rpnnpaauuan;->kikaa:Lo/rddup;

    .line 1243
    .line 1244
    goto/16 :goto_3

    .line 1245
    .line 1246
    :pswitch_20
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1247
    .line 1248
    .line 1249
    move-result-object v1

    .line 1250
    if-eqz v1, :cond_40

    .line 1251
    .line 1252
    iput-object v1, v0, Lo/rpnnpaauuan;->nkpkuui:Ljava/lang/String;

    .line 1253
    .line 1254
    goto/16 :goto_3

    .line 1255
    .line 1256
    :cond_40
    const-string v0, "Null displayVersion"

    .line 1257
    .line 1258
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 1259
    .line 1260
    .line 1261
    return-object v19

    .line 1262
    :pswitch_21
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextInt()I

    .line 1263
    .line 1264
    .line 1265
    move-result v1

    .line 1266
    iput v1, v0, Lo/rpnnpaauuan;->pepeunri:I

    .line 1267
    .line 1268
    iget-byte v1, v0, Lo/rpnnpaauuan;->uninpker:B

    .line 1269
    .line 1270
    or-int/lit8 v1, v1, 0x1

    .line 1271
    .line 1272
    int-to-byte v1, v1

    .line 1273
    iput-byte v1, v0, Lo/rpnnpaauuan;->uninpker:B

    .line 1274
    .line 1275
    goto/16 :goto_3

    .line 1276
    .line 1277
    :pswitch_22
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1278
    .line 1279
    .line 1280
    move-result-object v1

    .line 1281
    iput-object v1, v0, Lo/rpnnpaauuan;->iiunkaippn:Ljava/lang/String;

    .line 1282
    .line 1283
    goto/16 :goto_3

    .line 1284
    .line 1285
    :pswitch_23
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1286
    .line 1287
    .line 1288
    move-result-object v1

    .line 1289
    if-eqz v1, :cond_41

    .line 1290
    .line 1291
    iput-object v1, v0, Lo/rpnnpaauuan;->irkari:Ljava/lang/String;

    .line 1292
    .line 1293
    goto/16 :goto_3

    .line 1294
    .line 1295
    :cond_41
    const-string v0, "Null installationUuid"

    .line 1296
    .line 1297
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 1298
    .line 1299
    .line 1300
    return-object v19

    .line 1301
    :pswitch_24
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1302
    .line 1303
    .line 1304
    move-result-object v1

    .line 1305
    if-eqz v1, :cond_42

    .line 1306
    .line 1307
    iput-object v1, v0, Lo/rpnnpaauuan;->dpeakapiakpa:Ljava/lang/String;

    .line 1308
    .line 1309
    goto/16 :goto_3

    .line 1310
    .line 1311
    :cond_42
    const-string v0, "Null gmpAppId"

    .line 1312
    .line 1313
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 1314
    .line 1315
    .line 1316
    return-object v19

    .line 1317
    :pswitch_25
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1318
    .line 1319
    .line 1320
    move-result-object v1

    .line 1321
    iput-object v1, v0, Lo/rpnnpaauuan;->aiupunrka:Ljava/lang/String;

    .line 1322
    .line 1323
    goto/16 :goto_3

    .line 1324
    .line 1325
    :pswitch_26
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1326
    .line 1327
    .line 1328
    move-result-object v1

    .line 1329
    if-eqz v1, :cond_43

    .line 1330
    .line 1331
    iput-object v1, v0, Lo/rpnnpaauuan;->dedr:Ljava/lang/String;

    .line 1332
    .line 1333
    goto/16 :goto_3

    .line 1334
    .line 1335
    :cond_43
    invoke-static {v2}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 1336
    .line 1337
    .line 1338
    return-object v19

    .line 1339
    :pswitch_27
    invoke-static/range {p0 .. p0}, Lo/aekpnkrpripi;->pepeunri(Landroid/util/JsonReader;)Lo/diikaeukernu;

    .line 1340
    .line 1341
    .line 1342
    move-result-object v1

    .line 1343
    iput-object v1, v0, Lo/rpnnpaauuan;->ndpnikda:Lo/kkiiiped;

    .line 1344
    .line 1345
    goto/16 :goto_3

    .line 1346
    .line 1347
    :pswitch_28
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1348
    .line 1349
    .line 1350
    move-result-object v1

    .line 1351
    iput-object v1, v0, Lo/rpnnpaauuan;->adadnadrr:Ljava/lang/String;

    .line 1352
    .line 1353
    goto/16 :goto_3

    .line 1354
    .line 1355
    :pswitch_29
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1356
    .line 1357
    .line 1358
    move-result-object v1

    .line 1359
    if-eqz v1, :cond_44

    .line 1360
    .line 1361
    iput-object v1, v0, Lo/rpnnpaauuan;->dpunpe:Ljava/lang/String;

    .line 1362
    .line 1363
    goto/16 :goto_3

    .line 1364
    .line 1365
    :cond_44
    const-string v0, "Null sdkVersion"

    .line 1366
    .line 1367
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 1368
    .line 1369
    .line 1370
    return-object v19

    .line 1371
    :pswitch_2a
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->beginObject()V

    .line 1372
    .line 1373
    .line 1374
    move-object/from16 v1, v19

    .line 1375
    .line 1376
    move-object v2, v1

    .line 1377
    :goto_16
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 1378
    .line 1379
    .line 1380
    move-result v3

    .line 1381
    if-eqz v3, :cond_48

    .line 1382
    .line 1383
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 1384
    .line 1385
    .line 1386
    move-result-object v3

    .line 1387
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1388
    .line 1389
    .line 1390
    const-string v4, "files"

    .line 1391
    .line 1392
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1393
    .line 1394
    .line 1395
    move-result v4

    .line 1396
    if-nez v4, :cond_46

    .line 1397
    .line 1398
    const-string v4, "orgId"

    .line 1399
    .line 1400
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1401
    .line 1402
    .line 1403
    move-result v3

    .line 1404
    if-nez v3, :cond_45

    .line 1405
    .line 1406
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->skipValue()V

    .line 1407
    .line 1408
    .line 1409
    :goto_17
    move-object/from16 v3, p0

    .line 1410
    .line 1411
    goto :goto_16

    .line 1412
    :cond_45
    invoke-virtual/range {p0 .. p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 1413
    .line 1414
    .line 1415
    move-result-object v2

    .line 1416
    goto :goto_17

    .line 1417
    :cond_46
    new-instance v1, Lo/kniuuerekaup;

    .line 1418
    .line 1419
    const/16 v3, 0xd

    .line 1420
    .line 1421
    invoke-direct {v1, v3}, Lo/kniuuerekaup;-><init>(I)V

    .line 1422
    .line 1423
    .line 1424
    move-object/from16 v3, p0

    .line 1425
    .line 1426
    invoke-static {v3, v1}, Lo/aekpnkrpripi;->irkari(Landroid/util/JsonReader;Lo/kniuuerekaup;)Ljava/util/List;

    .line 1427
    .line 1428
    .line 1429
    move-result-object v1

    .line 1430
    if-eqz v1, :cond_47

    .line 1431
    .line 1432
    goto :goto_16

    .line 1433
    :cond_47
    const-string v0, "Null files"

    .line 1434
    .line 1435
    invoke-static {v0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 1436
    .line 1437
    .line 1438
    return-object v19

    .line 1439
    :cond_48
    move-object/from16 v3, p0

    .line 1440
    .line 1441
    invoke-virtual {v3}, Landroid/util/JsonReader;->endObject()V

    .line 1442
    .line 1443
    .line 1444
    if-eqz v1, :cond_49

    .line 1445
    .line 1446
    new-instance v4, Lo/epkdpnkiiea;

    .line 1447
    .line 1448
    invoke-direct {v4, v1, v2}, Lo/epkdpnkiiea;-><init>(Ljava/util/List;Ljava/lang/String;)V

    .line 1449
    .line 1450
    .line 1451
    iput-object v4, v0, Lo/rpnnpaauuan;->uikrdedi:Lo/prdrda;

    .line 1452
    .line 1453
    goto/16 :goto_0

    .line 1454
    .line 1455
    :cond_49
    const-string v0, "Missing required properties: files"

    .line 1456
    .line 1457
    invoke-static {v0}, Lo/nuekid;->adadnadrr(Ljava/lang/String;)V

    .line 1458
    .line 1459
    .line 1460
    return-object v19

    .line 1461
    :cond_4a
    move-object/from16 v3, p0

    .line 1462
    .line 1463
    invoke-virtual {v3}, Landroid/util/JsonReader;->endObject()V

    .line 1464
    .line 1465
    .line 1466
    invoke-virtual {v0}, Lo/rpnnpaauuan;->dpunpe()Lo/ipipkpua;

    .line 1467
    .line 1468
    .line 1469
    move-result-object v0

    .line 1470
    return-object v0

    .line 1471
    :sswitch_data_0
    .sparse-switch
        -0x7e43cda7 -> :sswitch_b
        -0x74fb5cc2 -> :sswitch_a
        -0x71ad57ad -> :sswitch_9
        -0x51f6ffd3 -> :sswitch_8
        -0x36578976 -> :sswitch_7
        -0x17f5db26 -> :sswitch_6
        0x14879cf2 -> :sswitch_5
        0x2ae81915 -> :sswitch_4
        0x3e71e6dc -> :sswitch_3
        0x6fbd6873 -> :sswitch_2
        0x75c19db6 -> :sswitch_1
        0x76508296 -> :sswitch_0
    .end sparse-switch

    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2a
        :pswitch_29
        :pswitch_28
        :pswitch_27
        :pswitch_26
        :pswitch_25
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_0
    .end packed-switch

    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    :sswitch_data_1
    .sparse-switch
        -0x7ee2d36c -> :sswitch_17
        -0x71ad57ad -> :sswitch_16
        -0x60775357 -> :sswitch_15
        -0x5fc4f373 -> :sswitch_14
        -0x4f94e1aa -> :sswitch_13
        -0x4cf81ee7 -> :sswitch_12
        0xde4 -> :sswitch_11
        0x17a21 -> :sswitch_10
        0x36ebcb -> :sswitch_f
        0x111a9ad3 -> :sswitch_e
        0x3d1e2286 -> :sswitch_d
        0x7a02fcad -> :sswitch_c
    .end sparse-switch

    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_12
        :pswitch_11
        :pswitch_c
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch

    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    :sswitch_data_2
    .sparse-switch
        -0x60775357 -> :sswitch_1d
        -0x1ef60132 -> :sswitch_1c
        0xcbc122a -> :sswitch_1b
        0x14f51cd8 -> :sswitch_1a
        0x2ae81915 -> :sswitch_19
        0x75c19db6 -> :sswitch_18
    .end sparse-switch

    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
    .end packed-switch

    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    :sswitch_data_3
    .sparse-switch
        -0x36578976 -> :sswitch_21
        -0x11773b11 -> :sswitch_20
        0x14f51cd8 -> :sswitch_1f
        0x6fbd6873 -> :sswitch_1e
    .end sparse-switch

    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    :pswitch_data_3
    .packed-switch 0x0
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
    .end packed-switch

    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    :sswitch_data_4
    .sparse-switch
        -0x7618bbfc -> :sswitch_2a
        -0x7561dc2f -> :sswitch_29
        0x1b81e -> :sswitch_28
        0x2dd056 -> :sswitch_27
        0x4dfed69 -> :sswitch_26
        0x5a744b4 -> :sswitch_25
        0x633fb29 -> :sswitch_24
        0x68ac491 -> :sswitch_23
        0x7bea4fcf -> :sswitch_22
    .end sparse-switch

    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    :pswitch_data_4
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
    .end packed-switch
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
.end method

.method public static pepeunri(Landroid/util/JsonReader;)Lo/diikaeukernu;
    .locals 8

    .line 1
    new-instance v0, Lo/eprkadurdpdn;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/util/JsonReader;->beginObject()V

    .line 7
    .line 8
    .line 9
    :goto_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_a

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    const/16 v3, 0x8

    .line 27
    .line 28
    const/4 v4, 0x4

    .line 29
    const/4 v5, 0x2

    .line 30
    const/4 v6, 0x1

    .line 31
    const/4 v7, -0x1

    .line 32
    sparse-switch v2, :sswitch_data_0

    .line 33
    .line 34
    .line 35
    goto/16 :goto_1

    .line 36
    .line 37
    :sswitch_0
    const-string v2, "importance"

    .line 38
    .line 39
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-nez v1, :cond_0

    .line 44
    .line 45
    goto/16 :goto_1

    .line 46
    .line 47
    :cond_0
    move v7, v3

    .line 48
    goto/16 :goto_1

    .line 49
    .line 50
    :sswitch_1
    const-string v2, "traceFile"

    .line 51
    .line 52
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    if-nez v1, :cond_1

    .line 57
    .line 58
    goto :goto_1

    .line 59
    :cond_1
    const/4 v7, 0x7

    .line 60
    goto :goto_1

    .line 61
    :sswitch_2
    const-string v2, "reasonCode"

    .line 62
    .line 63
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    if-nez v1, :cond_2

    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_2
    const/4 v7, 0x6

    .line 71
    goto :goto_1

    .line 72
    :sswitch_3
    const-string v2, "processName"

    .line 73
    .line 74
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    if-nez v1, :cond_3

    .line 79
    .line 80
    goto :goto_1

    .line 81
    :cond_3
    const/4 v7, 0x5

    .line 82
    goto :goto_1

    .line 83
    :sswitch_4
    const-string v2, "timestamp"

    .line 84
    .line 85
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v1

    .line 89
    if-nez v1, :cond_4

    .line 90
    .line 91
    goto :goto_1

    .line 92
    :cond_4
    move v7, v4

    .line 93
    goto :goto_1

    .line 94
    :sswitch_5
    const-string v2, "rss"

    .line 95
    .line 96
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v1

    .line 100
    if-nez v1, :cond_5

    .line 101
    .line 102
    goto :goto_1

    .line 103
    :cond_5
    const/4 v7, 0x3

    .line 104
    goto :goto_1

    .line 105
    :sswitch_6
    const-string v2, "pss"

    .line 106
    .line 107
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v1

    .line 111
    if-nez v1, :cond_6

    .line 112
    .line 113
    goto :goto_1

    .line 114
    :cond_6
    move v7, v5

    .line 115
    goto :goto_1

    .line 116
    :sswitch_7
    const-string v2, "pid"

    .line 117
    .line 118
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 119
    .line 120
    .line 121
    move-result v1

    .line 122
    if-nez v1, :cond_7

    .line 123
    .line 124
    goto :goto_1

    .line 125
    :cond_7
    move v7, v6

    .line 126
    goto :goto_1

    .line 127
    :sswitch_8
    const-string v2, "buildIdMappingForArch"

    .line 128
    .line 129
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v1

    .line 133
    if-nez v1, :cond_8

    .line 134
    .line 135
    goto :goto_1

    .line 136
    :cond_8
    const/4 v7, 0x0

    .line 137
    :goto_1
    packed-switch v7, :pswitch_data_0

    .line 138
    .line 139
    .line 140
    invoke-virtual {p0}, Landroid/util/JsonReader;->skipValue()V

    .line 141
    .line 142
    .line 143
    goto/16 :goto_0

    .line 144
    .line 145
    :pswitch_0
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextInt()I

    .line 146
    .line 147
    .line 148
    move-result v1

    .line 149
    iput v1, v0, Lo/eprkadurdpdn;->irkari:I

    .line 150
    .line 151
    iget-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 152
    .line 153
    or-int/2addr v1, v4

    .line 154
    int-to-byte v1, v1

    .line 155
    iput-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 156
    .line 157
    goto/16 :goto_0

    .line 158
    .line 159
    :pswitch_1
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 160
    .line 161
    .line 162
    move-result-object v1

    .line 163
    iput-object v1, v0, Lo/eprkadurdpdn;->dedr:Ljava/lang/String;

    .line 164
    .line 165
    goto/16 :goto_0

    .line 166
    .line 167
    :pswitch_2
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextInt()I

    .line 168
    .line 169
    .line 170
    move-result v1

    .line 171
    iput v1, v0, Lo/eprkadurdpdn;->pepeunri:I

    .line 172
    .line 173
    iget-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 174
    .line 175
    or-int/2addr v1, v5

    .line 176
    int-to-byte v1, v1

    .line 177
    iput-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 178
    .line 179
    goto/16 :goto_0

    .line 180
    .line 181
    :pswitch_3
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object v1

    .line 185
    if-eqz v1, :cond_9

    .line 186
    .line 187
    iput-object v1, v0, Lo/eprkadurdpdn;->dpeakapiakpa:Ljava/lang/String;

    .line 188
    .line 189
    goto/16 :goto_0

    .line 190
    .line 191
    :cond_9
    const-string p0, "Null processName"

    .line 192
    .line 193
    invoke-static {p0}, Lo/akide;->nkpkuui(Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    const/4 p0, 0x0

    .line 197
    return-object p0

    .line 198
    :pswitch_4
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextLong()J

    .line 199
    .line 200
    .line 201
    move-result-wide v1

    .line 202
    iput-wide v1, v0, Lo/eprkadurdpdn;->adadnadrr:J

    .line 203
    .line 204
    iget-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 205
    .line 206
    or-int/lit8 v1, v1, 0x20

    .line 207
    .line 208
    int-to-byte v1, v1

    .line 209
    iput-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 210
    .line 211
    goto/16 :goto_0

    .line 212
    .line 213
    :pswitch_5
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextLong()J

    .line 214
    .line 215
    .line 216
    move-result-wide v1

    .line 217
    iput-wide v1, v0, Lo/eprkadurdpdn;->aiupunrka:J

    .line 218
    .line 219
    iget-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 220
    .line 221
    or-int/lit8 v1, v1, 0x10

    .line 222
    .line 223
    int-to-byte v1, v1

    .line 224
    iput-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 225
    .line 226
    goto/16 :goto_0

    .line 227
    .line 228
    :pswitch_6
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextLong()J

    .line 229
    .line 230
    .line 231
    move-result-wide v1

    .line 232
    iput-wide v1, v0, Lo/eprkadurdpdn;->iiunkaippn:J

    .line 233
    .line 234
    iget-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 235
    .line 236
    or-int/2addr v1, v3

    .line 237
    int-to-byte v1, v1

    .line 238
    iput-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 239
    .line 240
    goto/16 :goto_0

    .line 241
    .line 242
    :pswitch_7
    invoke-virtual {p0}, Landroid/util/JsonReader;->nextInt()I

    .line 243
    .line 244
    .line 245
    move-result v1

    .line 246
    iput v1, v0, Lo/eprkadurdpdn;->dpunpe:I

    .line 247
    .line 248
    iget-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 249
    .line 250
    or-int/2addr v1, v6

    .line 251
    int-to-byte v1, v1

    .line 252
    iput-byte v1, v0, Lo/eprkadurdpdn;->kikaa:B

    .line 253
    .line 254
    goto/16 :goto_0

    .line 255
    .line 256
    :pswitch_8
    new-instance v1, Lo/kniuuerekaup;

    .line 257
    .line 258
    const/16 v2, 0xc

    .line 259
    .line 260
    invoke-direct {v1, v2}, Lo/kniuuerekaup;-><init>(I)V

    .line 261
    .line 262
    .line 263
    invoke-static {p0, v1}, Lo/aekpnkrpripi;->irkari(Landroid/util/JsonReader;Lo/kniuuerekaup;)Ljava/util/List;

    .line 264
    .line 265
    .line 266
    move-result-object v1

    .line 267
    iput-object v1, v0, Lo/eprkadurdpdn;->nkpkuui:Ljava/util/List;

    .line 268
    .line 269
    goto/16 :goto_0

    .line 270
    .line 271
    :cond_a
    invoke-virtual {p0}, Landroid/util/JsonReader;->endObject()V

    .line 272
    .line 273
    .line 274
    invoke-virtual {v0}, Lo/eprkadurdpdn;->dpunpe()Lo/diikaeukernu;

    .line 275
    .line 276
    .line 277
    move-result-object p0

    .line 278
    return-object p0

    .line 279
    :sswitch_data_0
    .sparse-switch
        -0x5a5f6366 -> :sswitch_8
        0x1b18b -> :sswitch_7
        0x1b2d0 -> :sswitch_6
        0x1ba52 -> :sswitch_5
        0x3492916 -> :sswitch_4
        0xc0f3d9a -> :sswitch_3
        0x2b0af251 -> :sswitch_2
        0x2b253061 -> :sswitch_1
        0x7eb2da74 -> :sswitch_0
    .end sparse-switch

    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
.end method
