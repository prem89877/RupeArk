.class public final Lo/aiknrdnpr;
.super Lo/urrndp;
.source "SourceFile"


# instance fields
.field public synthetic aaidaieneai:Ljava/lang/Object;

.field public final synthetic iureria:Lo/rppipd;

.field public rrkrpe:I


# direct methods
.method public constructor <init>(Lo/rppipd;Lo/urrndp;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lo/aiknrdnpr;->iureria:Lo/rppipd;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lo/urrndp;-><init>(Lo/arinuepn;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
.end method


# virtual methods
.method public final kaepinunirek(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lo/aiknrdnpr;->aaidaieneai:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lo/aiknrdnpr;->rrkrpe:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lo/aiknrdnpr;->rrkrpe:I

    .line 9
    .line 10
    iget-object p1, p0, Lo/aiknrdnpr;->iureria:Lo/rppipd;

    .line 11
    .line 12
    invoke-virtual {p1, p0}, Lo/rppipd;->pepeunri(Lo/urrndp;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
.end method
