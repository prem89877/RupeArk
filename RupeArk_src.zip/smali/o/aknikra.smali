.class public final Lo/aknikra;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final dpeakapiakpa:Lo/eind;

.field public final dpunpe:Lo/nakiriuuipi;


# direct methods
.method public constructor <init>(Lo/nakiriuuipi;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lo/aknikra;->dpunpe:Lo/nakiriuuipi;

    .line 5
    .line 6
    new-instance p1, Lo/eind;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-direct {p1, v0}, Lo/eind;-><init>(I)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, Lo/aknikra;->dpeakapiakpa:Lo/eind;

    .line 13
    .line 14
    return-void
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
.end method
