.class public final Lo/airpueuuk;
.super Lo/uppeni;
.source "SourceFile"

# interfaces
.implements Lo/kpur;


# instance fields
.field public aiunidkdk:F

.field public ideppeia:F

.field public niredd:Z

.field public paainep:F

.field public ppdunu:F


# virtual methods
.method public final dpunpe(Lo/karpk;Lo/kppariudkeni;J)Lo/rainnn;
    .locals 5

    .line 1
    iget v0, p0, Lo/airpueuuk;->aiunidkdk:F

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lo/puneeedua;->aiandi(F)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget v1, p0, Lo/airpueuuk;->paainep:F

    .line 8
    .line 9
    invoke-interface {p1, v1}, Lo/puneeedua;->aiandi(F)I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    add-int/2addr v1, v0

    .line 14
    iget v0, p0, Lo/airpueuuk;->ppdunu:F

    .line 15
    .line 16
    invoke-interface {p1, v0}, Lo/puneeedua;->aiandi(F)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    iget v2, p0, Lo/airpueuuk;->ideppeia:F

    .line 21
    .line 22
    invoke-interface {p1, v2}, Lo/puneeedua;->aiandi(F)I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    add-int/2addr v2, v0

    .line 27
    neg-int v0, v1

    .line 28
    neg-int v3, v2

    .line 29
    invoke-static {v0, v3, p3, p4}, Lo/unirnpep;->nkpkuui(IIJ)J

    .line 30
    .line 31
    .line 32
    move-result-wide v3

    .line 33
    invoke-interface {p2, v3, v4}, Lo/kppariudkeni;->irkari(J)Lo/dirkudrkpd;

    .line 34
    .line 35
    .line 36
    move-result-object p2

    .line 37
    iget v0, p2, Lo/dirkudrkpd;->dikdannunk:I

    .line 38
    .line 39
    add-int/2addr v0, v1

    .line 40
    invoke-static {v0, p3, p4}, Lo/unirnpep;->adadnadrr(IJ)I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    iget v1, p2, Lo/dirkudrkpd;->rpupp:I

    .line 45
    .line 46
    add-int/2addr v1, v2

    .line 47
    invoke-static {v1, p3, p4}, Lo/unirnpep;->aiupunrka(IJ)I

    .line 48
    .line 49
    .line 50
    move-result p3

    .line 51
    new-instance p4, Lo/anrpnuadpppn;

    .line 52
    .line 53
    const/16 v1, 0x1c

    .line 54
    .line 55
    invoke-direct {p4, v1, p0, p2}, Lo/anrpnuadpppn;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    sget-object p0, Lo/akrpnpdeka;->dikdannunk:Lo/akrpnpdeka;

    .line 59
    .line 60
    invoke-interface {p1, v0, p3, p0, p4}, Lo/karpk;->areni(IILjava/util/Map;Lo/npdkdr;)Lo/rainnn;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    return-object p0
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
.end method
